/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';

const ONE_HOUR_MS = 60 * 60 * 1000;

function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

function toValidDate(input: Date | number | string = Date.now()): Date | null {
  const d = input instanceof Date ? input : new Date(input);
  return Number.isNaN(d.getTime()) ? null : d;
}

/**
 * Formats an instant strictly in Universal Time (UTC / التوقيت العالمي) as HH:MM:SS.
 */
export function formatUtcClock(input: Date | number | string = Date.now()): string {
  const d = toValidDate(input);
  if (!d) return '--:--:--';
  return `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}:${pad2(d.getUTCSeconds())}`;
}

/**
 * Formats an instant strictly in UTC+1 (+1 / التوقيت المحلي +1) as HH:MM:SS.
 */
export function formatUtcPlusOneClock(input: Date | number | string = Date.now()): string {
  const d = toValidDate(input);
  if (!d) return '--:--:--';
  const plusOne = new Date(d.getTime() + ONE_HOUR_MS);
  return `${pad2(plusOne.getUTCHours())}:${pad2(plusOne.getUTCMinutes())}:${pad2(plusOne.getUTCSeconds())}`;
}

/**
 * Formats an instant strictly in Universal Time (UTC) as HH:MM.
 */
export function formatUtcShortTime(input: Date | number | string = Date.now()): string {
  const d = toValidDate(input);
  if (!d) return '--:--';
  return `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}`;
}

/**
 * Formats an instant strictly in UTC+1 (+1) as HH:MM.
 */
export function formatUtcPlusOneShortTime(input: Date | number | string = Date.now()): string {
  const d = toValidDate(input);
  if (!d) return '--:--';
  const plusOne = new Date(d.getTime() + ONE_HOUR_MS);
  return `${pad2(plusOne.getUTCHours())}:${pad2(plusOne.getUTCMinutes())}`;
}

/**
 * Formats an instant strictly in Universal Time (UTC) as DD-MM-YYYY.
 */
export function formatUtcDateString(input: Date | number | string = Date.now()): string {
  const d = toValidDate(input);
  if (!d) return '--';
  return `${pad2(d.getUTCDate())}-${pad2(d.getUTCMonth() + 1)}-${d.getUTCFullYear()}`;
}

/**
 * Formats an instant strictly in UTC+1 (+1) as DD-MM-YYYY.
 */
export function formatUtcPlusOneDateString(input: Date | number | string = Date.now()): string {
  const d = toValidDate(input);
  if (!d) return '--';
  const plusOne = new Date(d.getTime() + ONE_HOUR_MS);
  return `${pad2(plusOne.getUTCDate())}-${pad2(plusOne.getUTCMonth() + 1)}-${plusOne.getUTCFullYear()}`;
}

/**
 * Converts a Tunisia local date/time string (e.g. "mardi 17/11/2026 à 20:00",
 * "17/11/2026 à 20:00", "14-11-2026 à 18:00") into a UTC timestamp (epoch ms).
 */
export function parseTunisDateTimeToUtcMs(rawDateStr?: string): number | null {
  if (!rawDateStr) return null;
  const cleaned = rawDateStr.trim();
  const match = cleaned.match(/(\d{2})[/-](\d{2})[/-](\d{4})(?:.*?\b(\d{1,2}):(\d{2}))?/);
  if (!match) return null;

  const dd = match[1];
  const mm = match[2];
  const yyyy = match[3];
  const hh = match[4] ? pad2(Number(match[4])) : null;
  const min = match[5] ? pad2(Number(match[5])) : null;

  if (!hh || !min) {
    return null;
  }

  // Official promosport closing & tirage times on promosport-pronostic.com are in Tunisia time (UTC+1)
  const parsed = Date.parse(`${yyyy}-${mm}-${dd}T${hh}:${min}:00+01:00`);
  return Number.isFinite(parsed) ? parsed : null;
}

/**
 * Converts a Tunisia HH:MM string (e.g. from promo_matchs data-ko="20:45") + ISO date into UTC epoch ms & HH:MM UTC.
 */
export function convertTunisTimeToUtc(
  hhmm: string,
  isoDateStr?: string
): { utcHHMM: string; utcDate: string; timestampMs: number } {
  const clean = hhmm.trim();
  const m = clean.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) {
    return { utcHHMM: clean || '--:--', utcDate: '', timestampMs: 0 };
  }
  const hh = pad2(Number(m[1]));
  const mm = pad2(Number(m[2]));
  const datePart =
    isoDateStr && /^\d{4}-\d{2}-\d{2}$/.test(isoDateStr)
      ? isoDateStr
      : new Date().toISOString().slice(0, 10);

  const ms = Date.parse(`${datePart}T${hh}:${mm}:00+01:00`);
  if (!Number.isFinite(ms)) {
    return { utcHHMM: `${hh}:${mm}`, utcDate: '', timestampMs: 0 };
  }
  return {
    utcHHMM: formatUtcShortTime(ms),
    utcDate: formatUtcDateString(ms),
    timestampMs: ms,
  };
}

/**
 * Formats a concours / Tirage date string strictly in Universal Time (UTC / التوقيت العالمي).
 */
export function formatConcoursUtcLabel(rawDateStr?: string): string {
  if (!rawDateStr) return '-- UTC';
  if (/\bUTC\b/i.test(rawDateStr)) return rawDateStr;

  const ms = parseTunisDateTimeToUtcMs(rawDateStr);
  if (ms !== null) {
    return `${formatUtcDateString(ms)} • ${formatUtcShortTime(ms)} UTC`;
  }

  const dateOnly = rawDateStr.match(/(\d{2})[/-](\d{2})[/-](\d{4})/);
  if (dateOnly) {
    return `${dateOnly[1]}-${dateOnly[2]}-${dateOnly[3]}`;
  }
  return rawDateStr;
}

/**
 * Formats a concours / Tirage date string strictly in +1 (UTC+1) ONLY.
 */
export function formatConcoursPlusOneLabel(rawDateStr?: string): string {
  if (!rawDateStr) return '-- +1';

  const ms = parseTunisDateTimeToUtcMs(rawDateStr);
  if (ms !== null) {
    return `${formatUtcPlusOneDateString(ms)} • ${formatUtcPlusOneShortTime(ms)} +1`;
  }

  // Handle strings that may already have a HH:MM UTC or HH:MM +1 pattern
  const plusOneMatch = rawDateStr.match(/(\d{1,2}):(\d{2})\s*(?:\+1|\(\+1\))/);
  if (plusOneMatch) {
    const dateOnly = rawDateStr.match(/(\d{2})[/-](\d{2})[/-](\d{4})/);
    const hm = `${pad2(Number(plusOneMatch[1]))}:${plusOneMatch[2]} +1`;
    return dateOnly ? `${dateOnly[1]}-${dateOnly[2]}-${dateOnly[3]} • ${hm}` : hm;
  }

  const utcTimeMatch = rawDateStr.match(/\b(\d{1,2}):(\d{2})\s*UTC\b/i);
  if (utcTimeMatch) {
    const nextH = (Number(utcTimeMatch[1]) + 1) % 24;
    const dateOnly = rawDateStr.match(/(\d{2})[/-](\d{2})[/-](\d{4})/);
    const hm = `${pad2(nextH)}:${utcTimeMatch[2]} +1`;
    return dateOnly ? `${dateOnly[1]}-${dateOnly[2]}-${dateOnly[3]} • ${hm}` : hm;
  }

  const dateOnly = rawDateStr.match(/(\d{2})[/-](\d{2})[/-](\d{4})/);
  if (dateOnly) {
    return `${dateOnly[1]}-${dateOnly[2]}-${dateOnly[3]}`;
  }
  return rawDateStr.replace(/\bUTC\b/gi, '+1').trim();
}

/**
 * Formats a concours / Tirage date string showing BOTH Universal Time (UTC) and +1 (UTC+1).
 */
export function formatConcoursDualTimeLabel(rawDateStr?: string): string {
  return formatConcoursPlusOneLabel(rawDateStr);
}

/**
 * Formats a match kickoff time strictly in Universal Time (UTC / التوقيت العالمي).
 */
export function formatMatchUtcTime(match: {
  kickoffTimestamp?: number;
  dayTime?: string;
  time?: string;
}): string {
  if (match.kickoffTimestamp && match.kickoffTimestamp > 0) {
    return `${formatUtcShortTime(match.kickoffTimestamp)} UTC`;
  }
  const raw = (match.dayTime || match.time || '').trim();
  if (!raw || raw === '--:--') return '--:-- UTC';
  const hm = raw.match(/(\d{1,2}):(\d{2})/);
  return hm ? `${pad2(Number(hm[1]))}:${hm[2]} UTC` : `${raw} UTC`;
}

/**
 * Formats a match kickoff time strictly in +1 (UTC+1) ONLY.
 */
export function formatMatchUtcPlusOneTime(match: {
  kickoffTimestamp?: number;
  dayTime?: string;
  time?: string;
}): string {
  if (match.kickoffTimestamp && match.kickoffTimestamp > 0) {
    return `${formatUtcPlusOneShortTime(match.kickoffTimestamp)} +1`;
  }
  const raw = (match.dayTime || match.time || '').trim();
  if (!raw || raw === '--:--') return '--:-- +1';
  const hm = raw.match(/(\d{1,2}):(\d{2})/);
  if (!hm) return `${raw} +1`;
  if (/\+1/.test(raw)) return `${pad2(Number(hm[1]))}:${hm[2]} +1`;
  const nextHour = (Number(hm[1]) + 1) % 24;
  return `${pad2(nextHour)}:${hm[2]} +1`;
}

/**
 * Formats a match date strictly in Universal Time (UTC / التوقيت العالمي).
 */
export function formatMatchUtcDate(match: {
  kickoffTimestamp?: number;
  date?: string;
}): string {
  if (match.kickoffTimestamp && match.kickoffTimestamp > 0) {
    return formatUtcDateString(match.kickoffTimestamp);
  }
  return match.date || '';
}

/**
 * Formats a match date strictly in +1 (UTC+1).
 */
export function formatMatchPlusOneDate(match: {
  kickoffTimestamp?: number;
  date?: string;
}): string {
  if (match.kickoffTimestamp && match.kickoffTimestamp > 0) {
    return formatUtcPlusOneDateString(match.kickoffTimestamp);
  }
  return match.date || '';
}

/**
 * React hook returning live ticking Universal Time (UTC / التوقيت العالمي) and UTC+1 (+1) clocks.
 */
export function useUtcClock(intervalMs = 1000): {
  timeUtc: string;
  shortTimeUtc: string;
  dateUtc: string;
  timePlusOne: string;
  shortTimePlusOne: string;
} {
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  useEffect(() => {
    const id = window.setInterval(() => {
      setNowMs(Date.now());
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);

  return {
    timeUtc: formatUtcClock(nowMs),
    shortTimeUtc: formatUtcShortTime(nowMs),
    dateUtc: formatUtcDateString(nowMs),
    timePlusOne: formatUtcPlusOneClock(nowMs),
    shortTimePlusOne: formatUtcPlusOneShortTime(nowMs),
  };
}
