/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeeklyConcours } from '../types/promosport';
import { computeResultSign, parseMatchScore } from './matchLiveService';

export interface SlipSummaryStats {
  doublesCount: number;
  triplesCount: number;
  singlesCount: number;
  hasAnyMatchStarted: boolean;
  liveMatchesCount: number;
  finishedMatchesCount: number;
  correctCount: number;
  errorCount: number;
}

/**
 * Computes persistent slip selection counts (doubles, triples, singles)
 * and real-time / final correct & error counts across live and finished matches.
 */
export function computeSlipSummaryStats(
  selections: Record<number, ('1' | 'X' | '2')[]>,
  concours?: WeeklyConcours | null,
  expectedGrilleNumber?: number
): SlipSummaryStats {
  let doublesCount = 0;
  let triplesCount = 0;
  let singlesCount = 0;

  Object.values(selections || {}).forEach((sel) => {
    if (!Array.isArray(sel) || sel.length === 0) return;
    if (sel.length === 1) singlesCount += 1;
    else if (sel.length === 2) doublesCount += 1;
    else if (sel.length === 3) triplesCount += 1;
  });

  let hasAnyMatchStarted = false;
  let liveMatchesCount = 0;
  let finishedMatchesCount = 0;
  let correctCount = 0;
  let errorCount = 0;

  const canEvaluateConcours =
    Boolean(concours) &&
    (expectedGrilleNumber === undefined || concours!.number === expectedGrilleNumber);

  if (canEvaluateConcours && concours) {
    for (const match of concours.matches) {
      if (match.isDelayed) continue;

      const parsedScore = parseMatchScore(match);
      const isLive = match.status === 'live';
      const isFinished = match.status === 'finished';

      if (isLive) liveMatchesCount += 1;
      if (isFinished) finishedMatchesCount += 1;

      if (isLive || isFinished || parsedScore !== null || match.result !== null) {
        hasAnyMatchStarted = true;
      }

      if (!isLive && !isFinished && parsedScore === null && match.result === null) {
        continue;
      }

      let currentSign: '1' | 'X' | '2' | null = null;
      if (match.result === '1' || match.result === 'X' || match.result === '2') {
        currentSign = match.result;
      } else if (parsedScore) {
        currentSign = computeResultSign(Number(parsedScore.home), Number(parsedScore.away));
      }

      if (!currentSign) continue;

      const userChoices = selections?.[match.id] || [];
      if (userChoices.length === 0) continue;

      if (userChoices.includes(currentSign)) {
        correctCount += 1;
      } else {
        errorCount += 1;
      }
    }
  }

  return {
    doublesCount,
    triplesCount,
    singlesCount,
    hasAnyMatchStarted,
    liveMatchesCount,
    finishedMatchesCount,
    correctCount,
    errorCount,
  };
}
