import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import {hydrateFromExportedBootstrap} from './services/storageService';
import './index.css';

// Register VitePWA Service Worker immediately for Chrome installability, offline & background notifications
registerSW({
  immediate: true,
  onRegisteredSW(_swUrl, registration) {
    if (registration) {
      registration.update().catch(() => {});
      const regWithSync = registration as ServiceWorkerRegistration & {
        periodicSync?: { register: (tag: string, options: { minInterval: number }) => Promise<void> };
      };
      if (regWithSync.periodicSync) {
        regWithSync.periodicSync
          .register('promosport-grille-sync', { minInterval: 15 * 60 * 1000 })
          .catch(() => {});
      }
    }
  },
  onRegisterError() {
    // Silent fallback when running in restricted frame environments
  },
});

const rootEl = document.getElementById('root')!;
void hydrateFromExportedBootstrap().finally(() => {
  createRoot(rootEl).render(<App />);
});

