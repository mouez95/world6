/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { Lock, RefreshCw, Trophy, Users } from 'lucide-react';
import { PromosportGrille } from '../types/promosport';
import { formatConcoursPlusOneLabel } from '../services/timeUtils';

interface TirageFrozenSnapshotCardProps {
  grille: PromosportGrille;
  lang: 'AR' | 'FR';
  getTeamName?: (teamName: string, frName?: string) => string;
  isRefreshingPayouts?: boolean;
  onRefreshPayoutsOnly?: () => void;
}

interface LeagueGroupSpan {
  label: string;
  startRow: number; // 1-based CSS grid row start
  endRow: number;   // 1-based exclusive CSS grid row end
  count: number;
}

const PromosportCircularEmblem: React.FC = () => (
  <svg
    viewBox="0 0 120 112"
    className="w-[66px] h-[62px] sm:w-[88px] sm:h-[82px] shrink-0"
    aria-hidden="true"
  >
    <defs>
      <path id="promoArcTop" d="M 18,52 A 42,42 0 0,1 102,52" />
      <linearGradient id="ballGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="100%" stopColor="#cbd5e1" />
      </linearGradient>
    </defs>

    {/* Arched Arabic Header */}
    <text
      fill="#111827"
      fontSize="12.5"
      fontWeight="900"
      fontFamily="Cairo, sans-serif"
      textAnchor="middle"
    >
      <textPath href="#promoArcTop" startOffset="50%">
        النهوض بالرياضة
      </textPath>
    </text>

    {/* Subtle Decorative Swirl Ring */}
    <circle
      cx="60"
      cy="54"
      r="30"
      fill="none"
      stroke="#9d174d"
      strokeWidth="1.5"
      strokeDasharray="4 3"
      opacity="0.45"
    />

    {/* Classic 1 - X - 2 & Mini Soccer Ball Cluster */}
    <circle cx="40" cy="57" r="11.5" fill="url(#ballGrad)" stroke="#0f172a" strokeWidth="1.4" />
    <polygon points="40,51 44,54 42.5,59 37.5,59 36,54" fill="#0f172a" />
    <line x1="40" y1="51" x2="40" y2="46" stroke="#0f172a" strokeWidth="1" />
    <line x1="44" y1="54" x2="49" y2="52" stroke="#0f172a" strokeWidth="1" />
    <line x1="36" y1="54" x2="31" y2="52" stroke="#0f172a" strokeWidth="1" />

    {/* Red 1 */}
    <circle cx="59" cy="44" r="11" fill="#dc2626" stroke="#ffffff" strokeWidth="1.5" />
    <text
      x="59"
      y="48.5"
      textAnchor="middle"
      fill="#ffffff"
      fontSize="13"
      fontWeight="900"
      fontFamily="Cairo, sans-serif"
    >
      1
    </text>

    {/* Yellow X */}
    <circle cx="77" cy="56" r="11" fill="#facc15" stroke="#ffffff" strokeWidth="1.5" />
    <text
      x="77"
      y="60.5"
      textAnchor="middle"
      fill="#0f172a"
      fontSize="12.5"
      fontWeight="900"
      fontFamily="Cairo, sans-serif"
    >
      X
    </text>

    {/* Blue 2 */}
    <circle cx="59" cy="68" r="10.5" fill="#2563eb" stroke="#ffffff" strokeWidth="1.5" />
    <text
      x="59"
      y="72"
      textAnchor="middle"
      fill="#ffffff"
      fontSize="12.5"
      fontWeight="900"
      fontFamily="Cairo, sans-serif"
    >
      2
    </text>

    {/* PROMOSPORT Wordmark */}
    <text
      x="60"
      y="102"
      textAnchor="middle"
      fill="#0f172a"
      fontSize="13.5"
      fontWeight="900"
      letterSpacing="0.8"
      fontFamily="Cairo, sans-serif"
    >
      PROMOSPORT
    </text>
  </svg>
);

const PromosportBallBadge: React.FC = () => (
  <svg
    viewBox="0 0 88 76"
    className="w-[46px] h-[40px] sm:w-[64px] sm:h-[56px] shrink-0"
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="magentaBall" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fdf4ff" />
        <stop offset="100%" stopColor="#f5d0fe" />
      </linearGradient>
    </defs>
    {/* Soccer Ball */}
    <circle cx="44" cy="24" r="19" fill="url(#magentaBall)" stroke="#86198f" strokeWidth="2.2" />
    <polygon points="44,14 51,19 48.5,27 39.5,27 37,19" fill="#9d174d" />
    <polygon points="44,5 49,9 44,14 39,9" fill="#a21caf" />
    <polygon points="62,19 57,25 51,19 54,12" fill="#a21caf" />
    <polygon points="26,19 31,25 37,19 34,12" fill="#a21caf" />
    <polygon points="33,39 39.5,27 48.5,27 55,39 44,42" fill="#86198f" opacity="0.88" />

    {/* Curved Ribbon Underneath */}
    <rect x="10" y="42" width="68" height="28" rx="6" fill="#ffffff" stroke="#a21caf" strokeWidth="1.5" />
    <text
      x="44"
      y="54"
      textAnchor="middle"
      fill="#a21caf"
      fontSize="10"
      fontWeight="900"
      fontFamily="Cairo, sans-serif"
    >
      PROMO
    </text>
    <text
      x="44"
      y="67"
      textAnchor="middle"
      fill="#86198f"
      fontSize="12"
      fontWeight="900"
      fontFamily="Cairo, sans-serif"
    >
      13 / 13
    </text>
  </svg>
);

const PromosportTerminalIllustration: React.FC = () => (
  <svg
    viewBox="0 0 180 120"
    className="w-[96px] h-[64px] sm:w-[132px] sm:h-[88px] shrink-0"
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="termBody" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#f8fafc" />
        <stop offset="100%" stopColor="#cbd5e1" />
      </linearGradient>
      <linearGradient id="termScreen" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#1e3a8a" />
        <stop offset="100%" stopColor="#0f172a" />
      </linearGradient>
    </defs>

    {/* Soft Ground Shadow */}
    <ellipse cx="92" cy="106" rx="66" ry="8" fill="#0f172a" opacity="0.14" />

    {/* Main Slanted Terminal Printer Body */}
    <polygon points="34,82 96,24 152,42 152,82 104,104 34,94" fill="url(#termBody)" stroke="#475569" strokeWidth="2" />
    <polygon points="96,24 152,42 128,62 72,44" fill="#e2e8f0" stroke="#64748b" strokeWidth="1.5" />

    {/* Blue Keypad / Top Accent */}
    <polygon points="103,29 124,36 112,48 91,41" fill="#2563eb" />
    <polygon points="128,37 144,42 134,53 118,47" fill="#3b82f6" />

    {/* Angled Blue Display Bezel */}
    <polygon points="24,42 82,54 74,98 18,86" fill="#3b82f6" stroke="#1d4ed8" strokeWidth="2" />
    <polygon points="30,48 76,58 69,92 24,81" fill="url(#termScreen)" />

    {/* Screen Lines */}
    <line x1="34" y1="60" x2="66" y2="66" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" opacity="0.85" />
    <line x1="33" y1="68" x2="58" y2="73" stroke="#fde047" strokeWidth="2" strokeLinecap="round" opacity="0.85" />
    <line x1="31" y1="76" x2="61" y2="82" stroke="#34d399" strokeWidth="2" strokeLinecap="round" opacity="0.85" />

    {/* Ticket Slot & Printed Promosport Slip */}
    <polygon points="106,68 144,74 144,90 106,86" fill="#94a3b8" stroke="#475569" strokeWidth="1.4" />
    <line x1="112" y1="74" x2="138" y2="78" stroke="#334155" strokeWidth="1.4" />
    <line x1="112" y1="79" x2="138" y2="83" stroke="#334155" strokeWidth="1.4" />
    <polygon points="84,32 106,14 124,20 102,38" fill="#ffffff" stroke="#a21caf" strokeWidth="1.4" />
    <line x1="94" y1="28" x2="108" y2="19" stroke="#a21caf" strokeWidth="1.5" />
    <line x1="99" y1="31" x2="113" y2="22" stroke="#dc2626" strokeWidth="1.5" />
  </svg>
);

export const TirageFrozenSnapshotCard: React.FC<TirageFrozenSnapshotCardProps> = ({
  grille,
  lang,
  getTeamName,
  isRefreshingPayouts = false,
  onRefreshPayoutsOnly,
}) => {
  const isOfficial =
    grille.status === 'official' &&
    grille.winnersFormatted !== 'قيد التحديد الرسمي';
  const plusOneDateLabel = formatConcoursPlusOneLabel(grille.date);

  const resolvedMatches = useMemo(
    () =>
      grille.matches.slice(0, 13).map((m) => {
        const home = getTeamName
          ? getTeamName(m.homeTeam, m.homeTeamFr)
          : lang === 'AR'
          ? m.homeTeam
          : m.homeTeamFr || m.homeTeam;
        const away = getTeamName
          ? getTeamName(m.awayTeam, m.awayTeamFr)
          : lang === 'AR'
          ? m.awayTeam
          : m.awayTeamFr || m.awayTeam;
        const scoreMatch = String(m.score || '').match(/^(\d+)\s*[-:]\s*(\d+)$/);
        const finalScore = scoreMatch ? `${scoreMatch[1]} - ${scoreMatch[2]}` : '- - -';
        const finalSign: '1' | 'X' | '2' | '-' =
          scoreMatch && m.result ? m.result : scoreMatch ? m.result || '-' : '-';
        const comp =
          lang === 'AR'
            ? m.competition || m.competitionFr || 'مسابقة عالمية'
            : m.competitionFr || m.competition || 'Compétition';
        return {
          id: m.id,
          home,
          away,
          finalScore,
          finalSign,
          comp,
        };
      }),
    [grille.matches, lang, getTeamName]
  );

  // Consolidate consecutive matches sharing the same competition into crisp vertical spans
  const leagueGroups = useMemo<LeagueGroupSpan[]>(() => {
    const groups: LeagueGroupSpan[] = [];
    resolvedMatches.forEach((m, index) => {
      const prev = groups[groups.length - 1];
      if (prev && prev.label === m.comp) {
        prev.endRow = index + 2;
        prev.count += 1;
      } else {
        groups.push({
          label: m.comp,
          startRow: index + 1,
          endRow: index + 2,
          count: 1,
        });
      }
    });
    return groups;
  }, [resolvedMatches]);

  const signCellClass = (sign: '1' | 'X' | '2' | '-') => {
    if (sign === '1') {
      return 'bg-[#dc2626] text-white border-[#991b1b]';
    }
    if (sign === 'X') {
      return 'bg-[#facc15] text-slate-950 border-[#ca8a04]';
    }
    if (sign === '2') {
      return 'bg-[#2563eb] text-white border-[#1e40af]';
    }
    return 'bg-slate-100 text-slate-500 border-slate-300';
  };

  return (
    <div className="space-y-2.5 max-w-3xl mx-auto select-none">
      {/* Compact Frozen Status & Payout Refresh Bar (shown outside the official paper sheet) */}
      <div className="rounded-xl bg-[#1a071d]/95 border border-[#c026d3]/65 px-3 py-2 flex flex-wrap items-center justify-between gap-2 shadow-md">
        <div className="flex items-center gap-2 min-w-0">
          <Lock className="w-4 h-4 text-fuchsia-300 shrink-0" />
          <span className="text-[11px] sm:text-xs font-bold text-fuchsia-100 leading-snug">
            {isOfficial
              ? lang === 'AR'
                ? `القصاصة السابقة رقم ${grille.number} · نتائج ومرابيح رسمية معتمدة`
                : `Tirage N° ${grille.number} · Résultats et gains officiels publiés`
              : lang === 'AR'
              ? `القصاصة السابقة رقم ${grille.number} · النتائج نهائية وبانتظار القيمة المالية والمرابيح`
              : `Tirage N° ${grille.number} · En attente de la publication des gains`}
          </span>
        </div>

        {!isOfficial && onRefreshPayoutsOnly && (
          <button
            type="button"
            onClick={onRefreshPayoutsOnly}
            disabled={isRefreshingPayouts}
            className="min-h-[44px] px-3.5 py-1.5 rounded-xl bg-fuchsia-500/25 hover:bg-fuchsia-500/40 border border-fuchsia-300/70 text-fuchsia-100 font-black text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-60 shrink-0 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingPayouts ? 'animate-spin' : ''}`} />
            <span>{lang === 'AR' ? 'تحديث القيمة المالية والمرابيح' : 'Actualiser les gains'}</span>
          </button>
        )}
      </div>

      {/* ===================================================================== */}
      {/* OFFICIAL PROMOSPORT TUNISIA PAPER POSTER SHEET (WHITE & MAGENTA)     */}
      {/* ===================================================================== */}
      <div
        dir="rtl"
        className="relative w-full bg-white text-slate-950 border-[3px] sm:border-[4px] border-[#9d174d] rounded-xl overflow-hidden shadow-[0_14px_40px_rgba(0,0,0,0.75)] pointer-events-none select-none"
      >
        {/* Subtle Soft Stadium Pitch Watermark at the Bottom */}
        <svg
          viewBox="0 0 800 320"
          preserveAspectRatio="none"
          className="absolute inset-x-0 bottom-0 w-full h-56 sm:h-72 pointer-events-none opacity-[0.22]"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="stadiumGrass" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0" />
              <stop offset="45%" stopColor="#cbd5e1" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#bbf7d0" stopOpacity="0.85" />
            </linearGradient>
          </defs>
          <rect x="0" y="0" width="800" height="320" fill="url(#stadiumGrass)" />
          <path d="M 40,290 Q 400,150 760,290" fill="none" stroke="#94a3b8" strokeWidth="2.5" opacity="0.4" />
          <ellipse cx="400" cy="280" rx="220" ry="38" fill="none" stroke="#86efac" strokeWidth="3" opacity="0.55" />
        </svg>

        {/* ----------------------------------------------------------------- */}
        {/* 1. TOP HEADER BAR: [المسابقة #N] + [DATE/INFO] + [PROMOSPORT LOGO] */}
        {/* ----------------------------------------------------------------- */}
        <div className="relative z-10 flex items-stretch justify-between border-b-[2.5px] border-[#9d174d] bg-white">
          {/* Rightmost Block: Magenta "المسابقة" Header + Large Number */}
          <div className="w-[78px] sm:w-[116px] shrink-0 flex flex-col border-l-[2px] border-[#9d174d]">
            <div className="bg-[#a21caf] text-white text-center py-0.5 sm:py-1 px-1 text-[11px] sm:text-sm font-black tracking-wide">
              {lang === 'AR' ? 'المسابقة' : 'Concours'}
            </div>
            <div className="flex-1 bg-gradient-to-b from-[#d946ef]/80 via-[#c026d3]/75 to-[#a21caf]/80 flex items-center justify-center py-1 sm:py-2 px-1">
              <span
                dir="ltr"
                className="text-3xl sm:text-5xl font-black text-slate-950 tabular-nums leading-none tracking-tight drop-shadow-[0_1px_0_rgba(255,255,255,0.45)]"
              >
                {grille.number}
              </span>
            </div>
          </div>

          {/* Center Date & Official Notice */}
          <div className="flex-1 px-2 sm:px-4 py-1.5 sm:py-2.5 flex flex-col items-center justify-center text-center min-w-0">
            <div className="text-[11px] sm:text-sm font-black text-[#dc2626] leading-snug">
              {lang === 'AR'
                ? 'النتائج الرسمية الكاملة · القصاصة السابقة'
                : 'Résultats officiels complets · Concours précédent'}
            </div>
            <div className="mt-0.5 text-[10px] sm:text-xs font-extrabold text-slate-900 leading-snug">
              {lang === 'AR' ? 'تاريخ القصاصة : ' : 'Date du tirage : '}
              <span dir="ltr" className="font-mono font-black text-slate-950 tabular-nums">
                {plusOneDateLabel}
              </span>
            </div>
            <div className="mt-0.5 text-[9.5px] sm:text-[11px] font-bold text-[#86198f]">
              {lang === 'AR'
                ? 'القصاصة العالمية · 13 مقابلة رسمية'
                : 'Grille Internationale · 13 Matchs officiels'}
            </div>
          </div>

          {/* Leftmost Block: Promosport Circular Emblem */}
          <div className="px-1.5 sm:px-3 py-1 flex items-center justify-center shrink-0">
            <PromosportCircularEmblem />
          </div>
        </div>

        {/* ----------------------------------------------------------------- */}
        {/* 2. CAGNOTTE ABOVE HEADLINE + "القصاصة العالمية عدد X" + LEFT HEADERS */}
        {/* ----------------------------------------------------------------- */}
        <div className="relative z-10 px-2 sm:px-3.5 pt-2 sm:pt-3 pb-1.5 space-y-2">
          {/* Financial Value ABOVE Competition Title ("فوقها القيمة المالية") */}
          <div className="flex items-center justify-center">
            <div className="inline-flex flex-wrap items-center justify-center gap-1.5 sm:gap-3 px-3 sm:px-5 py-1 sm:py-1.5 rounded-lg bg-gradient-to-r from-[#fdf2f8] via-[#ffffff] to-[#ecfdf5] border-2 border-[#a21caf] shadow-sm">
              <span className="text-[11px] sm:text-sm font-black text-[#86198f]">
                {lang === 'AR' ? 'القيمة المالية :' : 'Cagnotte :'}
              </span>
              <span
                dir="ltr"
                className="text-sm sm:text-xl font-black text-[#047857] font-mono tabular-nums tracking-tight"
              >
                {grille.cagnotteFormatted}
              </span>
            </div>
          </div>

          {/* Headline + Left Column Headers Row (aligned strictly with the 13-row grid below) */}
          <div className="grid grid-cols-[20px_minmax(0,1fr)_minmax(0,1fr)_18px_4px_54px_40px] sm:grid-cols-[30px_minmax(0,1fr)_minmax(0,1fr)_26px_8px_86px_58px] items-end gap-0">
            {/* Right/Center Area spanning cols 1..4: Ball Emblem + "القصاصة العالمية عدد N" */}
            <div className="col-span-4 flex items-center justify-center sm:justify-start gap-1.5 sm:gap-3 pl-1 pb-0.5">
              <PromosportBallBadge />
              <h2 className="text-[13px] min-[390px]:text-sm sm:text-[23px] font-black text-[#86198f] leading-tight tracking-tight">
                {lang === 'AR'
                  ? `القصاصة العالمية عدد ${grille.number}`
                  : `Grille Internationale N° ${grille.number}`}
              </h2>
            </div>

            {/* Spacer col 5 */}
            <div />

            {/* Col 6 Header (Second from Left): النتيجة */}
            <div className="h-[36px] sm:h-[44px] bg-[#a21caf] border border-[#701a75] text-white font-black text-[11px] sm:text-sm flex items-center justify-center text-center leading-tight px-0.5">
              {lang === 'AR' ? 'النتيجة' : 'Score'}
            </div>

            {/* Col 7 Header (Far Left): العمود الفائز */}
            <div className="h-[36px] sm:h-[44px] bg-[#a21caf] border border-r-0 border-[#701a75] text-white font-black text-[9.5px] sm:text-xs flex items-center justify-center text-center leading-tight px-0.5">
              {lang === 'AR' ? 'العمود الفائز' : 'Colonne'}
            </div>
          </div>
        </div>

        {/* ----------------------------------------------------------------- */}
        {/* 3. MAIN 13-MATCH TABLE + LEFT-SIDE RESULTS & WINNING SIGNS         */}
        {/* ----------------------------------------------------------------- */}
        <div className="relative z-10 px-1.5 sm:px-3.5 pb-3">
          <div className="grid grid-cols-[20px_minmax(0,1fr)_minmax(0,1fr)_18px_4px_54px_40px] sm:grid-cols-[30px_minmax(0,1fr)_minmax(0,1fr)_26px_8px_86px_58px]">
            {/* Left Side: Main Framed Teams + Number + League Strip (Cols 1..4) */}
            {/* Rendered row-by-row in strict 1..13 grid */}
            {resolvedMatches.map((m, idx) => {
              const rowNum = idx + 1;
              const isLast = idx === resolvedMatches.length - 1;
              const rowBg = idx % 2 === 0 ? 'bg-white' : 'bg-[#fdf4ff]/60';
              const borderB = isLast ? 'border-b-2 border-[#1e293b]' : 'border-b border-slate-300';
              const borderT = idx === 0 ? 'border-t-2 border-[#1e293b]' : '';

              return (
                <React.Fragment key={m.id}>
                  {/* Col 1: Match Index 1..13 (Far Right) */}
                  <div
                    style={{ gridColumn: '1 / 2', gridRow: `${rowNum} / ${rowNum + 1}` }}
                    className={`min-h-[38px] sm:min-h-[46px] flex items-center justify-center text-[11px] sm:text-sm font-black text-[#9d174d] tabular-nums border-r-2 border-l border-[#1e293b] border-l-slate-300 ${rowBg} ${borderT} ${borderB}`}
                  >
                    {m.id}
                  </div>

                  {/* Col 2: Home Team (Right-Center, enlarged & ultra-legible) */}
                  <div
                    style={{ gridColumn: '2 / 3', gridRow: `${rowNum} / ${rowNum + 1}` }}
                    className={`min-h-[38px] sm:min-h-[46px] flex items-center justify-start px-1.5 sm:px-3 py-1 text-[12.5px] min-[390px]:text-[13.5px] sm:text-[16.5px] font-black text-slate-950 leading-[1.2] border-l border-slate-200 ${rowBg} ${borderT} ${borderB}`}
                  >
                    <span className="break-words">{m.home}</span>
                  </div>

                  {/* Col 3: Away Team (Left-Center, enlarged & ultra-legible) */}
                  <div
                    style={{ gridColumn: '3 / 4', gridRow: `${rowNum} / ${rowNum + 1}` }}
                    className={`min-h-[38px] sm:min-h-[46px] flex items-center justify-end px-1.5 sm:px-3 py-1 text-[12.5px] min-[390px]:text-[13.5px] sm:text-[16.5px] font-black text-slate-950 leading-[1.2] border-l border-slate-300 ${rowBg} ${borderT} ${borderB}`}
                  >
                    <span className="break-words text-left">{m.away}</span>
                  </div>

                  {/* Col 5: Clean White Gap Between Table & Left Result Columns */}
                  <div
                    style={{ gridColumn: '5 / 6', gridRow: `${rowNum} / ${rowNum + 1}` }}
                    className="bg-white"
                  />

                  {/* Col 6: Final Score (النتيجة) on the Left — enlarged & crisp */}
                  <div
                    style={{ gridColumn: '6 / 7', gridRow: `${rowNum} / ${rowNum + 1}` }}
                    className={`min-h-[38px] sm:min-h-[46px] flex items-center justify-center px-0.5 bg-[#f8fafc] border-r border-l border-slate-800 ${
                      idx === 0 ? 'border-t-2 border-t-slate-900' : ''
                    } ${isLast ? 'border-b-2 border-b-slate-900' : 'border-b border-b-slate-300'}`}
                  >
                    <span
                      dir="ltr"
                      className={`font-mono font-black text-[13px] min-[390px]:text-[14.5px] sm:text-[18.5px] tracking-tight tabular-nums ${
                        m.finalScore !== '- - -' ? 'text-slate-950' : 'text-slate-400'
                      }`}
                    >
                      {m.finalScore}
                    </span>
                  </div>

                  {/* Col 7: Winning Sign 1/X/2 (العمود الفائز) on the Far Left */}
                  <div
                    style={{ gridColumn: '7 / 8', gridRow: `${rowNum} / ${rowNum + 1}` }}
                    className={`min-h-[38px] sm:min-h-[46px] flex items-center justify-center p-0.5 sm:p-1 bg-white border-l-2 border-l-slate-900 ${
                      idx === 0 ? 'border-t-2 border-t-slate-900' : ''
                    } ${isLast ? 'border-b-2 border-b-slate-900' : 'border-b border-b-slate-300'}`}
                  >
                    <span
                      className={`w-full h-full min-h-[26px] sm:min-h-[32px] rounded-[4px] border flex items-center justify-center font-black text-[13px] sm:text-base tabular-nums ${signCellClass(
                        m.finalSign
                      )}`}
                    >
                      {m.finalSign}
                    </span>
                  </div>
                </React.Fragment>
              );
            })}

            {/* Col 4: Vertical Merged League Strips (spanning consecutive matches of same league) */}
            {leagueGroups.map((group, gIdx) => {
              const isFirstGroup = gIdx === 0;
              const isLastGroup = gIdx === leagueGroups.length - 1;
              return (
                <div
                  key={`${group.label}-${group.startRow}`}
                  style={{
                    gridColumn: '4 / 5',
                    gridRow: `${group.startRow} / ${group.endRow}`,
                  }}
                  className={`min-h-0 h-full w-full bg-[#e2e8f0] border-l-2 border-slate-900 border-r border-slate-400 flex items-center justify-center overflow-hidden px-0.5 py-1 ${
                    isFirstGroup ? 'border-t-2 border-t-slate-900' : 'border-t border-t-slate-700'
                  } ${isLastGroup ? 'border-b-2 border-b-slate-900' : ''}`}
                >
                  <span
                    style={{
                      writingMode: 'vertical-rl',
                      transform: 'rotate(180deg)',
                    }}
                    className={`font-black text-[#1e293b] text-center leading-none whitespace-nowrap overflow-hidden text-ellipsis max-h-full ${
                      group.count === 1
                        ? 'text-[6.5px] sm:text-[8px]'
                        : group.count === 2
                        ? 'text-[7.5px] sm:text-[9.5px]'
                        : 'text-[8.5px] sm:text-[11px]'
                    }`}
                  >
                    {group.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* ----------------------------------------------------------------- */}
        {/* 4. BOTTOM PAYOUTS & WINNERS TABLES (GOLD BORDERS, BLACK BG, SHINY SILVER TEXT) */}
        {/* ----------------------------------------------------------------- */}
        <div className="relative z-10 px-2 sm:px-3.5 pt-1.5 pb-2.5">
          <div className="grid grid-cols-[minmax(0,1.65fr)_minmax(0,1fr)] gap-2 sm:gap-3 items-stretch">
            {/* Right Summary Box: أيقونة مرابيح القصاصة */}
            <div className="flex flex-col rounded-xl bg-[#04060b] border-[2.5px] border-[#facc15] shadow-[0_0_16px_rgba(250,204,21,0.38),inset_0_0_14px_rgba(250,204,21,0.1)] overflow-hidden">
              {/* Golden-trimmed Header with Trophy Icon & Shiny Silver Title */}
              <div className="flex items-center justify-center gap-1.5 px-2 py-1.5 bg-gradient-to-r from-amber-500/20 via-black to-amber-500/20 border-b border-amber-400/60">
                <Trophy className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300 shrink-0 drop-shadow-[0_0_6px_rgba(251,191,36,0.85)]" />
                <span className="font-black text-xs sm:text-base text-[#f8fafc] tracking-wide [text-shadow:0_0_10px_rgba(255,255,255,0.6),0_1px_0_#94a3b8]">
                  {lang === 'AR' ? 'مرابيح القصاصة' : 'Gains du Concours'}
                </span>
              </div>

              <div className="flex-1 flex flex-col divide-y divide-amber-400/35 text-[11px] sm:text-xs">
                <div className="flex items-center justify-between gap-1.5 px-2.5 py-2 min-h-[34px] sm:min-h-[38px]">
                  <span className="font-black text-[#e2e8f0] [text-shadow:0_0_8px_rgba(241,245,249,0.45)] truncate">
                    {lang === 'AR' ? '13 إجابة صحيحة' : '13 bons résultats'}
                  </span>
                  <span
                    dir="ltr"
                    className={`font-mono font-black text-xs sm:text-sm tabular-nums shrink-0 ${
                      !isOfficial
                        ? 'text-amber-300 [text-shadow:0_0_8px_rgba(252,211,77,0.5)]'
                        : grille.isRollover
                        ? 'text-[#f8fafc] [text-shadow:0_0_10px_rgba(255,255,255,0.65)]'
                        : 'text-[#ffffff] [text-shadow:0_0_12px_rgba(255,255,255,0.8),0_1px_1px_#94a3b8]'
                    }`}
                  >
                    {grille.prizePerWinnerFormatted}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-1.5 px-2.5 py-2 min-h-[34px] sm:min-h-[38px] bg-white/[0.03]">
                  <span className="font-black text-[#e2e8f0] [text-shadow:0_0_8px_rgba(241,245,249,0.45)] truncate">
                    {lang === 'AR' ? 'القيمة المالية' : 'Cagnotte'}
                  </span>
                  <span
                    dir="ltr"
                    className="font-mono font-black text-xs sm:text-sm text-[#ffffff] tabular-nums shrink-0 [text-shadow:0_0_12px_rgba(255,255,255,0.8),0_1px_1px_#94a3b8]"
                  >
                    {grille.cagnotteFormatted}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-1.5 px-2.5 py-2 min-h-[34px] sm:min-h-[38px]">
                  <span className="font-black text-[#cbd5e1] [text-shadow:0_0_6px_rgba(226,232,240,0.4)] shrink-0">
                    {lang === 'AR' ? 'الحالة' : 'Statut'}
                  </span>
                  <span className="font-black text-[#f8fafc] truncate [text-shadow:0_0_10px_rgba(255,255,255,0.55)]">
                    {!isOfficial
                      ? lang === 'AR'
                        ? 'بانتظار الإعلان الرسمي'
                        : 'En attente officielle'
                      : grille.isRollover
                      ? lang === 'AR'
                        ? 'ترحيل الجائزة للقادم'
                        : 'Report vers prochain tirage'
                      : lang === 'AR'
                      ? 'نتائج ومرابيح نهائية'
                      : 'Gains officiels confirmés'}
                  </span>
                </div>
              </div>
            </div>

            {/* Left Summary Box: أيقونة عدد الفائزين */}
            <div className="flex flex-col rounded-xl bg-[#04060b] border-[2.5px] border-[#facc15] shadow-[0_0_16px_rgba(250,204,21,0.38),inset_0_0_14px_rgba(250,204,21,0.1)] overflow-hidden">
              {/* Golden-trimmed Header with Users Icon & Shiny Silver Title */}
              <div className="flex items-center justify-center gap-1.5 px-2 py-1.5 bg-gradient-to-r from-amber-500/20 via-black to-amber-500/20 border-b border-amber-400/60">
                <Users className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300 shrink-0 drop-shadow-[0_0_6px_rgba(251,191,36,0.85)]" />
                <span className="font-black text-xs sm:text-base text-[#f8fafc] tracking-wide [text-shadow:0_0_10px_rgba(255,255,255,0.6),0_1px_0_#94a3b8]">
                  {lang === 'AR' ? 'عدد الفائزين' : 'Gagnants'}
                </span>
              </div>

              <div className="flex-1 flex flex-col divide-y divide-amber-400/35 text-[11px] sm:text-xs text-center">
                <div className="flex items-center justify-center px-2 py-2 min-h-[34px] sm:min-h-[38px]">
                  <span className="font-black text-xs sm:text-base text-[#ffffff] tabular-nums [text-shadow:0_0_12px_rgba(255,255,255,0.85),0_1px_1px_#94a3b8]">
                    {grille.winnersFormatted}
                  </span>
                </div>

                <div className="flex items-center justify-center px-2 py-2 min-h-[34px] sm:min-h-[38px] bg-white/[0.03]">
                  <span className="font-black text-[#f1f5f9] tabular-nums [text-shadow:0_0_10px_rgba(255,255,255,0.65)]">
                    {lang === 'AR' ? `مسابقة عدد ${grille.number}` : `Concours N° ${grille.number}`}
                  </span>
                </div>

                <div className="flex items-center justify-center px-2 py-2 min-h-[34px] sm:min-h-[38px]">
                  <span className="font-black text-[#e2e8f0] [text-shadow:0_0_8px_rgba(241,245,249,0.5)]">
                    {isOfficial
                      ? lang === 'AR'
                        ? 'معتمد رسمياً'
                        : 'Officiel'
                      : lang === 'AR'
                      ? 'قيد التحديد'
                      : 'En cours'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ----------------------------------------------------------------- */}
        {/* 5. BOTTOM BRANDING & PROMOSPORT TERMINAL ARTWORK (AS IN POSTER)   */}
        {/* ----------------------------------------------------------------- */}
        <div className="relative z-10 px-2.5 sm:px-5 pt-1.5 pb-3 flex items-end justify-between gap-2 sm:gap-4">
          {/* Right Branding Block */}
          <div className="flex-1 text-center sm:text-right flex flex-col items-center justify-end pb-1">
            <div className="text-base sm:text-2xl font-black text-[#dc2626] leading-none">
              {lang === 'AR' ? 'البروموسبور' : 'PROMOSPORT'}
            </div>
            <div className="text-[9.5px] sm:text-xs font-extrabold text-slate-900 mt-1">
              {lang === 'AR'
                ? 'دعم متواصل للرياضة الوطنية'
                : 'Soutien continu au sport national'}
            </div>
            <div className="text-xs sm:text-base font-black text-[#dc2626] mt-1 sm:mt-1.5">
              {lang === 'AR' ? 'إلعب وإربح ونفع بلادك' : 'Jouez, gagnez et soutenez votre pays'}
            </div>
          </div>

          {/* Left Artwork Block: Promosport Wordmark + Bordered Terminal Machine */}
          <div className="flex flex-col items-center shrink-0">
            <div className="text-center mb-1">
              <div className="text-sm sm:text-lg font-black text-[#dc2626] leading-none">
                {lang === 'AR' ? 'البروموسبور' : 'PROMOSPORT'}
              </div>
              <div className="text-[8.5px] sm:text-[10px] font-bold text-slate-900 mt-0.5">
                {lang === 'AR' ? 'دعم متواصل للرياضة الوطنية' : 'Sport national'}
              </div>
            </div>
            <div className="rounded-xl border-2 border-[#a21caf] bg-white/95 px-2 py-1 shadow-sm flex items-center justify-center">
              <PromosportTerminalIllustration />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
