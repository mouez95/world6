/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Trash2,
  Edit3,
  Save,
  Trophy,
  Check,
  ChevronDown,
  ChevronUp,
  Receipt,
  Calendar,
  LayoutGrid,
  Clock,
} from 'lucide-react';
import { UserBetSlip, WeeklyConcours } from '../types/promosport';
import { MbLogo } from './MbLogo';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { audioService } from '../services/audioService';
import { calculatePromosportPrice } from '../services/pricingService';
import { computeSlipSummaryStats } from '../services/slipStatsService';
import { SlipSummaryBadges } from './SlipSummaryBadges';
import { formatConcoursPlusOneLabel, formatUtcPlusOneClock, useUtcClock } from '../services/timeUtils';
import { LanguageToggleButton } from './LanguageToggleButton';
import confetti from 'canvas-confetti';

interface SavedSlipFullPageViewProps {
  slip: UserBetSlip;
  concours: WeeklyConcours;
  lang: 'AR' | 'FR';
  onBackToSlips: () => void;
  onBackToGrille: () => void;
  onUpdateSlip: (updatedSlip: UserBetSlip) => void;
  onDeleteSlip: (slipId: string) => void;
  getTeamName: (teamName: string, frName?: string) => string;
  isKickoffStarted?: boolean;
  columnRate?: number;
  baseFee?: number;
  goalFlashMatchIds?: Record<number, number>;
  onChangeLang?: (lang: 'AR' | 'FR') => void;
}

export const SavedSlipFullPageView: React.FC<SavedSlipFullPageViewProps> = ({
  slip,
  concours,
  lang,
  onBackToSlips,
  onBackToGrille,
  onUpdateSlip,
  onDeleteSlip,
  getTeamName,
  isKickoffStarted = false,
  columnRate = 0.150,
  baseFee = 0.250,
  goalFlashMatchIds = {},
  onChangeLang,
}) => {
  // Toggle for Floating Shaded-Black Glass Saved Slip Ribbon (إظهار وإخفاء شريط القصاصة المسجلة يدوياً)
  const [isGrandPrizeOpen, setIsGrandPrizeOpen] = useState<boolean>(true);
  const { timePlusOne } = useUtcClock(1000);

  // Editing mode state (allows modifying choices directly on this full page)
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedSelections, setEditedSelections] = useState<Record<number, ('1' | 'X' | '2')[]>>(() => ({
    ...slip.selections,
  }));
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);

  // Floating glass height measurement ref
  const floatingRibbonRef = useRef<HTMLDivElement>(null);
  const [initialRibbonHeight, setInitialRibbonHeight] = useState<number>(216);

  const measureRibbonHeight = useCallback(() => {
    if (floatingRibbonRef.current) {
      const h = floatingRibbonRef.current.offsetHeight;
      if (h > 0) {
        setInitialRibbonHeight((prev) => (prev !== h ? h : prev));
      }
    }
  }, []);

  useEffect(() => {
    const rafId = window.requestAnimationFrame(measureRibbonHeight);
    window.addEventListener('resize', measureRibbonHeight);
    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && floatingRibbonRef.current) {
      observer = new ResizeObserver(measureRibbonHeight);
      observer.observe(floatingRibbonRef.current);
    }
    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('resize', measureRibbonHeight);
      observer?.disconnect();
    };
  }, [measureRibbonHeight]);

  const handleToggleRibbon = () => {
    audioService.playClick();
    setIsGrandPrizeOpen((prev) => !prev);
  };

  // Toggle selection when editing
  const handleToggleSelection = (matchId: number, sign: '1' | 'X' | '2') => {
    if (isKickoffStarted) return;
    audioService.playClick();
    setEditedSelections((prev) => {
      const current = prev[matchId] || [];
      let updated: ('1' | 'X' | '2')[];
      if (current.includes(sign)) {
        updated = current.filter((s) => s !== sign);
        if (updated.length === 0) {
          updated = [sign];
        }
      } else {
        updated = [...current, sign];
      }
      return { ...prev, [matchId]: updated };
    });
  };

  // Calculate stats on edited or saved selections
  const activeSelections = isEditing ? editedSelections : slip.selections;

  let countDoubles = 0;
  let countTriples = 0;
  Object.values(activeSelections).forEach((sel) => {
    if (sel && sel.length > 0) {
      if (sel.length === 2) countDoubles++;
      if (sel.length === 3) countTriples++;
    }
  });

  const pricing = calculatePromosportPrice(countDoubles, countTriples, columnRate, baseFee);
  const slipStats = computeSlipSummaryStats(activeSelections, concours, slip.grilleNumber);

  // Save modified slip
  const handleSaveModifiedSlip = () => {
    if (isKickoffStarted) return;
    audioService.playClick();
    const updatedSlip: UserBetSlip = {
      ...slip,
      selections: editedSelections,
      betType: countTriples > 0 ? 'triple' : countDoubles > 0 ? 'double' : 'single',
      totalCombinations: pricing.combinations,
      totalCostDt: pricing.priceTnd,
      updatedAt: `${formatUtcPlusOneClock()} +1`,
    };

    onUpdateSlip(updatedSlip);
    audioService.playChime();
    confetti({
      particleCount: 40,
      spread: 60,
      colors: ['#f1b816', '#38bdf8', '#10b981'],
    });

    setIsEditing(false);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 2500);
  };

  const displaySlipName =
    lang === 'AR'
      ? slip.name.replace(/^Fiche N°\s*/i, 'قصاصة مسجلة رقم ')
      : slip.name.replace(/^قصاصة مسجلة رقم\s*/i, 'Fiche N° ');

  return (
    <div
      dir={lang === 'AR' ? 'rtl' : 'ltr'}
      className="relative flex flex-col h-full bg-[#030918] text-white animate-fade-in overflow-hidden select-none"
    >

      {/* 1. TOP HEADER NAVIGATION BAR: القصاصات + القصاصة + تعديل/حفظ + فسخ مع بعضهم بالعرض في نفس الشريط (+30%) */}
      <div className="relative shrink-0 px-2 sm:px-4 pt-[max(0.5rem,env(safe-area-inset-top))] pb-2 sm:py-2.5 bg-gradient-to-r from-[#040c1e] via-[#091a38] to-[#040c1e] border-b border-sky-400/50 shadow-lg z-50">
        <div className="flex flex-nowrap items-center justify-between gap-1.5 sm:gap-2.5 w-full">
          {/* القصاصات / Fiches */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToSlips();
            }}
            className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-[#0e2246] hover:bg-[#15346a] border border-sky-400 text-cyan-300 hover:text-white font-black text-[13px] sm:text-[15px] transition-all active:scale-95 shadow-md cursor-pointer whitespace-nowrap"
          >
            <ArrowRight className={`w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] text-cyan-300 shrink-0 ${lang === 'FR' ? 'rotate-180' : ''}`} />
            <span>{lang === 'AR' ? 'القصاصات' : 'Fiches'}</span>
          </button>

          {/* القصاصة / Grille */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToGrille();
            }}
            className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-sky-600/30 to-blue-700/40 hover:from-sky-500 hover:to-blue-600 border border-sky-400 text-sky-200 hover:text-white font-black text-[13px] sm:text-[15px] transition-all active:scale-95 shadow-md cursor-pointer whitespace-nowrap"
          >
            <LayoutGrid className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] text-yellow-300 shrink-0" />
            <span>{lang === 'AR' ? 'القصاصة' : 'Grille'}</span>
          </button>

          {/* تعديل / حفظ */}
          {!isKickoffStarted && (!isEditing ? (
            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                setIsEditing(true);
              }}
              className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-[13px] sm:text-[15px] transition-all shadow-[0_0_12px_rgba(241,184,22,0.65)] cursor-pointer active:scale-95 whitespace-nowrap"
            >
              <Edit3 className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] shrink-0" />
              <span>{lang === 'AR' ? 'تعديل' : 'Modifier'}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSaveModifiedSlip}
              className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-black font-black text-[13px] sm:text-[15px] transition-all shadow-[0_0_14px_rgba(16,185,129,0.85)] cursor-pointer active:scale-95 whitespace-nowrap"
            >
              <Save className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] shrink-0" />
              <span>{lang === 'AR' ? 'حفظ' : 'Valider'}</span>
            </button>
          ))}

          {/* فسخ */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onDeleteSlip(slip.id);
            }}
            className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-red-600/35 hover:bg-red-600 border border-red-400 text-red-100 hover:text-white font-black text-[13px] sm:text-[15px] transition-all active:scale-95 cursor-pointer shadow-md whitespace-nowrap"
            title={lang === 'AR' ? 'فسخ القصاصة' : 'Supprimer la fiche'}
          >
            <Trash2 className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] shrink-0" />
            <span>{lang === 'AR' ? 'فسخ' : 'Suppr.'}</span>
          </button>
        </div>
      </div>

      {/* Save Success Notice */}
      {saveSuccessNotice && (
        <div className="shrink-0 p-2 bg-emerald-950/95 border-b border-emerald-400 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-fade-in z-30">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{lang === 'AR' ? 'تم حفظ تعديل القصاصة بنجاح!' : 'Fiche mise à jour avec succès !'}</span>
        </div>
      )}

      {/* 2. VIEWPORT WRAPPER: ALL MATCHES PASS UNDERNEATH THE SHADED-BLACK GLASS SAVED SLIP RIBBON */}
      <div className="relative flex-1 overflow-hidden">

        {/* COMPACT FLOATING REOPEN PILL WHEN MANUALLY HIDDEN */}
        {!isGrandPrizeOpen && (
          <div className="absolute top-1.5 inset-x-0 z-40 flex items-center justify-center gap-2 pointer-events-none px-2">
            <button
              type="button"
              aria-expanded={false}
              onClick={handleToggleRibbon}
              className="pointer-events-auto min-h-[40px] px-4 py-1.5 rounded-full backdrop-blur-lg bg-black/85 hover:bg-black/95 border-2 border-yellow-400/90 text-yellow-300 font-black text-xs shadow-[0_6px_22px_rgba(0,0,0,0.8)] flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all whitespace-nowrap"
              title={lang === 'AR' ? 'النقر لإظهار شريط القصاصة المسجلة' : 'Afficher le bandeau de la fiche'}
            >
              <Trophy className="w-4 h-4 text-yellow-300 shrink-0" />
              <span>{lang === 'AR' ? 'إظهار الجائزة' : 'Afficher Cagnotte'}</span>
              <ChevronDown className="w-4 h-4 text-yellow-300 shrink-0" />
            </button>
            {onChangeLang && (
              <div className="pointer-events-auto">
                <LanguageToggleButton lang={lang} onChangeLang={onChangeLang} compact />
              </div>
            )}
          </div>
        )}

        {/* FLOATING SHADED-BLACK GLASS SAVED SLIP RIBBON (فوق هياكل وأسماء ونتائج المباريات بخلفية سوداء مضللة دائماً) */}
        <div
          ref={floatingRibbonRef}
          className={`absolute top-0 inset-x-0 z-40 px-1.5 sm:px-3 pt-1.5 pb-1 transition-all duration-200 ease-out ${
            isGrandPrizeOpen
              ? 'translate-y-0 opacity-100 pointer-events-none'
              : '-translate-y-4 opacity-0 pointer-events-none'
          }`}
          aria-hidden={!isGrandPrizeOpen}
        >
          <div
            className={`relative rounded-2xl backdrop-blur-lg bg-gradient-to-b from-black/90 via-black/82 to-black/88 border-2 border-yellow-400/85 shadow-[0_14px_36px_rgba(0,0,0,0.88),inset_0_0_20px_rgba(255,255,255,0.08)] px-2.5 sm:px-4 py-2.5 space-y-2.5 ${
              isGrandPrizeOpen ? 'pointer-events-auto' : 'pointer-events-none'
            }`}
          >
            {/* Top Metadata Line + Language Toggle + إخفاء الجائزة Toggle inside the Shaded-Black Glass Ribbon */}
            <div className="flex items-start justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 min-w-0">
                <MbLogo size="sm" showLaser={true} />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-lg bg-yellow-400 text-black font-black text-xs shadow-sm">
                      {displaySlipName}
                    </span>
                    <span className="text-[11px] font-mono text-cyan-300 font-bold">
                      {lang === 'AR' ? `مسابقة #${slip.grilleNumber}` : `Concours #${slip.grilleNumber}`}
                    </span>
                  </div>
                  <div className="text-[10.5px] text-gray-200 flex flex-wrap items-center gap-1.5 mt-0.5 font-medium">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-yellow-400 shrink-0" />
                      <span>{lang === 'AR' ? 'تاريخ التعمير:' : 'Créée le :'} {slip.createdAt}</span>
                    </span>
                    <span className="font-mono text-[10px] px-1.5 py-0.5 rounded-md bg-amber-500/15 border border-amber-400/50 inline-flex items-center gap-1 tabular-nums text-amber-200" dir="ltr">
                      <Clock className="w-3 h-3 text-amber-300" />
                      <span>{timePlusOne} +1</span>
                    </span>
                    <span className="text-[10px] text-yellow-200/90 font-mono" dir="ltr">
                      ({formatConcoursPlusOneLabel(concours.closingTimeStr || concours.fullDateFormatted)})
                    </span>
                  </div>
                </div>
              </div>

              {/* Language Switch + Hide Ribbon Button */}
              <div className="flex items-center gap-1.5 shrink-0">
                {onChangeLang && (
                  <LanguageToggleButton lang={lang} onChangeLang={onChangeLang} compact />
                )}
                <button
                  type="button"
                  aria-expanded={true}
                  onClick={handleToggleRibbon}
                  className="shrink-0 min-h-[38px] flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl bg-black/70 hover:bg-black/90 border border-yellow-400/85 text-yellow-300 font-black text-[11px] sm:text-xs shadow-[0_0_12px_rgba(241,184,22,0.35)] cursor-pointer active:scale-95 transition-all whitespace-nowrap"
                  title={lang === 'AR' ? 'النقر لإخفاء شريط القصاصة المسجلة' : 'Masquer le bandeau'}
                >
                  <Trophy className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
                  <span>{lang === 'AR' ? 'إخفاء الجائزة' : 'Masquer'}</span>
                  <ChevronUp className="w-3.5 h-3.5 shrink-0" />
                </button>
              </div>
            </div>

            {/* CENTERED UNIFIED +20% ENLARGED CARD: الجائزة الكبرى + ثمن القصاصة متجاوران في أيقونة واحدة في الوسط */}
            <div className="flex justify-center w-full">
              <div className="inline-flex items-center justify-center gap-3 sm:gap-5 px-3.5 sm:px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500/30 via-yellow-400/20 to-emerald-500/30 border-2 border-yellow-300/90 shadow-[0_0_22px_rgba(241,184,22,0.45),inset_0_1px_0_rgba(255,255,255,0.2)] max-w-full">
                {/* الجائزة الكبرى (+20%) */}
                <div className={`flex items-center gap-2 sm:gap-2.5 min-w-0 ${lang === 'AR' ? 'text-right' : 'text-left'}`}>
                  <Trophy className="w-6 h-6 text-yellow-300 shrink-0 drop-shadow-[0_0_8px_rgba(250,204,21,0.75)]" />
                  <div className="min-w-0">
                    <span className="text-[10.5px] sm:text-xs font-black text-yellow-200 block leading-tight uppercase whitespace-nowrap">
                      {lang === 'AR' ? 'الجائزة الكبرى' : 'CAGNOTTE'}
                    </span>
                    <span className="font-mono text-sm sm:text-lg font-black text-white tracking-wider tabular-nums drop-shadow-[0_0_8px_#f1b816] whitespace-nowrap" dir="ltr">
                      {concours.cagnotteEstimate}
                    </span>
                  </div>
                </div>

                <div className="h-9 w-px bg-yellow-300/50 shrink-0" />

                {/* ثمن القصاصة (+20%) */}
                <div className={`flex items-center gap-2 sm:gap-2.5 min-w-0 ${lang === 'AR' ? 'text-right' : 'text-left'}`}>
                  <Receipt className="w-6 h-6 text-emerald-300 shrink-0 drop-shadow-[0_0_8px_rgba(16,185,129,0.65)]" />
                  <div className="min-w-0">
                    <span className="text-[10.5px] sm:text-xs font-black text-emerald-200 block leading-tight whitespace-nowrap">
                      {lang === 'AR' ? 'ثمن القصاصة' : 'PRIX FICHE'}
                    </span>
                    <span className="font-mono text-sm sm:text-lg font-black text-emerald-300 tabular-nums whitespace-nowrap" dir="ltr">
                      {pricing.priceTnd.toFixed(3)} DT
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* FULL-WIDTH CENTERED ROWS: الثنائيات والثلاثيات والفردي + الأخطاء والصحيحة بعرض الصفحة */}
            <SlipSummaryBadges stats={slipStats} lang={lang} fullWidth />
          </div>
        </div>

        {/* SCROLLABLE 13-MATCH CONTAINER (تمر جميع هياكل وأسماء ونتائج المباريات تحت الشريط الأسود المظلل الزجاجي) */}
        <div
          className="relative z-0 isolate h-full overflow-y-auto overflow-x-hidden overscroll-contain [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
          style={{
            WebkitOverflowScrolling: 'touch',
          }}
        >
          <div
            className="px-1 sm:px-2 pb-6 space-y-4"
            style={{
              paddingTop: `${isGrandPrizeOpen ? initialRibbonHeight + 12 : 54}px`,
            }}
          >
            {concours.matches.map((match) => {
              const userChoices = activeSelections[match.id] || [];
              const justScoredGoal = Boolean(goalFlashMatchIds[match.id]);

              return (
                <div
                  id={`slip-match-${match.id}`}
                  key={match.id}
                  className="relative w-full"
                  dir="ltr"
                >
                  <PinterestScoreboardCard
                    match={match}
                    lang={lang}
                    mode="slip"
                    isBettingLocked={isKickoffStarted}
                    slipChoices={userChoices}
                    isEditingSlip={isEditing}
                    onToggleSelection={handleToggleSelection}
                    getTeamName={getTeamName}
                    justScoredGoal={justScoredGoal}
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
