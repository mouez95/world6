/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CheckCircle2, XCircle, Layers } from 'lucide-react';
import { SlipSummaryStats } from '../services/slipStatsService';

interface SlipSummaryBadgesProps {
  stats: SlipSummaryStats;
  lang: 'AR' | 'FR';
  compact?: boolean;
  fullWidth?: boolean;
}

export const SlipSummaryBadges: React.FC<SlipSummaryBadgesProps> = ({
  stats,
  lang,
  compact = false,
  fullWidth = false,
}) => {
  const isWaitingBeforeKickoff = !stats.hasAnyMatchStarted;

  return (
    <div
      className={`flex flex-col ${fullWidth ? 'items-center w-full' : 'items-start w-full'} gap-1.5`}
      dir={lang === 'AR' ? 'rtl' : 'ltr'}
    >
      {/* Row 1: Doubles, Triples, Singles horizontally side-by-side inside the same unified icon */}
      <div
        className={`${
          fullWidth
            ? 'w-full flex flex-wrap items-center justify-around sm:justify-center gap-2 sm:gap-6 px-3 py-1.5 text-[11px] sm:text-xs'
            : `inline-flex flex-wrap items-center gap-1.5 sm:gap-2.5 ${
                compact ? 'px-2 py-1 text-[10px]' : 'px-2.5 py-1 text-[10.5px] sm:text-xs'
              }`
        } rounded-xl bg-gradient-to-r from-[#071936]/90 via-[#0b254f]/90 to-[#071936]/90 border border-cyan-400/65 shadow-[inset_0_1px_0_rgba(255,255,255,0.12),0_2px_8px_rgba(0,0,0,0.45)]`}
        title={
          lang === 'AR'
            ? 'عدد علامات الثنائيات والثلاثيات والفردي في هذه القصاصة'
            : 'Nombre de Doubles, Triples et Simples'
        }
      >
        <Layers className="w-3.5 h-3.5 text-cyan-300 shrink-0" />

        {/* الثنائيات (Doubles) */}
        <span className="inline-flex items-center gap-1 font-black text-amber-200 whitespace-nowrap">
          <span className="inline-flex items-center justify-center w-4 h-4 rounded-md bg-amber-400 text-black font-mono text-[9.5px] font-black">
            2
          </span>
          <span>{lang === 'AR' ? 'ثنائيات:' : 'Doubles:'}</span>
          <span className="font-mono text-white tabular-nums">{stats.doublesCount}</span>
        </span>

        <span className="text-cyan-400/50 font-bold">|</span>

        {/* الثلاثيات (Triples) */}
        <span className="inline-flex items-center gap-1 font-black text-fuchsia-200 whitespace-nowrap">
          <span className="inline-flex items-center justify-center w-4 h-4 rounded-md bg-fuchsia-400 text-black font-mono text-[9.5px] font-black">
            3
          </span>
          <span>{lang === 'AR' ? 'ثلاثيات:' : 'Triples:'}</span>
          <span className="font-mono text-white tabular-nums">{stats.triplesCount}</span>
        </span>

        <span className="text-cyan-400/50 font-bold">|</span>

        {/* الفردي (Singles) */}
        <span className="inline-flex items-center gap-1 font-black text-sky-200 whitespace-nowrap">
          <span className="inline-flex items-center justify-center w-4 h-4 rounded-md bg-sky-400 text-black font-mono text-[9.5px] font-black">
            1
          </span>
          <span>{lang === 'AR' ? 'فردي:' : 'Simples:'}</span>
          <span className="font-mono text-white tabular-nums">{stats.singlesCount}</span>
        </span>
      </div>

      {/* Row 2: Directly underneath — Error count & Correct count icons
          Yellow & completely static ("بدون حراك") from creation until first kickoff;
          Red (errors) & Green (correct) activated from first match live through all matches permanently */}
      <div
        className={
          fullWidth
            ? 'grid grid-cols-2 gap-2 w-full'
            : 'flex flex-wrap items-center gap-1.5'
        }
      >
        {/* Errors Icon (حمراء عند التفعيل، صفراء بدون حراك قبل بداية أول مقابلة) */}
        <div
          className={`${
            fullWidth
              ? 'w-full flex items-center justify-center gap-2 px-3 py-1.5 text-[11px] sm:text-xs'
              : `inline-flex items-center gap-1.5 ${
                  compact ? 'px-2 py-1 text-[10px]' : 'px-2.5 py-1 text-[10.5px] sm:text-xs'
                }`
          } rounded-xl border font-black shadow-sm ${
            isWaitingBeforeKickoff
              ? 'bg-yellow-500/20 border-yellow-400/90 text-yellow-200'
              : 'bg-red-600/35 border-red-400 text-red-100 shadow-[0_0_10px_rgba(239,68,68,0.35)]'
          }`}
          title={
            isWaitingBeforeKickoff
              ? lang === 'AR'
                ? 'في انتظار بداية أول مقابلة'
                : 'En attente du coup d’envoi'
              : lang === 'AR'
              ? 'عدد أخطاء العلامات من بداية كل مقابلة في المباشر حتى نهايتها'
              : 'Nombre d’erreurs depuis le coup d’envoi'
          }
        >
          <XCircle
            className={`w-3.5 h-3.5 shrink-0 ${
              isWaitingBeforeKickoff ? 'text-yellow-300' : 'text-red-400'
            }`}
          />
          <span>{lang === 'AR' ? 'الأخطاء:' : 'Erreurs:'}</span>
          <span
            className={`font-mono tabular-nums px-1.5 py-0.2 rounded-md ${
              isWaitingBeforeKickoff
                ? 'bg-yellow-400 text-black'
                : 'bg-red-500 text-white'
            }`}
          >
            {stats.errorCount}
          </span>
        </div>

        {/* Correct Icon (خضراء عند التفعيل، صفراء بدون حراك قبل بداية أول مقابلة) */}
        <div
          className={`${
            fullWidth
              ? 'w-full flex items-center justify-center gap-2 px-3 py-1.5 text-[11px] sm:text-xs'
              : `inline-flex items-center gap-1.5 ${
                  compact ? 'px-2 py-1 text-[10px]' : 'px-2.5 py-1 text-[10.5px] sm:text-xs'
                }`
          } rounded-xl border font-black shadow-sm ${
            isWaitingBeforeKickoff
              ? 'bg-yellow-500/20 border-yellow-400/90 text-yellow-200'
              : 'bg-emerald-600/35 border-emerald-400 text-emerald-100 shadow-[0_0_10px_rgba(16,185,129,0.35)]'
          }`}
          title={
            isWaitingBeforeKickoff
              ? lang === 'AR'
                ? 'في انتظار بداية أول مقابلة'
                : 'En attente du coup d’envoi'
              : lang === 'AR'
              ? 'عدد العلامات الصحيحة من بداية كل مقابلة في المباشر حتى نهايتها'
              : 'Nombre de pronostics corrects depuis le coup d’envoi'
          }
        >
          <CheckCircle2
            className={`w-3.5 h-3.5 shrink-0 ${
              isWaitingBeforeKickoff ? 'text-yellow-300' : 'text-emerald-400'
            }`}
          />
          <span>{lang === 'AR' ? 'الصحيحة:' : 'Corrects:'}</span>
          <span
            className={`font-mono tabular-nums px-1.5 py-0.2 rounded-md ${
              isWaitingBeforeKickoff
                ? 'bg-yellow-400 text-black'
                : 'bg-emerald-500 text-black'
            }`}
          >
            {stats.correctCount}
          </span>
        </div>
      </div>
    </div>
  );
};
