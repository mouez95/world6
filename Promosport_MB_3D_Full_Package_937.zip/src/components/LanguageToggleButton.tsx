/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Languages } from 'lucide-react';
import { audioService } from '../services/audioService';

interface LanguageToggleButtonProps {
  lang: 'AR' | 'FR';
  onChangeLang: (next: 'AR' | 'FR') => void;
  compact?: boolean;
  className?: string;
}

export const LanguageToggleButton: React.FC<LanguageToggleButtonProps> = ({
  lang,
  onChangeLang,
  compact = false,
  className = '',
}) => {
  const nextLang: 'AR' | 'FR' = lang === 'AR' ? 'FR' : 'AR';

  return (
    <button
      type="button"
      data-no-flash="true"
      onClick={() => {
        audioService.playClick();
        onChangeLang(nextLang);
      }}
      title={
        lang === 'AR'
          ? 'تبديل لغة التطبيق إلى الفرنسية (FR)'
          : 'Passer la langue de l’application en arabe (AR)'
      }
      aria-label={
        lang === 'AR'
          ? 'تعريب وتبديل اللغة بين العربية والفرنسية'
          : 'Changer la langue entre arabe et français'
      }
      dir="ltr"
      className={`shrink-0 inline-flex items-center gap-1 rounded-xl bg-[#07152e]/95 hover:bg-[#0c2147] border-2 border-[#f1b816] shadow-[0_0_14px_rgba(241,184,22,0.5)] active:scale-95 transition-all cursor-pointer select-none ${
        compact ? 'min-h-[38px] px-1.5 py-1' : 'min-h-[42px] px-2 py-1'
      } ${className}`}
    >
      <Languages
        className={`${compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-yellow-300 shrink-0`}
      />
      <span className="inline-flex items-center rounded-lg bg-black/55 p-0.5 border border-yellow-400/40">
        <span
          className={`px-1.5 py-0.5 rounded-md font-black leading-none transition-colors ${
            compact ? 'text-[10px]' : 'text-[11px] sm:text-xs'
          } ${
            lang === 'AR'
              ? 'bg-[#f1b816] text-black shadow-sm'
              : 'text-yellow-100/80'
          }`}
        >
          عربي
        </span>
        <span
          className={`px-1.5 py-0.5 rounded-md font-mono font-black leading-none transition-colors ${
            compact ? 'text-[10px]' : 'text-[11px] sm:text-xs'
          } ${
            lang === 'FR'
              ? 'bg-[#f1b816] text-black shadow-sm'
              : 'text-yellow-100/80'
          }`}
        >
          FR
        </span>
      </span>
    </button>
  );
};
