/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  FileCode,
  Download,
  Copy,
  Check,
  Smartphone,
  QrCode,
  Zap,
  Save,
  Archive,
  Terminal,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  FolderArchive
} from 'lucide-react';
import JSZip from 'jszip';
import { loadUserSlips } from '../services/storageService';
import { audioService } from '../services/audioService';

interface PromptEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PromptEditorModal: React.FC<PromptEditorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [isAutoSaveActive, setIsAutoSaveActive] = useState<boolean>(true);
  const [installPromptEvent, setInstallPromptEvent] = useState<any>(null);
  const [isInstalling, setIsInstalling] = useState<boolean>(false);
  const [isGeneratingZip, setIsGeneratingZip] = useState<boolean>(false);
  const [zipSuccess, setZipSuccess] = useState<boolean>(false);

  // App URL for QR Code and launcher
  const appUrl = typeof window !== 'undefined' ? window.location.href : 'https://promosport-tunisie.web.app';

  // Listen for beforeinstallprompt event for Google Chrome / Android PWA
  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setInstallPromptEvent(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  if (!isOpen) return null;

  const savedSlips = loadUserSlips();

  // Android APK Prompt and Build Specification
  const androidPromptSpecification = `[بروموسبور تونس - Promosport Tunisie 3D | Android APK Edition]
========================================================================
هوية المشروع: MB FOOTBALL TUNISIENNE | 51155580 (MB V19.2 HD 3D)
حالة الحفظ التلقائي: مُفعل دوماً في التخزين المحلي (LocalStorage / SQLite / Room)
رابط التطبيق المباشر: ${appUrl}
عدد القصاصات المسجلة حالياً: ${savedSlips.length} قصاصة

1. المعادلة الرسمية لاحتساب ثمن القصاصة (Promosport Official Tariff):
------------------------------------------------------------------------
الاحتمالات (Colonnes): C = 2^D * 3^T
حيث D هو عدد الثنائيات (0 إلى 11) و T هو عدد الثلاثيات (0 إلى 7)
المعادلة الجبائية: الثمن = (C * 0.150) + 0.250 TND
أمثلة معتمدة من الجدول الرسمي للبروموسبور (images__1__a73485de.jpeg):
- 1 ثنائي و 4 ثلاثي: C = 2 * 81 = 162 عمود -> 162 * 0.150 + 0.250 = 24.550 TND
- 2 ثنائي و 0 ثلاثي: C = 4 * 0.150 + 0.250 = 0.850 TND
- 1 ثنائي و 2 ثلاثي: C = 18 * 0.150 + 0.250 = 2.950 TND
- 0 ثنائي و 3 ثلاثي: C = 27 * 0.150 + 0.250 = 4.300 TND

2. ضوابط القصاصات المسجلة وتحديث النتائج:
------------------------------------------------------------------------
- تسجيل القصاصة مع التاريخ والساعة الدقيقة.
- قبل بداية أول مقابلة: يُسمح بالتعديل، الإضافة، والفسخ.
- عند بداية أول مقابلة حتى نهاية آخر مقابلة:
  * يُقفل التعديل والإضافة فوراً.
  * يُسمح فقط بفسخ القصاصة.
- تتبع النتائج المباشرة مع علامات الصح ✓ (بالأخضر) والخطأ ✗ (بالأحمر) تحت كل مقابلة.

3. ملفات بناء تطبيق الأندرويد (Capacitor / Android Studio APK):
------------------------------------------------------------------------
• capacitor.config.json:
{
  "appId": "com.promosport.tunisie.mb",
  "appName": "Promosport Tunisie 3D",
  "webDir": "dist",
  "bundledWebRuntime": false
}

• AndroidManifest.xml:
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.promosport.tunisie.mb">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <application android:label="Promosport 3D" android:icon="@mipmap/ic_launcher" android:hardwareAccelerated="true" />
</manifest>

• سجل القصاصات المسجلة الحالية:
${JSON.stringify(savedSlips, null, 2)}
`;

  // Copy Prompt to Clipboard
  const handleCopyPrompt = () => {
    audioService.playClick();
    navigator.clipboard.writeText(androidPromptSpecification);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Trigger Google Chrome / Android PWA Install
  const handleInstallApp = async () => {
    audioService.playClick();
    if (installPromptEvent) {
      installPromptEvent.prompt();
      const choice = await installPromptEvent.userChoice;
      if (choice.outcome === 'accepted') {
        alert('تم تثبيت التطبيق بنجاح على هاتفك!');
      }
      setInstallPromptEvent(null);
    } else {
      alert('لتثبيت التطبيق على هاتف أندرويد عبر متصفح Google Chrome:\n1. اضغط على القائمة (الثلاث نقاط) في أعلى المتصفح.\n2. اختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية" (Add to Home screen).\n3. سيتم تثبيت التطبيق كـ APK PWA فوراً!');
    }
  };

  // Generate & Download full ZIP package
  const handleDownloadZip = async () => {
    audioService.playClick();
    setIsGeneratingZip(true);
    try {
      const zip = new JSZip();

      // Add build files and specifications
      zip.file("README_ANDROID_BUILD.md", `# Promosport Tunisie 3D - Build Package\n\nRun:\n1. npm install\n2. npm run build\n3. npx cap add android\n4. npx cap open android\n`);
      zip.file("PROMPT_SPECIFICATION.txt", androidPromptSpecification);
      zip.file("capacitor.config.json", JSON.stringify({
        appId: "com.promosport.tunisie.mb",
        appName: "Promosport Tunisie 3D",
        webDir: "dist",
        bundledWebRuntime: false
      }, null, 2));

      zip.file("SAVED_USER_SLIPS.json", JSON.stringify(savedSlips, null, 2));
      zip.file("OFFICIAL_PRICING_TABLE.json", JSON.stringify({
        formula: "Price = (2^Doubles * 3^Triples) * 0.150 + 0.250 TND",
        reference: "images__1__a73485de.jpeg",
        example: "1 double + 4 triples = 24.550 TND"
      }, null, 2));

      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Promosport_Tunisie_3D_Full_Build_${Date.now()}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setZipSuccess(true);
      setTimeout(() => setZipSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء إنشاء ملف ZIP');
    } finally {
      setIsGeneratingZip(false);
    }
  };

  // Generate simple QR Code SVG
  const qrSvgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(appUrl)}&color=f1b816&bgcolor=050e20`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/92 md:bg-black/90 md:backdrop-blur-md animate-fade-in font-sans select-none"
    >
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-[#061022] border-2 border-yellow-500/80 shadow-[0_0_60px_rgba(241,184,22,0.4)] overflow-hidden text-white">
        
        {/* Top Header */}
        <div className="px-4 sm:px-6 py-3.5 bg-gradient-to-r from-[#040a18] via-[#091a38] to-[#040a18] border-b border-yellow-500/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-yellow-400 text-black flex items-center justify-center font-black text-xs shadow-md">
              APK
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-yellow-400 tracking-wide">
                خانة تعديل البرومبت وبناء تطبيق الأندرويد
              </h2>
              <p className="text-[10px] text-gray-300">
                تسجيل تلقائي، تثبيت Google Chrome، مسح QR وتنزيل ZIP
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              audioService.playClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-red-600/40 text-gray-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          
          {/* 1. AUTO-SAVE & STATUS BANNER */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-[#0a1835] to-emerald-950/60 border border-emerald-400/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-400 flex items-center justify-center animate-pulse">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="font-black text-xs sm:text-sm text-emerald-300 flex items-center gap-2">
                  <span>التسجيل التلقائي مفعل دوماً</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                </div>
                <p className="text-[11px] text-gray-300 mt-0.5">
                  يتم حفظ التعديلات والإعدادات وكافة القصاصات في الجهاز تلقائياً وبشكل فوري.
                </p>
              </div>
            </div>

            <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-xs font-mono font-bold">
              AUTO-SAVE ON
            </span>
          </div>

          {/* 2. GOOGLE CHROME PHONE INSTALL & QR CODE CAMERA SCAN */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* Install from Google Chrome */}
            <div className="p-4 rounded-2xl bg-[#091730] border border-sky-400/50 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-sky-300 font-black text-xs sm:text-sm">
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  <span>تثبيت التطبيق من Google Chrome</span>
                </div>
                <p className="text-[11px] text-gray-300 mt-1">
                  تثبيت فوري لتطبيق الهاتف كـ Web APK عبر متصفح كروم وإضافته إلى شاشة الهاتف الرئيسية.
                </p>
              </div>

              <button
                onClick={handleInstallApp}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-400 text-black font-black text-xs shadow-[0_0_15px_rgba(56,189,248,0.6)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>تثبيت التطبيق على الهاتف</span>
              </button>
            </div>

            {/* QR Code Scanner */}
            <div className="p-4 rounded-2xl bg-[#091730] border border-yellow-400/50 space-y-3 flex flex-col items-center text-center">
              <div className="flex items-center gap-2 text-yellow-300 font-black text-xs sm:text-sm">
                <QrCode className="w-4 h-4 text-yellow-400" />
                <span>مسح كود QR بكاميرا الهاتف</span>
              </div>

              {/* QR Image */}
              <div className="w-24 h-24 rounded-xl border-2 border-yellow-400/70 p-1 bg-[#050e20] shadow-[0_0_15px_rgba(241,184,22,0.4)] flex items-center justify-center">
                <img
                  src={qrSvgUrl}
                  alt="Promosport Mobile QR Code"
                  className="w-full h-full object-contain rounded-lg"
                />
              </div>

              <p className="text-[10px] text-gray-300">
                افتح كاميرا الهاتف وقم بتوجيهها نحو الكود لفتح وتشغيل التطبيق فوراً.
              </p>
            </div>

          </div>

          {/* 3. DOWNLOAD FULL ZIP ARCHIVE */}
          <div className="p-4 rounded-2xl bg-[#091730] border border-yellow-500/50 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FolderArchive className="w-5 h-5 text-yellow-400" />
                <div>
                  <h4 className="font-black text-sm text-yellow-300">
                    تنزيل التطبيق بصيغة ZIP (آخر تحديث شامل ومفعل)
                  </h4>
                  <p className="text-[11px] text-gray-300">
                    ملف أرشيف مضغوط يحتوي على الكود المصدري، ملفات Capacitor لبناء APK الأندرويد، وملف القصاصات.
                  </p>
                </div>
              </div>

              <button
                onClick={handleDownloadZip}
                disabled={isGeneratingZip}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-black text-xs shadow-[0_0_15px_rgba(241,184,22,0.6)] hover:scale-105 active:scale-95 transition-all flex items-center gap-2 disabled:opacity-50 shrink-0"
              >
                {isGeneratingZip ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : zipSuccess ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Download className="w-4 h-4" />
                )}
                <span>{zipSuccess ? 'تم التنزيل!' : 'تنزيل ZIP'}</span>
              </button>
            </div>
          </div>

          {/* 4. FULL ANDROID PROMPT SPECIFICATION & COPY BOX */}
          <div className="p-4 rounded-2xl bg-[#081226] border border-white/20 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-cyan-400" />
                <span className="font-black text-xs text-cyan-300">
                  برومبت أندرويد APK الشامل والمعادلة الرسمية
                </span>
              </div>

              <button
                onClick={handleCopyPrompt}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-yellow-300 border border-yellow-400/40 text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ!' : 'نسخ البرومبت'}</span>
              </button>
            </div>

            <pre className="p-3 rounded-xl bg-black/80 border border-white/10 text-[10px] font-mono text-gray-300 overflow-x-auto max-h-48 leading-relaxed whitespace-pre-wrap select-text">
              {androidPromptSpecification}
            </pre>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="p-3 bg-[#040a18] border-t border-yellow-500/40 flex justify-end">
          <button
            onClick={() => {
              audioService.playClick();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-[#f1b816] text-black font-black text-xs hover:bg-yellow-300 shadow-md"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
