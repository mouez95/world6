/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Bell, Trash2, Zap, Trophy, Flame } from 'lucide-react';
import { audioService } from '../services/audioService';
import { LiveNotificationItem } from '../types/promosport';
import { MbLogo } from './MbLogo';
import { LanguageToggleButton } from './LanguageToggleButton';

interface PromosportIntroStageProps {
  active: boolean;
  isClosing?: boolean;
  onEnterGrille: () => void;
  lang?: 'AR' | 'FR';
  onChangeLang?: (lang: 'AR' | 'FR') => void;
  liveNotifications?: LiveNotificationItem[];
  onClearNotifications?: () => void;
  onOpenNotification?: (item: LiveNotificationItem) => void;
}

interface SoftwareProbe {
  isSoftware: boolean;
  rendererName: string;
}

function detectSoftwareWebGL(gl: WebGLRenderingContext | WebGL2RenderingContext): SoftwareProbe {
  try {
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (ext) {
      const rendererName = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '');
      const isSoftware = /SwiftShader|llvmpipe|Software Rasterizer|Microsoft Basic Render/i.test(rendererName);
      return { isSoftware, rendererName };
    }
  } catch {
    // ignore probe errors
  }
  return { isSoftware: false, rendererName: 'hardware' };
}

/**
 * Generates exact seamless spherical truncated-icosahedron (12 pentagons + 20 hexagons)
 * albedo, bump, and roughness CanvasTextures for the 3D football with zero pole distortion.
 */
function createSoccerBallTextures(): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
} {
  const width = 768;
  const height = 384;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = width;
  albedoCanvas.height = height;
  const aCtx = albedoCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = width;
  bumpCanvas.height = height;
  const bCtx = bumpCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = width;
  roughCanvas.height = height;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(width, height);
  const bImg = bCtx.createImageData(width, height);
  const rImg = rCtx.createImageData(width, height);

  const phi = (1 + Math.sqrt(5)) / 2;

  const normalizeVec = (x: number, y: number, z: number): [number, number, number] => {
    const len = Math.hypot(x, y, z) || 1;
    return [x / len, y / len, z / len];
  };

  // 12 Pentagon centers (icosahedron vertices)
  const pentCenters: Array<[number, number, number]> = [
    normalizeVec(0, 1, phi),
    normalizeVec(0, -1, phi),
    normalizeVec(0, 1, -phi),
    normalizeVec(0, -1, -phi),
    normalizeVec(1, phi, 0),
    normalizeVec(-1, phi, 0),
    normalizeVec(1, -phi, 0),
    normalizeVec(-1, -phi, 0),
    normalizeVec(phi, 0, 1),
    normalizeVec(-phi, 0, 1),
    normalizeVec(phi, 0, -1),
    normalizeVec(-phi, 0, -1),
  ];

  // 20 Hexagon centers (dodecahedron vertices)
  const invPhi = 1 / phi;
  const hexCenters: Array<[number, number, number]> = [
    normalizeVec(1, 1, 1),
    normalizeVec(1, 1, -1),
    normalizeVec(1, -1, 1),
    normalizeVec(1, -1, -1),
    normalizeVec(-1, 1, 1),
    normalizeVec(-1, 1, -1),
    normalizeVec(-1, -1, 1),
    normalizeVec(-1, -1, -1),
    normalizeVec(0, phi, invPhi),
    normalizeVec(0, phi, -invPhi),
    normalizeVec(0, -phi, invPhi),
    normalizeVec(0, -phi, -invPhi),
    normalizeVec(invPhi, 0, phi),
    normalizeVec(-invPhi, 0, phi),
    normalizeVec(invPhi, 0, -phi),
    normalizeVec(-invPhi, 0, -phi),
    normalizeVec(phi, invPhi, 0),
    normalizeVec(phi, -invPhi, 0),
    normalizeVec(-phi, invPhi, 0),
    normalizeVec(-phi, -invPhi, 0),
  ];

  const invPentScale = 1 / 0.68819;
  const invHexScale = 1 / 0.86603;

  for (let py = 0; py < height; py++) {
    const v = (py + 0.5) / height;
    const phiA = v * Math.PI;
    const sinPhi = Math.sin(phiA);
    const cosPhi = Math.cos(phiA);

    for (let px = 0; px < width; px++) {
      const u = (px + 0.5) / width;
      const theta = u * Math.PI * 2;
      const vx = sinPhi * Math.cos(theta);
      const vy = cosPhi;
      const vz = sinPhi * Math.sin(theta);

      let best1 = Infinity;
      let best2 = Infinity;
      let isPent = false;

      for (let i = 0; i < 12; i++) {
        const c = pentCenters[i];
        const dot = Math.max(-1, Math.min(1, vx * c[0] + vy * c[1] + vz * c[2]));
        const sDist = Math.acos(dot) * invPentScale;
        if (sDist < best1) {
          best2 = best1;
          best1 = sDist;
          isPent = true;
        } else if (sDist < best2) {
          best2 = sDist;
        }
      }

      for (let i = 0; i < 20; i++) {
        const c = hexCenters[i];
        const dot = Math.max(-1, Math.min(1, vx * c[0] + vy * c[1] + vz * c[2]));
        const sDist = Math.acos(dot) * invHexScale;
        if (sDist < best1) {
          best2 = best1;
          best1 = sDist;
          isPent = false;
        } else if (sDist < best2) {
          best2 = sDist;
        }
      }

      const seamDelta = best2 - best1;
      const grain = Math.sin(vx * 115.0 + vy * 89.0) * Math.cos(vz * 110.0) * 6.0;

      const seamMask = Math.max(0, Math.min(1, (0.022 - seamDelta) / 0.022));
      const bevelMask = Math.max(0, Math.min(1, (0.055 - seamDelta) / 0.055));

      let r: number;
      let g: number;
      let b: number;
      let roughVal: number;

      if (isPent) {
        r = 18 + grain * 0.6;
        g = 22 + grain * 0.6;
        b = 31 + grain * 0.7;
        roughVal = 92;
      } else {
        r = 242 + grain * 0.7;
        g = 244 + grain * 0.7;
        b = 249 + grain * 0.7;
        roughVal = 82;
      }

      const bumpVal = 200 - bevelMask * 65 - seamMask * 125 + grain * 1.4;

      if (seamMask > 0.01) {
        const stitchPulse = 0.5 + 0.5 * Math.sin((theta + phiA) * 95.0);
        r = r * (1 - seamMask * 0.82) + stitchPulse * seamMask * 55;
        g = g * (1 - seamMask * 0.85) + stitchPulse * seamMask * 40;
        b = b * (1 - seamMask * 0.88) + stitchPulse * seamMask * 25;
        roughVal = Math.min(240, roughVal + seamMask * 110);
      }

      const idx = (py * width + px) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, r));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, g));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, b));
      aImg.data[idx + 3] = 255;

      const bv = Math.max(0, Math.min(255, bumpVal));
      bImg.data[idx] = bv;
      bImg.data[idx + 1] = bv;
      bImg.data[idx + 2] = bv;
      bImg.data[idx + 3] = 255;

      const rv = Math.max(0, Math.min(255, roughVal));
      rImg.data[idx] = rv;
      rImg.data[idx + 1] = rv;
      rImg.data[idx + 2] = rv;
      rImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  bCtx.putImageData(bImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const map = new THREE.CanvasTexture(albedoCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = 4;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  const roughnessMap = new THREE.CanvasTexture(roughCanvas);

  return { map, bumpMap, roughnessMap };
}

export const PromosportIntroStage: React.FC<PromosportIntroStageProps> = ({
  active,
  isClosing = false,
  onEnterGrille,
  lang = 'AR',
  onChangeLang,
  liveNotifications = [],
  onClearNotifications,
  onOpenNotification,
}) => {
  const stageRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const [webglLost, setWebglLost] = useState(false);
  const [mbRevealed, setMbRevealed] = useState(false);

  // Reveal the radiant spinning gilded MB emblem from above right as the fiery ball lands
  useEffect(() => {
    if (!active) return;
    setMbRevealed(false);
    const tMb = window.setTimeout(() => setMbRevealed(true), 760);
    return () => {
      window.clearTimeout(tMb);
    };
  }, [active]);

  useEffect(() => {
    if (!active) return;
    const container = stageRef.current;
    if (!container) return;

    let width = container.clientWidth || window.innerWidth;
    let height = container.clientHeight || window.innerHeight;

    let renderer: THREE.WebGLRenderer | null = null;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglLost(true);
      return;
    }

    const gl = renderer.getContext();
    const { isSoftware } = detectSoftwareWebGL(gl);
    if (isSoftware) {
      renderer.setPixelRatio(1);
    } else {
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    }

    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.setClearColor(0x000000, 0);

    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglLost(true);
    };
    const handleContextRestored = () => {
      setWebglLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();

    // Studio IBL for rich leather + gold metallic reflections
    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmrem.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(42, width / Math.max(1, height), 0.1, 100);
    camera.position.set(0, 0, 10);

    // Three-point + live fire lighting
    const ambientLight = new THREE.AmbientLight(0x93c5fd, 0.45);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff4e0, 1.45);
    keyLight.position.set(3.5, 4.5, 7.5);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.35);
    rimLight.position.set(-4.5, 2.5, -3.5);
    scene.add(rimLight);

    const fireLight = new THREE.PointLight(0xff7718, 6.4, 18, 1.6);
    fireLight.position.set(0, 0.4, 1.2);
    scene.add(fireLight);

    // Exact alignment helper mapping DOM ribbon coordinates directly into Three.js world space
    const computeLayout = (w: number, h: number) => {
      const aspect = w / Math.max(1, h);
      const visH = 2 * Math.tan(THREE.MathUtils.degToRad(42 / 2)) * 10;
      const visW = visH * aspect;
      const heroScale = THREE.MathUtils.clamp(visW / 5.4, 0.72, 1.15);

      const cRect = container.getBoundingClientRect();
      const rRect = ribbonRef.current?.getBoundingClientRect();

      let worldRibbonY = -0.35;
      let worldRibbonRightX = Math.min(visW * 0.28, 1.65 * heroScale);

      if (rRect && cRect.width > 0 && cRect.height > 0) {
        const ribbonCenterY = rRect.top + rRect.height * 0.48 - cRect.top;
        const ndcY = 1 - 2 * (ribbonCenterY / cRect.height);
        worldRibbonY = ndcY * (visH * 0.5);

        const ribbonRightX = rRect.right - rRect.width * 0.06 - cRect.left;
        const ndcRightX = 2 * (ribbonRightX / cRect.width) - 1;
        worldRibbonRightX = ndcRightX * (visW * 0.5);
      }

      const startX = -Math.max(visW * 0.58, 2.6);
      const startY = worldRibbonY + 0.02;
      // Lands cleanly on the right flank right behind & slightly cresting above the PROMOSPORT ribbon
      const targetX = Math.min(worldRibbonRightX, visW * 0.41);
      const targetY = worldRibbonY + 0.42 * heroScale;

      return { visW, visH, heroScale, targetX, targetY, startX, startY, worldRibbonY };
    };
    let layout = computeLayout(width, height);

    // =========================================================================
    // 1. SCI-FI ARENA STARFIELD & ENERGY HORIZON DUST
    // =========================================================================
    const dustCount = isSoftware ? 75 : 130;
    const dustPositions = new Float32Array(dustCount * 3);
    const dustColors = new Float32Array(dustCount * 3);
    const dustSizes = new Float32Array(dustCount);

    for (let i = 0; i < dustCount; i++) {
      dustPositions[i * 3] = (Math.random() - 0.5) * 14;
      dustPositions[i * 3 + 1] = (Math.random() - 0.5) * 9;
      dustPositions[i * 3 + 2] = -1.5 - Math.random() * 5.5;
      dustSizes[i] = 1.4 + Math.random() * 2.8;
      if (i % 3 === 0) {
        dustColors[i * 3] = 1.0;
        dustColors[i * 3 + 1] = 0.78;
        dustColors[i * 3 + 2] = 0.35;
      } else {
        dustColors[i * 3] = 0.35;
        dustColors[i * 3 + 1] = 0.78;
        dustColors[i * 3 + 2] = 1.0;
      }
    }

    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    dustGeo.setAttribute('color', new THREE.BufferAttribute(dustColors, 3));
    dustGeo.setAttribute('aSize', new THREE.BufferAttribute(dustSizes, 1));

    const dustUniforms = { uTime: { value: 0 } };
    const dustMat = new THREE.ShaderMaterial({
      uniforms: dustUniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute vec3 color;
        attribute float aSize;
        varying vec3 vColor;
        varying float vAlpha;
        uniform float uTime;
        void main() {
          vColor = color;
          vec3 p = position;
          p.y += sin(uTime * 0.6 + position.x * 1.4) * 0.08;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = aSize * (18.0 / max(1.0, -mv.z));
          vAlpha = 0.35 + 0.35 * sin(uTime * 2.2 + position.x * 3.1 + position.y * 2.3);
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        varying float vAlpha;
        void main() {
          float d = length(gl_PointCoord - vec2(0.5));
          float core = smoothstep(0.5, 0.04, d);
          gl_FragColor = vec4(vColor, core * vAlpha * 0.7);
        }
      `,
    });
    const dustPoints = new THREE.Points(dustGeo, dustMat);
    scene.add(dustPoints);

    // =========================================================================
    // 2. COMPOSITE 3D FOOTBALL GROUP (Stitched Pentagons/Hexagons + Corona)
    // =========================================================================
    const ballGroup = new THREE.Group();
    ballGroup.position.set(layout.startX, layout.startY, -0.32);
    scene.add(ballGroup);

    const ballTextures = createSoccerBallTextures();
    const ballGeo = new THREE.SphereGeometry(0.62, 48, 36);
    const ballMat = new THREE.MeshPhysicalMaterial({
      map: ballTextures.map,
      bumpMap: ballTextures.bumpMap,
      bumpScale: 0.024,
      roughnessMap: ballTextures.roughnessMap,
      roughness: 0.42,
      metalness: 0.1,
      clearcoat: 0.46,
      clearcoatRoughness: 0.22,
      envMapIntensity: 1.25,
    });
    const ballMesh = new THREE.Mesh(ballGeo, ballMat);
    ballGroup.add(ballMesh);

    const coronaGeo = new THREE.SphereGeometry(0.7, 36, 28);
    const coronaUniforms = {
      uTime: { value: 0 },
      uIntensity: { value: 0 },
    };
    const coronaMat = new THREE.ShaderMaterial({
      uniforms: coronaUniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.FrontSide,
      vertexShader: `
        varying vec3 vNormal;
        varying vec3 vViewPos;
        varying vec3 vLocalPos;
        void main() {
          vLocalPos = position;
          vNormal = normalize(normalMatrix * normal);
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vViewPos = -mv.xyz;
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform float uIntensity;
        varying vec3 vNormal;
        varying vec3 vViewPos;
        varying vec3 vLocalPos;

        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
            mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
            u.y
          );
        }

        void main() {
          vec3 N = normalize(vNormal);
          vec3 V = normalize(vViewPos);
          float fresnel = pow(1.0 - max(0.0, dot(N, V)), 2.35);
          float flick = noise(vec2(vLocalPos.x * 4.5 + uTime * 2.2, vLocalPos.y * 5.0 - uTime * 4.8));
          vec3 hotCol = mix(vec3(1.0, 0.28, 0.03), vec3(1.0, 0.86, 0.25), flick * 0.8 + fresnel * 0.35);
          float alpha = fresnel * (0.45 + 0.55 * flick) * uIntensity;
          gl_FragColor = vec4(hotCol * alpha * 1.45, alpha);
        }
      `,
    });
    const coronaMesh = new THREE.Mesh(coronaGeo, coronaMat);
    ballGroup.add(coronaMesh);

    // =========================================================================
    // 3. REAL-TIME 3D VOLUMETRIC-FEEL GLSL FLAME PLUME (Behind Ball & Ribbon)
    // =========================================================================
    const flameUniforms = {
      uTime: { value: 0 },
      uIgnition: { value: 0 },
      uMotionBlur: { value: 1 },
    };

    const flameGeo = new THREE.PlaneGeometry(3.4, 3.6, 1, 1);
    const flameMat = new THREE.ShaderMaterial({
      uniforms: flameUniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform float uIgnition;
        uniform float uMotionBlur;
        varying vec2 vUv;

        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }

        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
            mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
            u.y
          );
        }

        float fbm(vec2 p) {
          float sum = 0.0;
          float amp = 0.52;
          mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
          for (int i = 0; i < 5; i++) {
            sum += amp * noise(p);
            p = rot * p * 2.06 + vec2(1.4, -2.7);
            amp *= 0.5;
          }
          return sum;
        }

        void main() {
          vec2 p = (vUv - vec2(0.5, 0.34)) * vec2(2.6, 2.95);

          float tilt = uMotionBlur * 0.64;
          vec2 warpedP = p;
          warpedP.x += max(0.0, p.y + 0.35) * tilt * 0.72;

          float flow1 = fbm(vec2(warpedP.x * 2.35, warpedP.y * 1.55 - uTime * 3.9));
          float flow2 = fbm(vec2(warpedP.x * 4.4 + flow1 * 1.35, warpedP.y * 2.6 - uTime * 6.5));
          float turb = mix(flow1, flow2, 0.55);

          float heightNorm = clamp((warpedP.y + 0.58) / 2.25, 0.0, 1.0);
          float widthProfile = mix(0.68, 0.14, pow(heightNorm, 1.25));
          widthProfile += uMotionBlur * 0.18 * (1.0 - heightNorm);

          float sway = (turb - 0.5) * (0.45 + heightNorm * 0.65);
          float radial = abs(warpedP.x + sway) / max(0.08, widthProfile);

          float baseHeat = exp(-dot(p - vec2(0.0, -0.04), p - vec2(0.0, -0.04)) * 3.1);
          float tongueShape = smoothstep(1.18, 0.08, radial) * (1.0 - smoothstep(0.32, 1.0, heightNorm));
          tongueShape *= smoothstep(-0.62, -0.15, p.y);

          float cometX = clamp(-p.x / 1.5, 0.0, 1.0);
          float cometWake = exp(-abs(p.y + (turb - 0.5) * 0.25) * 5.0) * (1.0 - cometX) * step(p.x, 0.15) * uMotionBlur;

          float density = (tongueShape * (0.55 + 0.85 * turb) + baseHeat * 0.74 + cometWake * (0.58 + 0.6 * flow2)) * uIgnition;

          vec3 colCrimson = vec3(0.95, 0.15, 0.02);
          vec3 colOrange = vec3(1.0, 0.46, 0.04);
          vec3 colGold = vec3(1.0, 0.85, 0.24);
          vec3 colCore = vec3(1.0, 0.98, 0.86);

          vec3 fireColor = mix(colCrimson, colOrange, smoothstep(0.12, 0.42, density));
          fireColor = mix(fireColor, colGold, smoothstep(0.42, 0.82, density));
          fireColor = mix(fireColor, colCore, smoothstep(0.82, 1.35, density));

          float alpha = clamp(density * 1.18, 0.0, 1.0);
          float edgeFade = smoothstep(0.0, 0.12, vUv.x) * smoothstep(1.0, 0.88, vUv.x) *
                           smoothstep(0.0, 0.12, vUv.y) * smoothstep(1.0, 0.85, vUv.y);

          gl_FragColor = vec4(fireColor * (0.95 + density * 0.45), alpha * edgeFade);
        }
      `,
    });
    const flameMesh = new THREE.Mesh(flameGeo, flameMat);
    flameMesh.position.set(layout.startX, layout.startY + 0.48, -0.56);
    scene.add(flameMesh);

    const flameBackMesh = new THREE.Mesh(flameGeo, flameMat);
    flameBackMesh.position.set(layout.startX - 0.12, layout.startY + 0.36, -0.78);
    flameBackMesh.scale.set(1.15, 1.08, 1);
    flameBackMesh.rotation.z = 0.08;
    scene.add(flameBackMesh);

    // =========================================================================
    // 4. REAL-TIME 3D RISING & TRAILING FIRE EMBERS (THREE.Points)
    // =========================================================================
    const emberCount = isSoftware ? 65 : 115;
    const emberPositions = new Float32Array(emberCount * 3);
    const emberSizes = new Float32Array(emberCount);
    const emberLives = new Float32Array(emberCount);

    interface EmberParticle {
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      size: number;
    }

    const embers: EmberParticle[] = Array.from({ length: emberCount }, (_, i) => ({
      x: layout.startX,
      y: layout.startY,
      z: -0.45,
      vx: (Math.random() - 0.5) * 0.6,
      vy: 0.9 + Math.random() * 1.8,
      life: (i / emberCount) * 1.1,
      maxLife: 0.7 + Math.random() * 0.85,
      size: 2.2 + Math.random() * 4.2,
    }));

    const emberGeo = new THREE.BufferGeometry();
    emberGeo.setAttribute('position', new THREE.BufferAttribute(emberPositions, 3));
    emberGeo.setAttribute('aSize', new THREE.BufferAttribute(emberSizes, 1));
    emberGeo.setAttribute('aLife', new THREE.BufferAttribute(emberLives, 1));

    const emberMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute float aSize;
        attribute float aLife;
        varying float vLife;
        void main() {
          vLife = aLife;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = aSize * (16.0 / max(1.0, -mv.z)) * (0.4 + 0.6 * (1.0 - aLife));
        }
      `,
      fragmentShader: `
        varying float vLife;
        void main() {
          float d = length(gl_PointCoord - vec2(0.5));
          float glow = smoothstep(0.5, 0.02, d);
          vec3 col = mix(vec3(1.0, 0.92, 0.45), vec3(1.0, 0.28, 0.03), vLife);
          float alpha = glow * (1.0 - vLife) * 0.95;
          gl_FragColor = vec4(col * 1.35, alpha);
        }
      `,
    });
    const emberPoints = new THREE.Points(emberGeo, emberMat);
    emberPoints.frustumCulled = false;
    scene.add(emberPoints);

    // =========================================================================
    // ANIMATION LOOP (Fast Left->Right Entrance + Eternal Burning & Spinning)
    // =========================================================================
    const startMs = performance.now();
    let prevMs = startMs;
    let rafId = 0;
    let disposed = false;

    const handleResize = () => {
      if (disposed || !renderer || !container) return;
      width = container.clientWidth || window.innerWidth;
      height = container.clientHeight || window.innerHeight;
      camera.aspect = width / Math.max(1, height);
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      renderer.setPixelRatio(isSoftware ? 1 : Math.min(window.devicePixelRatio || 1, 2));
      layout = computeLayout(width, height);
    };
    window.addEventListener('resize', handleResize);

    const ribbonObserver =
      typeof ResizeObserver !== 'undefined' && ribbonRef.current
        ? new ResizeObserver(() => {
            if (!disposed) layout = computeLayout(width, height);
          })
        : null;
    if (ribbonObserver && ribbonRef.current) {
      ribbonObserver.observe(ribbonRef.current);
    }

    // Re-sample layout after initial React paint so DOM rects are guaranteed settled
    const rafAlign = requestAnimationFrame(() => {
      if (!disposed) layout = computeLayout(width, height);
    });

    const FLIGHT_START = 0.08;
    const FLIGHT_DURATION = 0.98;

    const tick = () => {
      if (disposed || !renderer) return;
      const now = performance.now();
      const elapsed = (now - startMs) / 1000;
      const dt = Math.min(0.05, (now - prevMs) / 1000);
      prevMs = now;

      const ignition = THREE.MathUtils.smoothstep(elapsed, 0.0, 0.28);

      const rawFlightT = THREE.MathUtils.clamp((elapsed - FLIGHT_START) / FLIGHT_DURATION, 0, 1);
      const easedT = 1 - Math.pow(1 - rawFlightT, 3.2);
      const velocityWeight = rawFlightT < 1 ? Math.pow(1 - rawFlightT, 1.45) : 0;

      const curX = THREE.MathUtils.lerp(layout.startX, layout.targetX, easedT);
      const arcLift = Math.sin(rawFlightT * Math.PI) * 0.12 * layout.heroScale;
      const idleFloat = rawFlightT >= 1 ? Math.sin((elapsed - 1.1) * 2.4) * 0.022 * layout.heroScale : 0;
      const curY = THREE.MathUtils.lerp(layout.startY, layout.targetY, easedT) + arcLift + idleFloat;

      ballGroup.position.set(curX, curY, -0.32);
      ballGroup.scale.setScalar(layout.heroScale);

      // Continuous axial spin on itself (faster while flying, sleek steady spin once parked)
      const rollSpeed = 2.6 + velocityWeight * 6.8;
      ballMesh.rotation.z -= rollSpeed * dt;
      ballMesh.rotation.y += (1.85 + velocityWeight * 3.1) * dt;
      ballMesh.rotation.x = Math.sin(elapsed * 1.4) * 0.22;

      dustUniforms.uTime.value = elapsed;
      coronaUniforms.uTime.value = elapsed;
      coronaUniforms.uIntensity.value = ignition * (0.95 + 0.15 * Math.sin(elapsed * 9.0));

      flameUniforms.uTime.value = elapsed;
      flameUniforms.uIgnition.value = ignition;
      flameUniforms.uMotionBlur.value = velocityWeight;

      flameMesh.position.set(
        curX - velocityWeight * 0.42 * layout.heroScale,
        curY + (0.48 - velocityWeight * 0.26) * layout.heroScale,
        -0.56
      );
      flameMesh.scale.setScalar(layout.heroScale);

      flameBackMesh.position.set(
        curX - (0.1 + velocityWeight * 0.55) * layout.heroScale,
        curY + (0.38 - velocityWeight * 0.22) * layout.heroScale,
        -0.78
      );
      flameBackMesh.scale.set(1.14 * layout.heroScale, 1.08 * layout.heroScale, 1);

      fireLight.position.set(curX + 0.15, curY + 0.35, 1.05);
      fireLight.intensity = ignition * (5.2 + Math.sin(elapsed * 16.0) * 0.85 + Math.cos(elapsed * 23.0) * 0.55);

      camera.position.x = Math.sin(elapsed * 0.45) * 0.06;
      camera.position.y = Math.cos(elapsed * 0.38) * 0.04;
      camera.lookAt(0, 0, 0);

      const posArr = emberGeo.attributes.position.array as Float32Array;
      const sizeArr = emberGeo.attributes.aSize.array as Float32Array;
      const lifeArr = emberGeo.attributes.aLife.array as Float32Array;

      for (let i = 0; i < emberCount; i++) {
        const em = embers[i];
        em.life += dt;
        if (em.life >= em.maxLife) {
          em.life = 0;
          em.maxLife = 0.65 + Math.random() * 0.85;
          const angle = Math.random() * Math.PI * 2;
          const spawnR = (0.25 + Math.random() * 0.42) * layout.heroScale;
          em.x = curX + Math.cos(angle) * spawnR;
          em.y = curY + Math.sin(angle) * spawnR * 0.7;
          em.z = -0.45 + (Math.random() - 0.5) * 0.45;
          em.vx = -velocityWeight * (2.2 + Math.random() * 2.4) + (Math.random() - 0.5) * 0.85;
          em.vy = 0.95 + Math.random() * 1.95;
        } else {
          em.x += (em.vx + Math.sin(elapsed * 6.0 + i) * 0.35) * dt;
          em.y += em.vy * dt;
          em.vy += 0.45 * dt;
        }

        posArr[i * 3] = em.x;
        posArr[i * 3 + 1] = em.y;
        posArr[i * 3 + 2] = em.z;
        sizeArr[i] = em.size * layout.heroScale * ignition;
        lifeArr[i] = em.life / em.maxLife;
      }
      emberGeo.attributes.position.needsUpdate = true;
      emberGeo.attributes.aSize.needsUpdate = true;
      emberGeo.attributes.aLife.needsUpdate = true;

      renderer.render(scene, camera);
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(rafAlign);
      cancelAnimationFrame(rafId);
      ribbonObserver?.disconnect();
      window.removeEventListener('resize', handleResize);
      renderer?.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer?.domElement.removeEventListener('webglcontextrestored', handleContextRestored);

      dustGeo.dispose();
      dustMat.dispose();
      ballGeo.dispose();
      ballMat.dispose();
      ballTextures.map.dispose();
      ballTextures.bumpMap.dispose();
      ballTextures.roughnessMap.dispose();
      coronaGeo.dispose();
      coronaMat.dispose();
      flameGeo.dispose();
      flameMat.dispose();
      emberGeo.dispose();
      emberMat.dispose();
      envTarget.dispose();
      renderer?.dispose();
      if (renderer && renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [active]);

  if (!active) return null;

  return (
    <div
      className={`fixed inset-0 z-[110] flex flex-col items-center justify-center overflow-hidden bg-[#020612] select-none transition-all duration-300 ${
        isClosing ? 'opacity-0 scale-110 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* Sci-Fi Ambient Radial Nebula Backdrop (below WebGL canvas) */}
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 85% 60% at 50% 48%, rgba(234, 88, 12, 0.14) 0%, rgba(14, 116, 144, 0.14) 38%, rgba(2, 6, 18, 0.98) 80%)',
        }}
      />

      {/* Sci-Fi Perspective Horizon Grid Floor (subtle depth cue) */}
      <div
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 h-[36vh] pointer-events-none opacity-25"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(56, 189, 248, 0.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(56, 189, 248, 0.25) 1px, transparent 1px)',
          backgroundSize: '42px 42px',
          transform: 'perspective(380px) rotateX(68deg) translateY(38%)',
          maskImage: 'linear-gradient(to bottom, transparent 0%, black 65%)',
          WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, black 65%)',
        }}
      />

      {/* Layer 1 (z-10): 3D WebGL Living Flame + Spinning Football Stage */}
      <div ref={stageRef} className="absolute inset-0 z-10 pointer-events-none" />

      {/* Fallback atmospheric glow if WebGL context lost */}
      {webglLost && (
        <div
          aria-hidden="true"
          className="absolute inset-0 z-10 pointer-events-none flex items-center justify-center"
        >
          <div className="w-64 h-64 rounded-full bg-gradient-to-tr from-red-600/40 via-amber-500/35 to-yellow-300/20 animate-pulse" />
        </div>
      )}

      {/* Language Toggle AR / FR on Intro Stage */}
      {onChangeLang && (
        <div className="fixed top-[max(0.75rem,env(safe-area-inset-top))] right-3 sm:right-5 z-30">
          <LanguageToggleButton lang={lang} onChangeLang={onChangeLang} />
        </div>
      )}

      {/* Layer 2 & 3 (z-20): Interactive Clickable Logo Showcase + Frosted Glass Alerts Strip right below PROMOSPORT */}
      <div className="relative z-20 flex flex-col items-center justify-center w-full max-w-xl px-4">
        <button
          type="button"
          onClick={onEnterGrille}
          aria-label={
            lang === 'AR'
              ? 'افتح واجهة القصاصة - بروموسبور'
              : 'Ouvrir la grille Promosport'
          }
          className="flex flex-col items-center justify-center w-full pt-2 pb-1 cursor-pointer group focus:outline-none"
        >
          {/* TOP: Stationary Royal Ruby & Gold "MB" Shield with golden orbital light rings (no radial blur/radiations, no shield spin, fixed colors) */}
          <div
            className={`relative mb-3 sm:mb-4 flex items-center justify-center transition-all duration-700 ease-out ${
              mbRevealed
                ? 'opacity-100 translate-y-0 scale-100'
                : 'opacity-0 -translate-y-12 scale-50 pointer-events-none'
            }`}
          >
            <div className="relative z-10 group-hover:scale-105 transition-transform duration-300">
              <MbLogo size="xl" showLaser={false} showArrows={true} showPlaque={true} />
            </div>
          </div>

        {/* CENTER: Clean Official PROMOSPORT 3D Ribbon Banner (NO "probabilité tactique" & NO "أقوى صفحة بروموسبور في تونس انظموا الينا") */}
        <div
          ref={ribbonRef}
          dir="ltr"
          className="relative w-full max-w-[390px] sm:max-w-[480px] flex items-center justify-center my-4 transition-transform duration-300 group-hover:scale-[1.03] group-active:scale-[0.98]"
        >
          {/* Ambient warm glow directly behind ribbon linking it visually to the 3D flames */}
          <div
            aria-hidden="true"
            className="absolute -inset-x-6 -inset-y-4 pointer-events-none"
            style={{
              background:
                'radial-gradient(ellipse 75% 55% at 55% 50%, rgba(249, 115, 22, 0.28) 0%, transparent 72%)',
            }}
          />

          {/* Metallic 3D Curved PROMOSPORT Banner Ribbon */}
          <svg
            viewBox="0 0 640 156"
            className="w-full h-auto drop-shadow-[0_14px_32px_rgba(0,0,0,0.88)] overflow-visible"
          >
            <defs>
              <linearGradient id="ribbonFrameGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#f8fafc" />
                <stop offset="28%" stopColor="#cbd5e1" />
                <stop offset="52%" stopColor="#fef08a" />
                <stop offset="76%" stopColor="#94a3b8" />
                <stop offset="100%" stopColor="#e2e8f0" />
              </linearGradient>

              <linearGradient id="ribbonBodyGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#081229" />
                <stop offset="20%" stopColor="#0f2347" />
                <stop offset="50%" stopColor="#1e1b4b" />
                <stop offset="78%" stopColor="#7f1d1d" />
                <stop offset="100%" stopColor="#991b1b" />
              </linearGradient>

              <linearGradient id="ribbonGlossGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.42)" />
                <stop offset="55%" stopColor="rgba(255,255,255,0.08)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0)" />
              </linearGradient>

              <linearGradient id="promoWordGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="35%" stopColor="#fca5a5" />
                <stop offset="70%" stopColor="#ef4444" />
                <stop offset="100%" stopColor="#b91c1c" />
              </linearGradient>

              <linearGradient id="sportWordGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="45%" stopColor="#f8fafc" />
                <stop offset="78%" stopColor="#fde047" />
                <stop offset="100%" stopColor="#f59e0b" />
              </linearGradient>

              <linearGradient id="wingRedGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#dc2626" />
                <stop offset="60%" stopColor="#ef4444" />
                <stop offset="100%" stopColor="#f59e0b" />
              </linearGradient>
            </defs>

            <polygon points="10,58 76,42 62,114 2,114" fill="url(#wingRedGrad)" opacity="0.92" />
            <polygon points="576,42 638,42 628,114 562,114" fill="url(#wingRedGrad)" opacity="0.95" />

            <path
              d="M 48 36 C 195 22, 445 22, 598 36 L 578 122 C 435 109, 205 109, 28 122 Z"
              fill="url(#ribbonFrameGrad)"
              stroke="#020617"
              strokeWidth="3"
            />

            <path
              d="M 54 42 C 198 29, 442 29, 591 42 L 573 116 C 432 103, 208 103, 36 116 Z"
              fill="url(#ribbonBodyGrad)"
              stroke="rgba(253, 224, 71, 0.55)"
              strokeWidth="1.6"
            />

            <path
              d="M 58 44 C 198 32, 442 32, 586 44 L 580 74 C 440 64, 200 64, 48 74 Z"
              fill="url(#ribbonGlossGrad)"
            />

            {/* Tunisian Crescent & Star Sport Crest Badge */}
            <g transform="translate(88, 79)">
              <circle cx="0" cy="0" r="19" fill="#b91c1c" stroke="#fef08a" strokeWidth="2.2" />
              <circle cx="1.5" cy="0" r="11" fill="#ffffff" />
              <circle cx="5" cy="0" r="8.5" fill="#b91c1c" />
              <polygon
                points="7,-4 8.2,-1.2 11.2,-1 8.8,0.9 9.7,3.8 7,2.1 4.3,3.8 5.2,0.9 2.8,-1 5.8,-1.2"
                fill="#ffffff"
              />
            </g>

            {/* Bold Italic Bevelled PROMOSPORT Wordmark */}
            <g transform="translate(342, 91) skewX(-9)">
              <text
                x="3"
                y="4"
                textAnchor="middle"
                fontFamily="Chakra Petch, Impact, Arial Black, sans-serif"
                fontSize="50"
                fontWeight="900"
                letterSpacing="2.5"
                fill="#020617"
                opacity="0.92"
              >
                PROMOSPORT
              </text>

              <text
                x="0"
                y="0"
                textAnchor="middle"
                fontFamily="Chakra Petch, Impact, Arial Black, sans-serif"
                fontSize="50"
                fontWeight="900"
                letterSpacing="2.5"
                stroke="#0f172a"
                strokeWidth="2.2"
                paintOrder="stroke"
              >
                <tspan fill="url(#promoWordGrad)">PROMO</tspan>
                <tspan fill="url(#sportWordGrad)">SPORT</tspan>
              </text>
            </g>

            <path
              d="M 46 112 C 208 100, 432 100, 566 112"
              fill="none"
              stroke="#facc15"
              strokeWidth="2"
              opacity="0.82"
            />
          </svg>
        </div>

        </button>

        {/* FROSTED GLASS NOTIFICATIONS BAR DIRECTLY BELOW PROMOSPORT FRAME */}
        <div
          dir={lang === 'AR' ? 'rtl' : 'ltr'}
          className="w-full max-w-[440px] mt-3 rounded-2xl backdrop-blur-md bg-gradient-to-br from-[#07152f]/58 via-[#0b224a]/46 to-[#040d21]/62 border border-sky-300/65 shadow-[0_10px_28px_rgba(0,0,0,0.6),inset_0_0_16px_rgba(56,189,248,0.16)] p-2.5 sm:p-3 space-y-2"
        >
          {/* Strip Header: Centered "تنبيه حي" + Clear Old Notifications Icon */}
          <div className="relative flex items-center justify-between gap-2 pb-1.5 border-b border-white/15">
            <div className="flex items-center gap-1.5 shrink-0">
              <Bell className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
              <span className="text-[11px] font-mono font-black text-amber-200 tabular-nums">
                {liveNotifications.length}
              </span>
            </div>

            <span className="text-[11px] sm:text-xs font-black text-white tracking-wide drop-shadow-[0_1px_4px_rgba(0,0,0,0.95)] truncate">
              {lang === 'AR'
                ? 'تنبيه حي • الصفحة الرئيسية وبقية الخانات'
                : 'Alertes en direct • Accueil & Grilles'}
            </span>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                audioService.playClick();
                onClearNotifications?.();
              }}
              disabled={liveNotifications.length === 0}
              title={
                lang === 'AR'
                  ? 'فسخ الإشعارات القديمة وإظهار الإشعارات الجديدة دوماً'
                  : 'Effacer les anciennes alertes'
              }
              aria-label={lang === 'AR' ? 'فسخ الإشعارات القديمة' : 'Effacer les alertes'}
              className="min-h-[30px] px-2 py-1 rounded-xl bg-red-600/25 hover:bg-red-600/80 disabled:opacity-40 disabled:cursor-not-allowed border border-red-400/70 text-red-100 text-[10.5px] font-black flex items-center gap-1 transition-all cursor-pointer active:scale-95 shrink-0"
            >
              <Trash2 className="w-3 h-3 shrink-0" />
              <span>{lang === 'AR' ? 'فسخ' : 'Effacer'}</span>
            </button>
          </div>

          {/* Live Always-Updating Feed (New notifications always appear automatically, even after clearing) */}
          {liveNotifications.length === 0 ? (
            <div className="py-2.5 text-center text-[11px] text-sky-100/85 font-bold">
              {lang === 'AR'
                ? 'لا توجد إشعارات حالياً — ستظهر الإشعارات الجديدة هنا دوماً فور وصولها.'
                : 'Aucune alerte pour le moment — les nouvelles alertes s’afficheront ici automatiquement.'}
            </div>
          ) : (
            <div className="space-y-1.5 max-h-32 overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
              {liveNotifications.map((item) => {
                const isGoal = item.kind === 'goal';
                const isGrille = item.kind === 'grille' || item.kind === 'winners';
                return (
                  <div
                    key={item.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => onOpenNotification?.(item)}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        onOpenNotification?.(item);
                      }
                    }}
                    aria-label={
                      lang === 'AR'
                        ? `${item.title}. انقر للانتقال إلى الصفحة المناسبة`
                        : `${item.title}. Cliquer pour ouvrir`
                    }
                    title={lang === 'AR' ? 'انقر للانتقال إلى الصفحة المطلوبة' : 'Cliquer pour ouvrir'}
                    className={`flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-xl border cursor-pointer hover:ring-2 hover:ring-yellow-300/70 active:scale-[0.99] transition-all ${
                      isGoal
                        ? 'bg-amber-500/18 border-amber-400/55'
                        : isGrille
                        ? 'bg-cyan-500/15 border-cyan-400/50'
                        : 'bg-slate-900/65 border-white/15'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`shrink-0 w-5 h-5 rounded-lg flex items-center justify-center ${
                          isGoal
                            ? 'bg-amber-400 text-black'
                            : isGrille
                            ? 'bg-cyan-400 text-black'
                            : 'bg-emerald-500 text-black'
                        }`}
                      >
                        {isGoal ? (
                          <Zap className="w-3 h-3" />
                        ) : isGrille ? (
                          <Trophy className="w-3 h-3" />
                        ) : (
                          <Flame className="w-3 h-3" />
                        )}
                      </span>
                      <div className="min-w-0">
                        <div className="text-[11px] font-black text-white truncate">
                          {item.title}
                        </div>
                        <div className="text-[9.5px] text-sky-100/80 truncate">
                          {item.message}
                        </div>
                      </div>
                    </div>
                    <div className="shrink-0 flex flex-col items-end gap-0.5">
                      {item.scoreLabel && (
                        <span
                          dir="ltr"
                          className="text-[10px] font-mono font-black text-yellow-200 tabular-nums"
                        >
                          {item.scoreLabel}
                        </span>
                      )}
                      <span
                        dir="ltr"
                        className="text-[9px] font-mono text-amber-200/90 tabular-nums"
                      >
                        {item.timestamp}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
