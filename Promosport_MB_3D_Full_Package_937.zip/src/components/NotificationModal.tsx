/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Bell,
  Clock,
  Volume2,
  VolumeX,
  Smartphone,
  Save,
  Download,
  Upload,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Trophy,
  CalendarCheck,
  FileText,
  Music2,
  MousePointerClick,
  Radio,
  LayoutGrid,
  Trash2,
  Zap,
  Flame,
} from 'lucide-react';
import { ClickSoundStyle, GoalSoundStyle, LiveNotificationItem, NotificationSettings } from '../types/promosport';
import {
  audioService,
  CLICK_SOUND_OPTIONS,
  GOAL_SOUND_OPTIONS,
} from '../services/audioService';
import { exportBackupJSON, importBackupJSON } from '../services/storageService';
import { ensureDesktopPushSubscribed } from '../services/webPushClient';
import { LanguageToggleButton } from './LanguageToggleButton';

export type NotificationSectionTab = 'live' | 'general';

const GOAL_SOUND_LABELS_FR: Record<GoalSoundStyle, { label: string; description: string }> = {
  'water-droplet': {
    label: 'Double goutte d’eau',
    description: 'Sonnerie claire de goutte d’eau avec écho doux',
  },
  'stadium-whistle': {
    label: 'Sifflet de but & stade',
    description: 'Sifflet d’arbitre dynamique avec ambiance de stade',
  },
  'golden-chime': {
    label: 'Carillon doré',
    description: 'Carillons dorés successifs pour célébrer un but',
  },
};

const CLICK_SOUND_LABELS_FR: Record<ClickSoundStyle, { label: string; durationLabel: string; description: string }> = {
  'soft-tap': {
    label: 'Touche douce',
    durationLabel: '0,06 s',
    description: 'Son tactile léger et rapide',
  },
  'water-drop': {
    label: 'Petite goutte',
    durationLabel: '0,12 s',
    description: 'Petite goutte d’eau à chaque clic',
  },
  'crystal-bell': {
    label: 'Cloche cristal',
    durationLabel: '0,18 s',
    description: 'Note cristalline courte et nette',
  },
};

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: NotificationSettings;
  onSaveSettings: (newSettings: NotificationSettings) => void;
  onImmediateApply?: (newSettings: NotificationSettings) => void;
  onTriggerTestAlert: (section: NotificationSectionTab) => void;
  initialSection?: NotificationSectionTab;
  liveNotifications?: LiveNotificationItem[];
  generalNotifications?: LiveNotificationItem[];
  onClearLiveNotifications?: () => void;
  onClearGeneralNotifications?: () => void;
  onOpenNotificationItem?: (item: LiveNotificationItem) => void;
  lang?: 'AR' | 'FR';
  onChangeLang?: (lang: 'AR' | 'FR') => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onImmediateApply,
  onTriggerTestAlert,
  initialSection = 'general',
  liveNotifications = [],
  generalNotifications = [],
  onClearLiveNotifications,
  onClearGeneralNotifications,
  onOpenNotificationItem,
  lang = 'AR',
  onChangeLang,
}) => {
  const [localSettings, setLocalSettings] = useState<NotificationSettings>({ ...settings });
  const [activeSection, setActiveSection] = useState<NotificationSectionTab>(initialSection);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const localSettingsRef = useRef<NotificationSettings>(localSettings);
  localSettingsRef.current = localSettings;

  useEffect(() => {
    if (isOpen) {
      setLocalSettings({ ...settings });
      setActiveSection(initialSection);
    }
  }, [isOpen, settings, initialSection]);

  if (!isOpen) return null;

  const updateAndActivate = (updater: (prev: NotificationSettings) => NotificationSettings) => {
    const next = updater(localSettingsRef.current);
    localSettingsRef.current = next;
    setLocalSettings(next);
    audioService.setSoundEnabled(next.soundEnabled);
    audioService.setGoalSoundStyle(next.goalSoundStyle);
    audioService.setClickSoundEnabled(next.clickSoundEnabled);
    audioService.setClickSoundStyle(next.clickSoundStyle);
    if (onImmediateApply) {
      onImmediateApply(next);
    }
  };

  const handleToggle = (key: keyof NotificationSettings) => {
    audioService.playClick();
    updateAndActivate((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSelectGoalSound = (style: GoalSoundStyle) => {
    updateAndActivate((prev) => ({
      ...prev,
      soundEnabled: true,
      goalSoundEnabled: true,
      goalSoundStyle: style,
    }));
    audioService.playTimedAlert(style, localSettings.goalSoundDurationSeconds, true);
  };

  const handleSelectNotificationSound = (style: GoalSoundStyle) => {
    updateAndActivate((prev) => ({
      ...prev,
      soundEnabled: true,
      notificationSoundEnabled: true,
      notificationSoundStyle: style,
    }));
    audioService.playTimedAlert(style, localSettings.notificationSoundDurationSeconds, true);
  };

  const handleToggleClickSound = (enabled: boolean) => {
    updateAndActivate((prev) => ({
      ...prev,
      clickSoundEnabled: enabled,
    }));
    if (enabled) {
      audioService.playClick(localSettings.clickSoundStyle);
    }
  };

  const handleSelectClickStyle = (style: ClickSoundStyle) => {
    updateAndActivate((prev) => ({
      ...prev,
      soundEnabled: true,
      clickSoundEnabled: true,
      clickSoundStyle: style,
    }));
    audioService.playClick(style);
  };

  const handleSave = () => {
    audioService.playChime();
    onSaveSettings(localSettings);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleExport = () => {
    audioService.playClick();
    exportBackupJSON(localSettings);
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const imported = await importBackupJSON(file);
      setLocalSettings(imported);
      onSaveSettings(imported);
      audioService.playChime();
      setImportStatus(
        lang === 'AR'
          ? 'تم استيراد كافة الإعدادات والبرومبت بنجاح! ✅'
          : 'Paramètres et configuration importés avec succès ! ✅'
      );
      setTimeout(() => setImportStatus(null), 3000);
    } catch (err) {
      setImportStatus(
        lang === 'AR' ? 'خطأ: الملف المرفوع غير صالح ❌' : 'Erreur : fichier sélectionné invalide ❌'
      );
      setTimeout(() => setImportStatus(null), 3000);
    }
  };

  const requestPushPermission = async () => {
    if (!('Notification' in window)) {
      setImportStatus(
        lang === 'AR'
          ? 'المتصفح الحالي لا يدعم إشعارات النظام المباشرة.'
          : 'Ce navigateur ne prend pas en charge les notifications système.'
      );
      setTimeout(() => setImportStatus(null), 3500);
      return;
    }
    try {
      const { permission, subscribed } = await ensureDesktopPushSubscribed(true);
      if (permission === 'granted') {
        audioService.playChime();
        updateAndActivate((prev) => ({ ...prev, pushNotificationsEnabled: true }));
        setImportStatus(
          subscribed
            ? lang === 'AR'
              ? 'تم تفعيل إشعارات سطح المكتب (مفتوح ومغلق) بنجاح!'
              : 'Notifications bureau (arrière-plan) activées avec succès !'
            : lang === 'AR'
              ? 'تم تفعيل إشعارات سطح المكتب والجهاز بنجاح!'
              : 'Notifications bureau et appareil activées avec succès !'
        );
      } else {
        updateAndActivate((prev) => ({ ...prev, pushNotificationsEnabled: false }));
        setImportStatus(
          lang === 'AR'
            ? 'يرجى السماح بالإشعارات من إعدادات المتصفح لتلقي تنبيهات سطح المكتب.'
            : 'Veuillez autoriser les notifications dans les paramètres du navigateur.'
        );
      }
    } catch {
      updateAndActivate((prev) => ({ ...prev, pushNotificationsEnabled: false }));
    }
    setTimeout(() => setImportStatus(null), 3500);
  };

  return (
    <div
      dir={lang === 'AR' ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/90 md:bg-black/85 md:backdrop-blur-sm animate-fadeIn"
    >
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-stone-950 border border-yellow-500/50 rounded-3xl p-5 sm:p-8 shadow-[0_0_50px_rgba(234,179,8,0.25)] text-white">
        {/* Header */}
        <div className="flex items-center justify-between gap-2 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-3 rounded-2xl bg-yellow-500/10 border border-yellow-500/40 text-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)] shrink-0">
              <Bell className="w-6 h-6 animate-bounce" />
            </div>
            <div className="min-w-0">
              <h2 className="text-lg sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-yellow-400 to-red-500 truncate">
                {lang === 'AR' ? 'منظومة التنبيهات المتقدمة' : 'Centre de notifications avancé'}
              </h2>
              <p className="text-xs text-gray-400 truncate">
                {lang === 'AR'
                  ? 'إدارة الإشعارات الفورية، التحديث التلقائي، والنسخ الاحتياطي'
                  : 'Alertes instantanées, sons, synchronisation et sauvegarde'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onChangeLang && (
              <LanguageToggleButton lang={lang} onChangeLang={onChangeLang} compact />
            )}
            <button
              onClick={() => {
                audioService.playClick();
                onClose();
              }}
              aria-label={lang === 'AR' ? 'إغلاق' : 'Fermer'}
              className="p-2 rounded-full bg-stone-900 hover:bg-stone-800 text-gray-400 hover:text-white border border-stone-700 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {importStatus && (
          <div className="mb-4 p-3 rounded-xl bg-yellow-500/20 border border-yellow-400/50 text-yellow-300 text-xs font-semibold text-center animate-pulse">
            {importStatus}
          </div>
        )}

        {/* Divided Sections Switcher: القسم الأول (خانة المباشر وحدها) | القسم الثاني (بقية الخانات مع الصفحة الرئيسية وحدها) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-6">
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setActiveSection('live');
            }}
            className={`p-3 rounded-2xl border-2 ${lang === 'AR' ? 'text-right' : 'text-left'} transition-all cursor-pointer flex items-center justify-between gap-2 ${
              activeSection === 'live'
                ? 'bg-gradient-to-r from-emerald-500/25 via-emerald-900/40 to-stone-900 border-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.38)]'
                : 'bg-stone-900/70 border-stone-800 text-gray-300 hover:border-emerald-500/50'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className={`p-2 rounded-xl border ${activeSection === 'live' ? 'bg-emerald-400 text-black border-emerald-200' : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'}`}>
                <Radio className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-black truncate">
                  {lang === 'AR' ? 'القسم الأول: خانة المباشر وحدها' : 'Section 1 : Onglet Direct seul'}
                </div>
                <div className="text-[10px] text-emerald-200/80 truncate">
                  {lang === 'AR' ? 'يفعل ويظهر داخل المباشر فقط' : 'Actif uniquement dans Direct'}
                </div>
              </div>
            </div>
            <span className="shrink-0 px-2 py-0.5 rounded-full bg-black/70 border border-emerald-400/60 font-mono text-[11px] font-black text-emerald-300 tabular-nums">
              {liveNotifications.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setActiveSection('general');
            }}
            className={`p-3 rounded-2xl border-2 ${lang === 'AR' ? 'text-right' : 'text-left'} transition-all cursor-pointer flex items-center justify-between gap-2 ${
              activeSection === 'general'
                ? 'bg-gradient-to-r from-yellow-500/25 via-amber-900/35 to-stone-900 border-yellow-400 text-white shadow-[0_0_20px_rgba(250,204,21,0.38)]'
                : 'bg-stone-900/70 border-stone-800 text-gray-300 hover:border-yellow-500/50'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className={`p-2 rounded-xl border ${activeSection === 'general' ? 'bg-yellow-400 text-black border-yellow-200' : 'bg-yellow-500/15 text-yellow-300 border-yellow-500/40'}`}>
                <LayoutGrid className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-black truncate">
                  {lang === 'AR' ? 'القسم الثاني: بقية الخانات والصفحة الرئيسية' : 'Section 2 : Grilles, Tirage & Accueil'}
                </div>
                <div className="text-[10px] text-yellow-200/80 truncate">
                  {lang === 'AR' ? 'القصاصة • Tirage • APK • الرئيسية' : 'Grille • Tirage • APK • Accueil'}
                </div>
              </div>
            </div>
            <span className="shrink-0 px-2 py-0.5 rounded-full bg-black/70 border border-yellow-400/60 font-mono text-[11px] font-black text-yellow-300 tabular-nums">
              {generalNotifications.length}
            </span>
          </button>
        </div>

        {/* SECTION 1: LIVE TAB ONLY */}
        {activeSection === 'live' && (
          <div className="space-y-5 mb-6">
            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-400/45 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-black text-emerald-300">
                  <Radio className="w-4 h-4 shrink-0" />
                  <span>
                    {lang === 'AR'
                      ? `سجل تنبيهات خانة المباشر وحدها (${liveNotifications.length})`
                      : `Journal des alertes Direct (${liveNotifications.length})`}
                  </span>
                </div>
                {liveNotifications.length > 0 && onClearLiveNotifications && (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onClearLiveNotifications();
                    }}
                    className="px-2.5 py-1 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-400/70 text-red-100 text-[10.5px] font-black flex items-center gap-1 cursor-pointer active:scale-95 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{lang === 'AR' ? 'فسخ إشعارات المباشر' : 'Effacer Direct'}</span>
                  </button>
                )}
              </div>

              {liveNotifications.length === 0 ? (
                <div className="py-4 text-center text-xs text-emerald-100/75 font-bold">
                  {lang === 'AR'
                    ? 'لا توجد إشعارات في قسم المباشر حالياً — تفعل وتظهر أهداف وتنبيهات المباريات المباشرة هنا وفي خانة المباشر وحدها.'
                    : 'Aucune alerte Direct pour le moment — les buts et scores en direct apparaissent uniquement ici et dans l’onglet Direct.'}
                </div>
              ) : (
                <div className="space-y-1.5 max-h-48 overflow-y-auto [&::-webkit-scrollbar]:hidden">
                  {liveNotifications.map((item) => (
                    <div
                      key={item.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => {
                        onOpenNotificationItem?.(item);
                        onClose();
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          onOpenNotificationItem?.(item);
                          onClose();
                        }
                      }}
                      className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-black/55 border border-emerald-400/40 hover:border-yellow-300 cursor-pointer transition-all"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="shrink-0 w-6 h-6 rounded-lg bg-amber-400 text-black flex items-center justify-center">
                          {item.kind === 'goal' ? <Zap className="w-3.5 h-3.5" /> : <Flame className="w-3.5 h-3.5" />}
                        </span>
                        <div className="min-w-0">
                          <div className="text-[11px] font-black text-white truncate">{item.title}</div>
                          <div className="text-[9.5px] text-gray-300 truncate">{item.message}</div>
                        </div>
                      </div>
                      <div className="shrink-0 flex flex-col items-end gap-0.5">
                        {item.scoreLabel && (
                          <span dir="ltr" className="text-[10px] font-mono font-black text-yellow-200 tabular-nums">
                            {item.scoreLabel}
                          </span>
                        )}
                        <span dir="ltr" className="text-[9px] font-mono text-emerald-300/90 tabular-nums">
                          {item.timestamp}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* SECTION 2: HOME PAGE + REMAINING TABS ONLY */}
        {activeSection === 'general' && (
          <>
            <div className="mb-6 p-4 rounded-2xl bg-amber-950/25 border border-yellow-400/45 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-black text-yellow-300">
                  <LayoutGrid className="w-4 h-4 shrink-0" />
                  <span>
                    {lang === 'AR'
                      ? `سجل إشعارات بقية الخانات والصفحة الرئيسية (${generalNotifications.length})`
                      : `Journal Accueil & Grilles (${generalNotifications.length})`}
                  </span>
                </div>
                {generalNotifications.length > 0 && onClearGeneralNotifications && (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onClearGeneralNotifications();
                    }}
                    className="px-2.5 py-1 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-400/70 text-red-100 text-[10.5px] font-black flex items-center gap-1 cursor-pointer active:scale-95 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{lang === 'AR' ? 'فسخ إشعارات القسم الثاني' : 'Effacer Section 2'}</span>
                  </button>
                )}
              </div>

              {generalNotifications.length === 0 ? (
                <div className="py-4 text-center text-xs text-yellow-100/75 font-bold">
                  {lang === 'AR'
                    ? 'لا توجد إشعارات حالياً — تفعل وتظهر إشعارات القصاصات الجديدة والجوائز الكبرى والمرابيح في الصفحة الرئيسية وبقية الخانات وحدها.'
                    : 'Aucune alerte — les nouvelles grilles, cagnottes et rapports s’affichent sur l’accueil et ces onglets.'}
                </div>
              ) : (
                <div className="space-y-1.5 max-h-48 overflow-y-auto [&::-webkit-scrollbar]:hidden">
                  {generalNotifications.map((item) => (
                    <div
                      key={item.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => {
                        onOpenNotificationItem?.(item);
                        onClose();
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          onOpenNotificationItem?.(item);
                          onClose();
                        }
                      }}
                      className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-black/55 border border-yellow-400/40 hover:border-cyan-300 cursor-pointer transition-all"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="shrink-0 w-6 h-6 rounded-lg bg-cyan-400 text-black flex items-center justify-center">
                          <Trophy className="w-3.5 h-3.5" />
                        </span>
                        <div className="min-w-0">
                          <div className="text-[11px] font-black text-white truncate">{item.title}</div>
                          <div className="text-[9.5px] text-gray-300 truncate">{item.message}</div>
                        </div>
                      </div>
                      <div className="shrink-0 flex flex-col items-end gap-0.5">
                        {item.scoreLabel && (
                          <span dir="ltr" className="text-[10px] font-mono font-black text-yellow-200 tabular-nums">
                            {item.scoreLabel}
                          </span>
                        )}
                        <span dir="ltr" className="text-[9px] font-mono text-amber-200/90 tabular-nums">
                          {item.timestamp}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

        {/* Section 1: Specific Alert Toggles */}
        <div className="space-y-4 mb-6">
          <h3 className="text-sm font-bold text-yellow-400 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-yellow-400" />
            {lang === 'AR' ? 'تخصيص وتفعيل التنبيهات المحددة' : 'Personnaliser les alertes'}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* 1. New Grilles */}
            <div
              onClick={() => handleToggle('notifyNewGrille')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyNewGrille
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <FileText
                  className={`w-5 h-5 ${
                    localSettings.notifyNewGrille ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">
                    {lang === 'AR' ? 'صدور القصاصات الجديدة' : 'Nouvelles grilles publiées'}
                  </div>
                  <div className="text-[11px] text-gray-400">
                    {lang === 'AR' ? 'تنبيه فوري عند نشر مسابقة جديدة' : 'Alerte immédiate à chaque nouveau concours'}
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyNewGrille
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyNewGrille && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 2. Official Results & Winners */}
            <div
              onClick={() => handleToggle('notifyOfficialResults')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyOfficialResults
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <Trophy
                  className={`w-5 h-5 ${
                    localSettings.notifyOfficialResults ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">
                    {lang === 'AR' ? 'إعلان النتائج الرسمية والفائزين' : 'Résultats officiels & gagnants'}
                  </div>
                  <div className="text-[11px] text-gray-400">
                    {lang === 'AR' ? 'نتائج المباريات وقيمة الأرباح' : 'Scores officiels et rapports de gains'}
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyOfficialResults
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyOfficialResults && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 3. Jackpot Rollover */}
            <div
              onClick={() => handleToggle('notifyJackpotRollover')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyJackpotRollover
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <Sparkles
                  className={`w-5 h-5 ${
                    localSettings.notifyJackpotRollover ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">
                    {lang === 'AR' ? 'ترحيل الجوائز الكبرى (Cagnotte)' : 'Report de cagnotte'}
                  </div>
                  <div className="text-[11px] text-gray-400">
                    {lang === 'AR' ? 'إشعار عند ترحيل مبالغ قياسية' : 'Alerte en cas de cagnotte record'}
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyJackpotRollover
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyJackpotRollover && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 4. Closing countdown alerts */}
            <div
              onClick={() => handleToggle('notifyClosingCountdown')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyClosingCountdown
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <CalendarCheck
                  className={`w-5 h-5 ${
                    localSettings.notifyClosingCountdown ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">
                    {lang === 'AR' ? 'تنبيهات موعد غلق المسابقة' : 'Rappel de clôture du concours'}
                  </div>
                  <div className="text-[11px] text-gray-400">
                    {lang === 'AR' ? 'تذكير قبل انتهاء أجل التحقق' : 'Rappel avant la fin de validation'}
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyClosingCountdown
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyClosingCountdown && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 5. Sound effects */}
            <div
              onClick={() => handleToggle('soundEnabled')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.soundEnabled
                  ? 'bg-gradient-to-r from-emerald-500/20 to-stone-900 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                {localSettings.soundEnabled ? (
                  <Volume2 className="w-5 h-5 text-emerald-400 animate-pulse" />
                ) : (
                  <VolumeX className="w-5 h-5 text-gray-500" />
                )}
                <div>
                  <div className="text-xs font-bold">
                    {lang === 'AR' ? 'النغمات الصوتية التفاعلية' : 'Effets sonores interactifs'}
                  </div>
                  <div className="text-[11px] text-gray-400">
                    {lang === 'AR' ? 'أصوات التنبيه والنقر والموجات الذهبية' : 'Sons d’alerte, de clic et carillons'}
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.soundEnabled
                    ? 'border-emerald-400 bg-emerald-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.soundEnabled && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 6. Push Notifications */}
            <div
              onClick={requestPushPermission}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.pushNotificationsEnabled
                  ? 'bg-gradient-to-r from-cyan-500/20 to-stone-900 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <Smartphone
                  className={`w-5 h-5 ${
                    localSettings.pushNotificationsEnabled ? 'text-cyan-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">
                    {lang === 'AR' ? 'إشعارات سطح المكتب (مفتوح أو مغلق)' : 'Notifications système (Push)'}
                  </div>
                  <div className="text-[11px] text-gray-400">
                    {lang === 'AR' ? 'وصول الأهداف والقصاصات لسطح المكتب دوماً' : 'Réception continue même hors écran'}
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.pushNotificationsEnabled
                    ? 'border-cyan-400 bg-cyan-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.pushNotificationsEnabled && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6 p-4 rounded-2xl bg-stone-900/70 border border-cyan-500/35 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black text-cyan-300">
              <Bell className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'AR'
                  ? 'صوت إشعارات القصاصة والقيمة المالية والمرابيح'
                  : 'Son des alertes Grilles, Cagnotte & Gains'}
              </span>
            </div>
            <button type="button" onClick={() => handleToggle('notificationSoundEnabled')} className={`px-3 py-1.5 rounded-lg text-[11px] font-black cursor-pointer ${localSettings.notificationSoundEnabled ? 'bg-emerald-500 text-black' : 'bg-red-600 text-white'}`}>
              {localSettings.notificationSoundEnabled
                ? lang === 'AR' ? 'مفعل' : 'Activé'
                : lang === 'AR' ? 'صامت' : 'Muet'}
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {GOAL_SOUND_OPTIONS.map((opt) => (
              <button key={`notification-${opt.id}`} type="button" onClick={() => handleSelectNotificationSound(opt.id)} className={`min-h-[42px] p-2.5 rounded-xl border ${lang === 'AR' ? 'text-right' : 'text-left'} text-xs font-black transition-all cursor-pointer ${localSettings.notificationSoundStyle === opt.id && localSettings.notificationSoundEnabled ? 'bg-cyan-500/20 border-cyan-300 text-cyan-100' : 'bg-stone-950/80 border-stone-800 text-gray-300 hover:border-cyan-500/40'}`}>
                {lang === 'AR' ? opt.label : GOAL_SOUND_LABELS_FR[opt.id]?.label || opt.label}
                {localSettings.notificationSoundStyle === opt.id && localSettings.notificationSoundEnabled && <CheckCircle2 className="inline w-3.5 h-3.5 mx-1 text-cyan-300" />}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[11px]">
            <span className="text-gray-300 font-bold">
              {lang === 'AR' ? 'مدة صوت الإشعار:' : 'Durée du son :'}
            </span>
            {[1, 2, 3, 5].map((seconds) => (
              <button key={`notification-duration-${seconds}`} type="button" onClick={() => updateAndActivate((prev) => ({ ...prev, notificationSoundDurationSeconds: seconds as 1 | 2 | 3 | 5 }))} className={`px-3 py-1.5 rounded-lg border font-black cursor-pointer ${localSettings.notificationSoundDurationSeconds === seconds ? 'bg-cyan-400 text-black border-cyan-200' : 'bg-stone-950 text-gray-300 border-stone-700'}`}>
                {seconds} {lang === 'AR' ? 'ث' : 's'}
              </button>
            ))}
          </div>
        </div>
          </>
        )}

        {/* Goal sounds: strictly Section 1 (Live tab only) */}
        {activeSection === 'live' && (
        <div className="mb-6 p-4 rounded-2xl bg-stone-900/70 border border-yellow-500/35 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black text-yellow-400">
              <Music2 className="w-4 h-4 shrink-0" />
              <span>{lang === 'AR' ? 'اختيار صوت الأهداف ومدته' : 'Sonnerie des buts & durée'}</span>
            </div>
            <button type="button" onClick={() => handleToggle('goalSoundEnabled')} className={`px-3 py-1.5 rounded-lg text-[11px] font-black cursor-pointer ${localSettings.goalSoundEnabled ? 'bg-emerald-500 text-black' : 'bg-red-600 text-white'}`}>
              {localSettings.goalSoundEnabled
                ? lang === 'AR' ? 'مفعل' : 'Activé'
                : lang === 'AR' ? 'صامت' : 'Muet'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {GOAL_SOUND_OPTIONS.map((opt) => {
              const isSelected = localSettings.goalSoundStyle === opt.id;
              const optText = lang === 'AR' ? opt : GOAL_SOUND_LABELS_FR[opt.id] || opt;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleSelectGoalSound(opt.id)}
                  className={`min-h-[44px] p-3 rounded-xl border ${lang === 'AR' ? 'text-right' : 'text-left'} transition-all duration-200 cursor-pointer flex flex-col justify-between gap-1.5 active:scale-95 ${
                    isSelected
                      ? 'bg-gradient-to-br from-yellow-400/25 via-amber-500/15 to-red-600/20 border-yellow-400 shadow-[0_0_16px_rgba(234,179,8,0.4)]'
                      : 'bg-stone-950/80 border-stone-800 hover:border-yellow-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-xs font-black ${isSelected ? 'text-yellow-300' : 'text-gray-200'}`}>
                      {optText.label}
                    </span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />}
                  </div>
                  <p className="text-[10.5px] text-gray-400 leading-snug">{optText.description}</p>
                  <div className="flex items-center justify-between pt-1 border-t border-white/10 text-[10.5px] font-bold">
                    <span className="text-gray-400">{lang === 'AR' ? 'مدة الصوت:' : 'Durée :'}</span>
                    <span className="text-cyan-300 font-mono tabular-nums">{localSettings.goalSoundDurationSeconds} {lang === 'AR' ? 'ث' : 's'}</span>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[11px]">
            <span className="text-gray-300 font-bold">{lang === 'AR' ? 'مدة صوت الهدف:' : 'Durée du but :'}</span>
            {[1, 2, 3, 5].map((seconds) => (
              <button key={`goal-duration-${seconds}`} type="button" onClick={() => updateAndActivate((prev) => ({ ...prev, goalSoundDurationSeconds: seconds as 1 | 2 | 3 | 5 }))} className={`px-3 py-1.5 rounded-lg border font-black cursor-pointer ${localSettings.goalSoundDurationSeconds === seconds ? 'bg-yellow-400 text-black border-yellow-200' : 'bg-stone-950 text-gray-300 border-stone-700'}`}>
                {seconds} {lang === 'AR' ? 'ث' : 's'}
              </button>
            ))}
          </div>
        </div>
        )}

        {/* Section 3: Click Interaction Sound (On/Off + 3 Styles, always active) */}
        <div className="mb-6 p-4 rounded-2xl bg-stone-900/70 border border-cyan-500/35 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black text-cyan-300">
              <MousePointerClick className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'AR'
                  ? 'صوت النقر على كل خانة أو أيقونة (مفعل دوماً)'
                  : 'Son au clic sur chaque bouton (toujours actif)'}
              </span>
            </div>

            <div className="flex items-center gap-1.5 bg-stone-950 p-1 rounded-xl border border-stone-800">
              <button
                type="button"
                onClick={() => handleToggleClickSound(true)}
                className={`min-h-[36px] px-3 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                  localSettings.clickSoundEnabled
                    ? 'bg-emerald-500 text-black shadow'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {lang === 'AR' ? 'يصدر صوت ✓' : 'Son activé ✓'}
              </button>
              <button
                type="button"
                onClick={() => handleToggleClickSound(false)}
                className={`min-h-[36px] px-3 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                  !localSettings.clickSoundEnabled
                    ? 'bg-red-600 text-white shadow'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {lang === 'AR' ? 'بدون صوت (صامت)' : 'Muet'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {CLICK_SOUND_OPTIONS.map((styleOpt) => {
              const isSelected = localSettings.clickSoundStyle === styleOpt.id && localSettings.clickSoundEnabled;
              const styleText = lang === 'AR' ? styleOpt : CLICK_SOUND_LABELS_FR[styleOpt.id] || styleOpt;
              return (
                <button
                  key={styleOpt.id}
                  type="button"
                  onClick={() => handleSelectClickStyle(styleOpt.id)}
                  className={`min-h-[44px] p-2.5 rounded-xl border ${lang === 'AR' ? 'text-right' : 'text-left'} transition-all duration-200 cursor-pointer flex flex-col justify-between gap-1 active:scale-95 ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_14px_rgba(34,211,238,0.35)]'
                      : localSettings.clickSoundEnabled
                        ? 'bg-stone-950/80 border-stone-800 hover:border-cyan-500/40 text-gray-300'
                        : 'bg-stone-950/40 border-stone-800/60 text-gray-500 hover:border-cyan-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-black">{styleText.label}</span>
                    <span className="text-[10px] font-mono text-cyan-300 tabular-nums">{styleText.durationLabel}</span>
                  </div>
                  <span className="text-[10px] text-gray-400">{styleText.description}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 4: Alert Duration Choice */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-yellow-400 mb-2 flex items-center gap-1.5">
            <Clock className="w-4 h-4" />
            {lang === 'AR'
              ? 'مدة استمرار التنبيه عند وصول قصاصة جديدة:'
              : 'Durée d’affichage de la bannière d’alerte :'}
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { label: lang === 'AR' ? '5 ثواني' : '5 s', val: 5 },
              { label: lang === 'AR' ? '10 ثواني' : '10 s', val: 10 },
              { label: lang === 'AR' ? '15 ثانية' : '15 s', val: 15 },
              { label: lang === 'AR' ? 'حتى الإغلاق' : 'Jusqu’à fermeture', val: 0 },
            ].map((item) => {
              const isSelected = localSettings.durationSeconds === item.val;
              return (
                <button
                  key={item.val}
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    updateAndActivate((prev) => ({ ...prev, durationSeconds: item.val as 5 | 10 | 15 | 0 }));
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all duration-300 cursor-pointer ${
                    isSelected
                      ? 'bg-yellow-500 text-black border-yellow-300 shadow-[0_0_15px_rgba(234,179,8,0.5)] scale-102'
                      : 'bg-stone-900 text-gray-400 border-stone-800 hover:border-stone-700'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 3: Automatic Check Frequency */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-yellow-400 mb-2 flex items-center gap-1.5">
            <RefreshCw className="w-4 h-4" />
            {lang === 'AR' ? 'تردد فحص التحديثات التلقائي:' : 'Fréquence de synchronisation automatique :'}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: lang === 'AR' ? 'كل ربع ساعة (15 دقيقة)' : 'Toutes les 15 min', val: 15 },
              { label: lang === 'AR' ? 'كل نصف ساعة (30 دقيقة)' : 'Toutes les 30 min', val: 30 },
              { label: lang === 'AR' ? 'كل ساعة كاملة (60 دقيقة)' : 'Toutes les 60 min', val: 60 },
            ].map((item) => {
              const isSelected = localSettings.checkIntervalMinutes === item.val;
              return (
                <button
                  key={item.val}
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setLocalSettings((prev) => ({
                      ...prev,
                      checkIntervalMinutes: item.val as 15 | 30 | 60,
                    }));
                  }}
                  className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all duration-300 cursor-pointer ${
                    isSelected
                      ? 'bg-red-600 text-white border-yellow-400 shadow-[0_0_15px_rgba(220,38,38,0.6)] scale-102'
                      : 'bg-stone-900 text-gray-400 border-stone-800 hover:border-stone-700'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 4: Backup & Prompt Export/Import */}
        <div className="mb-8 p-4 rounded-2xl bg-stone-900/60 border border-stone-800">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <div className="text-xs font-bold text-gray-200">
                {lang === 'AR' ? 'النسخ الاحتياطي والبرومبت كاملاً (JSON)' : 'Sauvegarde & configuration complète (JSON)'}
              </div>
              <div className="text-[11px] text-gray-400">
                {lang === 'AR' ? 'حفظ الإعدادات والمواصفات ومزامنتها في أي وقت' : 'Exporter ou importer vos préférences à tout moment'}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleExport}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-yellow-400 text-xs font-bold transition-all active:scale-95 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{lang === 'AR' ? 'تنزيل البرومبت JSON' : 'Exporter JSON'}</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-gray-300 hover:text-white text-xs font-bold transition-all active:scale-95 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{lang === 'AR' ? 'استيراد ملف' : 'Importer fichier'}</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleImportFile}
              />
            </div>
          </div>
        </div>

        {/* Footer Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-stone-800">
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onTriggerTestAlert(activeSection);
            }}
            className="w-full sm:w-auto px-4 py-2.5 rounded-2xl bg-stone-900 hover:bg-stone-800 border border-stone-700 text-xs font-bold text-gray-300 hover:text-white transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span>
              {activeSection === 'live'
                ? lang === 'AR' ? 'تجربة تنبيه المباشر (القسم الأول)' : 'Tester alerte Direct (Section 1)'
                : lang === 'AR' ? 'تجربة تنبيه القصاصة (القسم الثاني)' : 'Tester alerte Grille (Section 2)'}
            </span>
          </button>

          {/* Dedicated glowing save button as requested */}
          <button
            type="button"
            onClick={handleSave}
            className={`w-full sm:w-auto px-6 py-2.5 rounded-2xl font-black text-xs transition-all duration-300 flex items-center justify-center gap-2 active:scale-95 cursor-pointer ${
              savedSuccess
                ? 'bg-emerald-500 text-black border border-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.8)]'
                : 'bg-gradient-to-r from-yellow-500 via-amber-400 to-yellow-600 text-black border border-yellow-300 shadow-[0_0_25px_rgba(234,179,8,0.7)] hover:shadow-[0_0_35px_rgba(234,179,8,1)] animate-gold-pulse'
            }`}
          >
            {savedSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>{lang === 'AR' ? 'تم الحفظ والتفعيل الفوري!' : 'Enregistré et activé !'}</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4 animate-pulse" />
                <span>{lang === 'AR' ? 'حفظ وتفعيل التحديث التلقائي دوماً' : 'Enregistrer et activer'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
