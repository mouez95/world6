/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download, Smartphone, WifiOff, X, ExternalLink, CheckCircle2, Chrome } from 'lucide-react';
import { usePWAInstall, useOnlineStatus } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  lang?: 'AR' | 'FR';
  onOpenInstallHub?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  lang = 'AR',
  onOpenInstallHub,
}) => {
  const {
    isInstallable,
    isInstalled,
    isIOS,
    autoInstallRequested,
    dismissAutoInstall,
    install,
  } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  if (isInstalled) {
    return null;
  }

  const handleInstallClick = async () => {
    const res = await install();
    if (res === 'accepted') {
      setJustInstalled(true);
      dismissAutoInstall();
      setTimeout(() => setJustInstalled(false), 3500);
    } else if (res === 'unavailable' && onOpenInstallHub) {
      dismissAutoInstall();
      onOpenInstallHub();
    }
  };

  if (justInstalled) {
    return (
      <div
        dir={lang === 'AR' ? 'rtl' : 'ltr'}
        className="fixed bottom-[max(5rem,calc(env(safe-area-inset-bottom)+4.5rem))] left-3 z-30 flex items-center gap-1.5 rounded-xl bg-emerald-600/95 border border-emerald-200 px-3 py-1.5 text-xs font-black text-white shadow-lg"
      >
        <CheckCircle2 className="w-4 h-4" />
        <span>
          {lang === 'AR' ? 'تم تثبيت التطبيق بنجاح!' : 'Application installée avec succès !'}
        </span>
      </div>
    );
  }

  // Prominent banner when launched with ?install=1 in full Chrome tab
  if (autoInstallRequested) {
    return (
      <div
        dir={lang === 'AR' ? 'rtl' : 'ltr'}
        className="fixed top-[max(5rem,calc(env(safe-area-inset-top)+4.25rem))] inset-x-3 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 sm:w-full sm:max-w-md z-50 rounded-2xl bg-[#07152e]/95 border-2 border-yellow-400 p-4 shadow-[0_0_30px_rgba(250,204,21,0.55)] md:backdrop-blur-md text-white space-y-2.5"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-yellow-300 font-black text-sm">
            <Chrome className="w-5 h-5 text-cyan-400" />
            <span>
              {lang === 'AR'
                ? 'جاهز للتثبيت على Google Chrome'
                : 'Prêt à installer sur Google Chrome'}
            </span>
          </div>
          <button
            type="button"
            onClick={dismissAutoInstall}
            className="p-1 rounded-lg bg-white/10 hover:bg-white/20 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isInstallable ? (
          <button
            type="button"
            onClick={handleInstallClick}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-black font-black text-xs shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>
              {lang === 'AR'
                ? 'اضغط هنا لتثبيت التطبيق على الشاشة الرئيسية'
                : 'Appuyez ici pour installer sur l’écran d’accueil'}
            </span>
          </button>
        ) : (
          <div className="space-y-2 text-[11px] text-gray-200 leading-relaxed">
            {lang === 'AR' ? (
              <p>
                اضغط على قائمة المتصفح <strong className="text-yellow-300">(⋮)</strong> في أعلى الشاشة ثم اختر{' '}
                <strong className="text-white">«تثبيت التطبيق» (Install App)</strong> أو{' '}
                <strong className="text-white">«إضافة إلى الشاشة الرئيسية»</strong>.
              </p>
            ) : (
              <p>
                Ouvrez le menu <strong className="text-yellow-300">(⋮)</strong> du navigateur puis sélectionnez{' '}
                <strong className="text-white">« Installer l’application »</strong> ou{' '}
                <strong className="text-white">« Ajouter à l’écran d’accueil »</strong>.
              </p>
            )}
            {onOpenInstallHub && (
              <button
                type="button"
                onClick={handleInstallClick}
                className="w-full py-2 rounded-xl bg-sky-500 text-black font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>
                  {lang === 'AR'
                    ? 'فتح مركز الحلول والتنزيل الكامل'
                    : 'Ouvrir le centre d’installation'}
                </span>
              </button>
            )}
          </div>
        )}
      </div>
    );
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={handleInstallClick}
        className="fixed bottom-[max(5rem,calc(env(safe-area-inset-bottom)+4.5rem))] left-3 z-30 flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-400 border border-white/80 px-3 py-1.5 text-xs font-black text-black shadow-[0_0_18px_rgba(56,189,248,0.75)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
      >
        <Download className="w-3.5 h-3.5" />
        <span>{lang === 'AR' ? 'تثبيت التطبيق' : 'Installer l’app'}</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="fixed bottom-[max(5rem,calc(env(safe-area-inset-bottom)+4.5rem))] left-3 z-30 flex items-center gap-1.5 rounded-xl bg-[#091730]/95 border border-yellow-400/80 px-3 py-1.5 text-xs font-black text-yellow-200 shadow-lg hover:bg-[#0f254d] cursor-pointer"
        >
          <Smartphone className="w-3.5 h-3.5 text-yellow-300" />
          <span>{lang === 'AR' ? 'تثبيت على iOS' : 'Installer sur iOS'}</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 md:bg-black/75 md:backdrop-blur-sm p-4">
            <div
              dir={lang === 'AR' ? 'rtl' : 'ltr'}
              className="w-full max-w-sm rounded-2xl bg-[#07142b] border-2 border-yellow-400/80 p-5 shadow-2xl text-white space-y-3"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-yellow-300">
                  {lang === 'AR' ? 'تثبيت التطبيق على iPhone / iPad' : 'Installer sur iPhone / iPad'}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded-lg bg-white/10 hover:bg-white/20 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              {lang === 'AR' ? (
                <ol className="text-xs text-gray-200 space-y-2 list-decimal pr-4 leading-relaxed">
                  <li>افتح هذا الرابط في متصفح <strong>Safari</strong> على هاتفك.</li>
                  <li>اضغط على زر <strong>المشاركة (Share)</strong> أسفل الشاشة.</li>
                  <li>اختر <strong>إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.</li>
                </ol>
              ) : (
                <ol className="text-xs text-gray-200 space-y-2 list-decimal pl-4 leading-relaxed">
                  <li>Ouvrez ce lien dans <strong>Safari</strong>.</li>
                  <li>Touchez le bouton <strong>Partager (Share)</strong> en bas.</li>
                  <li>Choisissez <strong>Sur l’écran d’accueil</strong>.</li>
                </ol>
              )}
              {onOpenInstallHub && (
                <button
                  type="button"
                  onClick={() => {
                    setShowIOSGuide(false);
                    onOpenInstallHub();
                  }}
                  className="w-full py-2 rounded-xl bg-yellow-400 text-black font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>
                    {lang === 'AR' ? 'عرض جميع حلول التنزيل' : 'Voir toutes les options'}
                  </span>
                </button>
              )}
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

export const OfflineIndicator: React.FC<{ lang?: 'AR' | 'FR' }> = ({ lang = 'AR' }) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      dir={lang === 'AR' ? 'rtl' : 'ltr'}
      className="fixed bottom-[max(1rem,env(safe-area-inset-bottom))] left-3 sm:left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600/95 border border-yellow-200 px-3 py-1.5 text-xs font-black text-white shadow-[0_0_16px_rgba(245,158,11,0.75)]"
    >
      <WifiOff className="w-3.5 h-3.5 animate-pulse" />
      <span>
        {lang === 'AR'
          ? 'وضع عدم الاتصال — التطبيق يعمل بالبيانات المحفوظة'
          : 'Mode hors ligne — Données locales actives'}
      </span>
    </div>
  );
};
