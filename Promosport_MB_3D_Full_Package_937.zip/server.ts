/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import { createServer as createHttpServer } from 'node:http';
import path from 'node:path';
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import * as webpush from 'web-push';
import JSZip from 'jszip';
import {
  INITIAL_GRILLES,
  INITIAL_WEEKLY_CONCOURS,
  archiveConcoursToGrille,
  mergeGrilleArchives,
} from './src/services/promosportData.ts';
import { evaluateConcoursRealTime, isConcoursCompletelyFinished } from './src/services/matchLiveService.ts';
import { enrichConcoursWithDirectLiveFeeds, mergeConcoursPreservingScores } from './src/services/liveFootballFeed.ts';
import {
  fetchPromosportPronosticFullScan,
  scanPromosportLiveCatalogHtml,
  fetchRapidLiveMap,
  applyRapidToLiveMatches,
  PROMOSPORT_PRONOSTIC_HOME_URL,
} from './src/services/promosportSiteParser.ts';
import type { PromosportGrille, WeeklyConcours, SiteLiveMatch, SiteLiveScanPayload } from './src/types/promosport.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;

interface ServerSyncCache {
  activeConcours: WeeklyConcours;
  grilles: PromosportGrille[];
  syncedAt: string;
  lastAttemptMs: number;
  lastRemoteSuccessMs: number;
}

const syncCache: ServerSyncCache = {
  activeConcours: INITIAL_WEEKLY_CONCOURS,
  grilles: [...INITIAL_GRILLES],
  syncedAt: new Date().toISOString(),
  lastAttemptMs: 0,
  lastRemoteSuccessMs: 0,
};

const TIRAGE_ARCHIVE_STORE_PATH = path.join(os.tmpdir(), 'promosport-tirage-archive.json');
let inFlightProbePromise: Promise<void> | null = null;

async function initSyncArchiveStore(): Promise<void> {
  try {
    if (!existsSync(TIRAGE_ARCHIVE_STORE_PATH)) return;
    const raw = await fs.readFile(TIRAGE_ARCHIVE_STORE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as { activeConcours?: WeeklyConcours; grilles?: PromosportGrille[] };
    if (
      parsed.activeConcours &&
      typeof parsed.activeConcours.number === 'number' &&
      parsed.activeConcours.number >= INITIAL_WEEKLY_CONCOURS.number &&
      Array.isArray(parsed.activeConcours.matches) &&
      parsed.activeConcours.matches.length > 0
    ) {
      syncCache.activeConcours = parsed.activeConcours;
    }
    if (Array.isArray(parsed.grilles) && parsed.grilles.length > 0) {
      syncCache.grilles = mergeGrilleArchives(INITIAL_GRILLES, parsed.grilles);
    }
  } catch {
    // ignore cache read errors
  }
}

async function persistSyncArchiveStore(): Promise<void> {
  try {
    await fs.writeFile(
      TIRAGE_ARCHIVE_STORE_PATH,
      JSON.stringify({
        activeConcours: syncCache.activeConcours,
        grilles: syncCache.grilles.slice(0, 15),
        updatedAt: syncCache.syncedAt,
      }),
      'utf-8'
    );
  } catch {
    // ignore disk cache write errors
  }
}

// ============================================================================
// SERVER WEB PUSH (VAPID) ENGINE — Delivers desktop notifications when closed
// ============================================================================
interface PushStoreFile {
  publicKey: string;
  privateKey: string;
  subscriptions: webpush.PushSubscription[];
}

const PUSH_STORE_PATH = path.join(os.tmpdir(), 'promosport-tunisie-push-store.json');
let pushKeys: { publicKey: string; privateKey: string } | null = null;
const pushSubscriptions = new Map<string, webpush.PushSubscription>();

async function initPushStore(): Promise<void> {
  try {
    if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
      pushKeys = {
        publicKey: process.env.VAPID_PUBLIC_KEY,
        privateKey: process.env.VAPID_PRIVATE_KEY,
      };
    } else if (existsSync(PUSH_STORE_PATH)) {
      const raw = await fs.readFile(PUSH_STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<PushStoreFile>;
      if (parsed.publicKey && parsed.privateKey) {
        pushKeys = { publicKey: parsed.publicKey, privateKey: parsed.privateKey };
      }
      if (Array.isArray(parsed.subscriptions)) {
        for (const sub of parsed.subscriptions) {
          if (sub && typeof sub.endpoint === 'string') {
            pushSubscriptions.set(sub.endpoint, sub);
          }
        }
      }
    }
  } catch {
    // fallback to fresh keypair generation
  }

  if (!pushKeys) {
    pushKeys = webpush.generateVAPIDKeys();
    await persistPushStore();
  }

  try {
    webpush.setVapidDetails(
      'mailto:alerts@promosport-tunisie.local',
      pushKeys.publicKey,
      pushKeys.privateKey
    );
  } catch {
    // ignore VAPID config error
  }
}

async function persistPushStore(): Promise<void> {
  if (!pushKeys) return;
  const payload: PushStoreFile = {
    publicKey: pushKeys.publicKey,
    privateKey: pushKeys.privateKey,
    subscriptions: Array.from(pushSubscriptions.values()),
  };
  await fs.writeFile(PUSH_STORE_PATH, JSON.stringify(payload), 'utf-8').catch(() => {});
}

async function broadcastDesktopPush(payload: {
  title: string;
  body: string;
  concoursNumber?: number;
  tag?: string;
  targetTab?: 'grille' | 'tirage' | 'live' | 'apk';
}): Promise<number> {
  if (!pushKeys || pushSubscriptions.size === 0) return 0;
  const messageStr = JSON.stringify(payload);
  let sentCount = 0;
  const expiredEndpoints: string[] = [];

  await Promise.all(
    Array.from(pushSubscriptions.entries()).map(async ([endpoint, sub]) => {
      try {
        await webpush.sendNotification(sub, messageStr, { TTL: 1800 });
        sentCount += 1;
      } catch (err: unknown) {
        const statusCode = (err as { statusCode?: number })?.statusCode;
        if (statusCode === 404 || statusCode === 410) {
          expiredEndpoints.push(endpoint);
        }
      }
    })
  );

  if (expiredEndpoints.length > 0) {
    for (const ep of expiredEndpoints) {
      pushSubscriptions.delete(ep);
    }
    void persistPushStore();
  }
  return sentCount;
}

// Baseline snapshots for detecting server-side goal, new grille, and winners events
let serverPrevConcoursNumber = INITIAL_WEEKLY_CONCOURS.number;
let serverPrevActivePrize = {
  concoursNumber: INITIAL_WEEKLY_CONCOURS.number,
  value: String(INITIAL_WEEKLY_CONCOURS.cagnotteEstimate || '').trim(),
};
const serverPrevMatchSnap = new Map<number, { status: string; home: number; away: number; hasScore: boolean }>();
let serverPrevWinnersSig = '';
const serverPrevLiveCatalogScores = new Map<string, { home: number; away: number }>();

function evaluateAndDispatchConcoursPushes(concours: WeeklyConcours, grilles: PromosportGrille[]): void {
  if (pushSubscriptions.size === 0) {
    serverPrevConcoursNumber = concours.number;
    serverPrevActivePrize = {
      concoursNumber: concours.number,
      value: String(concours.cagnotteEstimate || '').trim(),
    };
    serverPrevMatchSnap.clear();
    for (const m of concours.matches) {
      const hasScore = !m.isDelayed && m.scoreHome !== undefined && m.scoreAway !== undefined;
      serverPrevMatchSnap.set(m.id, {
        status: m.status,
        home: Number(m.scoreHome || 0),
        away: Number(m.scoreAway || 0),
        hasScore,
      });
    }
    return;
  }

  const currentPrize = String(concours.cagnotteEstimate || '').trim();
  if (
    serverPrevActivePrize.concoursNumber === concours.number &&
    serverPrevActivePrize.value &&
    currentPrize &&
    currentPrize !== serverPrevActivePrize.value &&
    !/^(—|-|غير محدد|قيد التحديد الرسمي)$/i.test(currentPrize)
  ) {
    void broadcastDesktopPush({
      title: `تحديث قيمة الجائزة الكبرى — القصاصة ${concours.number}`,
      body: `القيمة الجديدة للجائزة الكبرى: ${currentPrize}`,
      concoursNumber: concours.number,
      tag: `jackpot-${concours.number}-${currentPrize.replace(/\s+/g, '-')}`,
      targetTab: 'grille',
    });
  }
  serverPrevActivePrize = { concoursNumber: concours.number, value: currentPrize };

  // 1. New Concours / Grille published
  if (concours.number > serverPrevConcoursNumber) {
    serverPrevConcoursNumber = concours.number;
    const prevNum = concours.number - 1;
    void broadcastDesktopPush({
      title: `قصاصة جديدة رقم ${concours.number} في خانة القصاصة`,
      body: `الجائزة الكبرى ${concours.cagnotteEstimate} • القصاصة السابقة رقم ${prevNum} ظاهرة الآن في خانة Tirage`,
      concoursNumber: concours.number,
      tag: `grille-${concours.number}`,
      targetTab: 'grille',
    });
  }

  // 2. Live Goal / Full-Time / Kickoff events in Active Concours
  const isBaselineEmpty = serverPrevMatchSnap.size === 0;
  for (const m of concours.matches) {
    const hasScore =
      !m.isDelayed &&
      m.scoreHome !== undefined &&
      m.scoreAway !== undefined &&
      /^\d+$/.test(String(m.scoreHome)) &&
      /^\d+$/.test(String(m.scoreAway));
    const curH = hasScore ? Number(m.scoreHome) : 0;
    const curA = hasScore ? Number(m.scoreAway) : 0;
    const prev = serverPrevMatchSnap.get(m.id);

    if (!isBaselineEmpty && prev && !m.isDelayed && hasScore) {
      if (
        (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
        ((prev.hasScore && (curH > prev.home || curA > prev.away)) || (!prev.hasScore && (curH > 0 || curA > 0)))
      ) {
        void broadcastDesktopPush({
          title: `هدف الآن! ${m.homeTeam} ${curH} - ${curA} ${m.awayTeam}`,
          body: `القصاصة ${concours.number} • الدقيقة ${m.liveMinute || "1'"}`,
          concoursNumber: concours.number,
          tag: `goal-${concours.number}-${m.id}-${curH}-${curA}`,
          targetTab: 'live',
        });
      } else if (prev.status !== 'finished' && m.status === 'finished') {
        void broadcastDesktopPush({
          title: `نهاية المقابلة: ${m.homeTeam} ${curH} - ${curA} ${m.awayTeam}`,
          body: `القصاصة ${concours.number} • النتيجة (${m.result || '-'})`,
          concoursNumber: concours.number,
          tag: `ft-${concours.number}-${m.id}`,
          targetTab: 'live',
        });
      }
    }

    serverPrevMatchSnap.set(m.id, {
      status: m.status,
      home: curH,
      away: curA,
      hasScore,
    });
  }

  // 3. Official Winners / Financial Payouts Published
  const latestOfficial = grilles.find(
    (g) => g.number < concours.number && g.status === 'official' && g.winnersFormatted && g.winnersFormatted !== 'قيد التحديد الرسمي'
  );
  if (latestOfficial) {
    const sig = `${latestOfficial.number}:${latestOfficial.winnersCount}:${latestOfficial.prizePerWinner}`;
    if (serverPrevWinnersSig && serverPrevWinnersSig !== sig) {
      void broadcastDesktopPush({
        title: `إعلان المرابيح — قصاصة رقم ${latestOfficial.number}`,
        body: `المرابيح: ${latestOfficial.winnersFormatted} • نصيب الفائز: ${latestOfficial.prizePerWinnerFormatted}`,
        concoursNumber: latestOfficial.number,
        tag: `winners-${latestOfficial.number}`,
        targetTab: 'tirage',
      });
    }
    serverPrevWinnersSig = sig;
  }
}

function evaluateAndDispatchLiveCatalogPushes(payload: SiteLiveScanPayload): void {
  const isBaseline = serverPrevLiveCatalogScores.size === 0;
  for (const m of payload.matches) {
    if (!m.hasVerifiedScore || m.status !== 'live') continue;
    const h = Number(m.scoreHome || 0);
    const a = Number(m.scoreAway || 0);
    const prev = serverPrevLiveCatalogScores.get(m.siteMatchId);
    if (!isBaseline && pushSubscriptions.size > 0 && prev && (h > prev.home || a > prev.away)) {
      void broadcastDesktopPush({
        title: `هدف مباشر! ${m.homeTeam} ${h} - ${a} ${m.awayTeam}`,
        body: `${m.competition || 'مباشر'} • الدقيقة ${m.liveMinute || "1'"}`,
        tag: `live-goal-${m.siteMatchId}-${h}-${a}`,
        targetTab: 'live',
      });
    }
    serverPrevLiveCatalogScores.set(m.siteMatchId, { home: h, away: a });
  }
}

/**
 * Permanently scans https://www.promosport-pronostic.com/welcome/promosport
 * (plus rapid live endpoint & scoreboards) for:
 * - New active grilles (auto-download & immediate promotion without delay)
 * - Immediate rollover archiving of superseded grilles into Tirage (even before winnersCount appears)
 * - Live match scores, minutes, half-times, and official payouts/winnersCount
 */
function probeOfficialPromosportSite(): Promise<void> {
  if (inFlightProbePromise) {
    return inFlightProbePromise;
  }

  inFlightProbePromise = (async () => {
    const nowMs = Date.now();
    syncCache.lastAttemptMs = nowMs;

    try {
      const siteScan = await fetchPromosportPronosticFullScan();

      // 1. Archive & promote if a newer concours appeared on promosport-pronostic.com
      if (siteScan.activeConcours) {
        if (siteScan.activeConcours.number > syncCache.activeConcours.number) {
          const matchingResult = siteScan.grilles.find(
            (g) => g.number === syncCache.activeConcours.number
          );
          const archivedPrev = archiveConcoursToGrille(syncCache.activeConcours, matchingResult);
          syncCache.grilles = mergeGrilleArchives(syncCache.grilles, [archivedPrev]);
          syncCache.activeConcours = siteScan.activeConcours;
        } else if (siteScan.activeConcours.number === syncCache.activeConcours.number) {
          syncCache.activeConcours = mergeConcoursPreservingScores(
            syncCache.activeConcours,
            siteScan.activeConcours
          );
        }
        syncCache.lastRemoteSuccessMs = nowMs;
      }

      // 2. Merge latest official/pending Tirage grilles from site
      if (siteScan.grilles.length > 0) {
        syncCache.grilles = mergeGrilleArchives(syncCache.grilles, siteScan.grilles);
        syncCache.lastRemoteSuccessMs = nowMs;
      }

      // 3. Enrich active concours matches with real-time verified scores (no fake assumptions)
      const { concours: enriched, matchedCount } = await enrichConcoursWithDirectLiveFeeds(
        syncCache.activeConcours
      );
      syncCache.activeConcours = enriched;
      if (matchedCount > 0) {
        syncCache.lastRemoteSuccessMs = nowMs;
      }
    } catch {
      // Keep clean cached state if upstream site is temporarily unreachable
    }

    try {
      // Evaluate with strict zero-assumption evaluator
      const evaluatedConcours = evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null);
      syncCache.activeConcours = evaluatedConcours;

      const archivedExtra: PromosportGrille[] = [];
      if (isConcoursCompletelyFinished(evaluatedConcours, nowMs)) {
        const existing = syncCache.grilles.find((g) => g.number === evaluatedConcours.number);
        archivedExtra.push(archiveConcoursToGrille(evaluatedConcours, existing));
      }

      syncCache.grilles = mergeGrilleArchives(INITIAL_GRILLES, [...syncCache.grilles, ...archivedExtra]);

      // Strictly enforce that N - 1 is present in Tirage archive whenever active concours is N
      const expectedPrevNum = evaluatedConcours.number - 1;
      if (
        expectedPrevNum === INITIAL_WEEKLY_CONCOURS.number &&
        !syncCache.grilles.some((g) => g.number === expectedPrevNum)
      ) {
        syncCache.grilles = mergeGrilleArchives(syncCache.grilles, [
          archiveConcoursToGrille(INITIAL_WEEKLY_CONCOURS),
        ]);
      }

      syncCache.syncedAt = new Date(nowMs).toISOString();
      evaluateAndDispatchConcoursPushes(syncCache.activeConcours, syncCache.grilles);
      void persistSyncArchiveStore();
    } catch (err) {
      console.warn('[probeOfficialPromosportSite] evaluation error:', err);
    }
  })().finally(() => {
    inFlightProbePromise = null;
  });

  return inFlightProbePromise;
}

interface ServerLiveMatchesCache {
  baseMatches: SiteLiveMatch[];
  payload: SiteLiveScanPayload;
  lastCatalogMs: number;
  lastRapidMs: number;
}

const liveMatchesCache: ServerLiveMatchesCache = {
  baseMatches: [],
  payload: {
    matches: [],
    leagues: [],
    liveCount: 0,
    totalCount: 0,
    scannedAt: new Date().toISOString(),
    sourceUrl: PROMOSPORT_PRONOSTIC_HOME_URL,
  },
  lastCatalogMs: 0,
  lastRapidMs: 0,
};

let inFlightLiveCatalogPromise: Promise<void> | null = null;

async function refreshLiveMatchesCache(forceCatalogScan = false): Promise<SiteLiveScanPayload> {
  const nowMs = Date.now();
  const needCatalog =
    forceCatalogScan ||
    liveMatchesCache.baseMatches.length === 0 ||
    nowMs - liveMatchesCache.lastCatalogMs > 20000;

  if (needCatalog) {
    if (!inFlightLiveCatalogPromise) {
      inFlightLiveCatalogPromise = (async () => {
        try {
          const [catalog, rapid] = await Promise.all([
            scanPromosportLiveCatalogHtml(),
            fetchRapidLiveMap(),
          ]);
          if (catalog.length > 0) {
            liveMatchesCache.baseMatches = catalog;
            liveMatchesCache.lastCatalogMs = Date.now();
          }
          if (liveMatchesCache.baseMatches.length > 0) {
            liveMatchesCache.payload = applyRapidToLiveMatches(liveMatchesCache.baseMatches, rapid);
            liveMatchesCache.lastRapidMs = Date.now();
            evaluateAndDispatchLiveCatalogPushes(liveMatchesCache.payload);
          }
        } catch {
          // Keep existing cached payload on transient upstream error
        }
      })().finally(() => {
        inFlightLiveCatalogPromise = null;
      });
    }
    await Promise.race([
      inFlightLiveCatalogPromise,
      new Promise<void>((resolve) => setTimeout(resolve, 6500)),
    ]);
    return liveMatchesCache.payload;
  }

  // Moment-by-moment rapid live update (every ~2.5s)
  if (nowMs - liveMatchesCache.lastRapidMs > 2500 && liveMatchesCache.baseMatches.length > 0) {
    try {
      const rapid = await fetchRapidLiveMap();
      liveMatchesCache.payload = applyRapidToLiveMatches(liveMatchesCache.baseMatches, rapid);
      liveMatchesCache.lastRapidMs = Date.now();
      evaluateAndDispatchLiveCatalogPushes(liveMatchesCache.payload);
    } catch {
      // Preserve last valid snapshot
    }
  }

  return liveMatchesCache.payload;
}

const execAsync = promisify(exec);
let activeDistBuild: Promise<void> | null = null;

interface ExportDistFile {
  path: string;
  base64: string;
  size: number;
}

async function getLatestMtimeMs(targetPath: string): Promise<number> {
  try {
    const stat = await fs.stat(targetPath);
    let newest = stat.mtimeMs;
    if (stat.isDirectory()) {
      const entries = await fs.readdir(targetPath, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name === 'node_modules' || entry.name === 'dist' || entry.name.startsWith('.')) {
          continue;
        }
        const childNewest = await getLatestMtimeMs(path.join(targetPath, entry.name));
        if (childNewest > newest) newest = childNewest;
      }
    }
    return newest;
  } catch {
    return 0;
  }
}

async function ensureBuiltDist(forceFresh = false): Promise<string> {
  const distDir = path.resolve(__dirname, 'dist');
  const distIndex = path.join(distDir, 'index.html');

  let needsBuild = forceFresh || !existsSync(distIndex);
  if (!needsBuild) {
    const distStat = await fs.stat(distIndex).catch(() => null);
    const distMtime = distStat ? distStat.mtimeMs : 0;
    const watchedPaths = ['src', 'public', 'index.html', 'vite.config.ts', 'package.json'];
    const mtimes = await Promise.all(watchedPaths.map((p) => getLatestMtimeMs(path.resolve(__dirname, p))));
    const newestSourceMtime = Math.max(...mtimes);
    if (newestSourceMtime > distMtime) {
      needsBuild = true;
    }
  }

  if (needsBuild) {
    if (!activeDistBuild) {
      activeDistBuild = execAsync('npx vite build', {
        cwd: __dirname,
        maxBuffer: 1024 * 1024 * 10,
      })
        .then(() => undefined)
        .finally(() => {
          activeDistBuild = null;
        });
    }
    await activeDistBuild;
  }

  return distDir;
}

async function collectDistFiles(dir: string, rootDir: string, out: ExportDistFile[]): Promise<void> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(rootDir, fullPath).replace(/\\/g, '/');

    if (relPath === 'assets/aistudio' || relPath.startsWith('assets/aistudio/')) {
      continue;
    }

    if (entry.isDirectory()) {
      await collectDistFiles(fullPath, rootDir, out);
    } else if (entry.isFile()) {
      const buf = await fs.readFile(fullPath);
      out.push({
        path: relPath,
        base64: buf.toString('base64'),
        size: buf.length,
      });
    }
  }
}

const ANDROID_PACKAGE_ID_REGEX = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/;
let lastAutoSyncAt = new Date().toISOString();

function escapeXml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function readJsonSafe<T>(filePath: string, fallback: T): Promise<T> {
  try {
    if (!existsSync(filePath)) return fallback;
    const raw = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

interface SyncWorkspacePayload {
  appSettings?: Record<string, unknown>;
  notificationSettings?: Record<string, unknown>;
  userSlips?: unknown[];
  concours?: WeeklyConcours;
  activeConcours?: WeeklyConcours;
  activeUrl?: string;
  promptSpec?: string;
  offlineHtml?: string;
}

async function copyDirFiltered(srcDir: string, destDir: string, relBase = ''): Promise<number> {
  await fs.mkdir(destDir, { recursive: true });
  const entries = await fs.readdir(srcDir, { withFileTypes: true });
  let count = 0;

  for (const entry of entries) {
    const rel = relBase ? `${relBase}/${entry.name}` : entry.name;
    if (rel === 'assets/aistudio' || rel.startsWith('assets/aistudio/')) continue;

    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);

    if (entry.isDirectory()) {
      count += await copyDirFiltered(srcPath, destPath, rel);
    } else if (entry.isFile()) {
      await fs.copyFile(srcPath, destPath);
      count += 1;
    }
  }
  return count;
}

async function syncDistToCapacitorAssets(distDir: string): Promise<number> {
  const androidPublicDir = path.resolve(__dirname, 'android/app/src/main/assets/public');
  await fs.rm(androidPublicDir, { recursive: true, force: true }).catch(() => {});
  const copied = await copyDirFiltered(distDir, androidPublicDir);

  const bootstrapPath = path.resolve(__dirname, 'APP_BOOTSTRAP.json');
  if (existsSync(bootstrapPath)) {
    await fs.copyFile(bootstrapPath, path.join(androidPublicDir, 'promosport-bootstrap.json')).catch(() => {});
  }
  return copied;
}

async function syncWorkspaceAndCapacitor(payload: SyncWorkspacePayload = {}): Promise<{
  syncedAt: string;
  packageId: string;
  appName: string;
  slipsCount: number;
  concoursNumber: number;
}> {
  const existingAppSettings = await readJsonSafe<Record<string, unknown>>(
    path.resolve(__dirname, 'APP_SETTINGS.json'),
    {
      appName: 'بروموسبور تونس - MB Football',
      packageId: 'com.promosport.tunisie.mb',
      phoneNumber: '51155580',
      concoursNumber: syncCache.activeConcours.number,
      columnRate: 0.15,
      baseFee: 0.25,
      enableSlipsHistory: true,
    }
  );

  const existingNotifSettings = await readJsonSafe<Record<string, unknown>>(
    path.resolve(__dirname, 'NOTIFICATION_SETTINGS.json'),
    {
      notifyNewGrille: true,
      notifyOfficialResults: true,
      notifyJackpotRollover: true,
      notifyClosingCountdown: true,
      soundEnabled: true,
      pushNotificationsEnabled: true,
      notificationSoundEnabled: true,
      notificationSoundStyle: 'golden-chime',
      notificationSoundDurationSeconds: 2,
      goalSoundEnabled: true,
      goalSoundDurationSeconds: 2,
      goalSoundStyle: 'water-droplet',
      clickSoundEnabled: true,
      clickSoundStyle: 'soft-tap',
      durationSeconds: 10,
      checkIntervalMinutes: 15,
      autoUpdateActive: true,
    }
  );

  const existingSlips = await readJsonSafe<unknown[]>(
    path.resolve(__dirname, 'SAVED_USER_SLIPS.json'),
    []
  );

  const existingBootstrap = await readJsonSafe<Record<string, unknown>>(
    path.resolve(__dirname, 'APP_BOOTSTRAP.json'),
    {}
  );

  const mergedAppSettings = {
    ...existingAppSettings,
    ...(payload.appSettings && typeof payload.appSettings === 'object' ? payload.appSettings : {}),
  };

  const mergedNotifSettings = {
    ...existingNotifSettings,
    ...(payload.notificationSettings && typeof payload.notificationSettings === 'object'
      ? payload.notificationSettings
      : {}),
  };

  const nextSlips = Array.isArray(payload.userSlips) ? payload.userSlips : existingSlips;
  const nextConcours =
    payload.activeConcours || payload.concours || (existingBootstrap.activeConcours as WeeklyConcours | undefined) || syncCache.activeConcours;
  const rawPackageId = String(mergedAppSettings.packageId || 'com.promosport.tunisie.mb').trim();
  const validPackageId = ANDROID_PACKAGE_ID_REGEX.test(rawPackageId)
    ? rawPackageId
    : 'com.promosport.tunisie.mb';
  const appName = String(mergedAppSettings.appName || 'بروموسبور تونس - MB Football').trim() || 'بروموسبور تونس - MB Football';
  const syncedAt = new Date().toISOString();
  lastAutoSyncAt = syncedAt;

  const bootstrapPayload = {
    available: true,
    exportId: `sync-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    exportedAt: syncedAt,
    remoteSyncOrigin: payload.activeUrl || (existingBootstrap.remoteSyncOrigin as string | undefined) || '',
    protectedPin: '1777',
    appSettings: { ...mergedAppSettings, packageId: validPackageId, appName },
    notificationSettings: mergedNotifSettings,
    userSlips: nextSlips,
    activeConcours: nextConcours,
    lastNotifiedSignature: existingBootstrap.lastNotifiedSignature ?? null,
    autoCommands: {
      liveScoreTickerMs: 1000,
      upstreamSyncMs: 10000,
      goalFlameDurationMs: 7000,
      goalAudio: mergedNotifSettings.goalSoundStyle || 'water-droplet',
      clickSoundEnabled: mergedNotifSettings.clickSoundEnabled !== false,
      clickSoundStyle: mergedNotifSettings.clickSoundStyle || 'soft-tap',
      autoActivateSlipsAndSettings: true,
      autoOpenBrowserOnServerStart: true,
      autoEnableNotifications: Boolean(mergedNotifSettings.pushNotificationsEnabled),
    },
  };

  const bootstrapJson = JSON.stringify(bootstrapPayload, null, 2);

  await Promise.all([
    fs.writeFile(path.resolve(__dirname, 'APP_SETTINGS.json'), JSON.stringify(bootstrapPayload.appSettings, null, 2), 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'NOTIFICATION_SETTINGS.json'), JSON.stringify(mergedNotifSettings, null, 2), 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'SAVED_USER_SLIPS.json'), JSON.stringify(nextSlips, null, 2), 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'APP_BOOTSTRAP.json'), bootstrapJson, 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'public/promosport-bootstrap.json'), bootstrapJson, 'utf-8'),
  ]);

  if (typeof payload.promptSpec === 'string' && payload.promptSpec.trim().length > 0) {
    await fs.writeFile(path.resolve(__dirname, 'PROMPT_SPECIFICATION.txt'), payload.promptSpec, 'utf-8');
  }

  if (typeof payload.offlineHtml === 'string' && payload.offlineHtml.trim().length > 0) {
    const htmlFilename = `Promosport_MB_3D_Offline_App_${nextConcours.number || 936}.html`;
    await fs.writeFile(path.resolve(__dirname, htmlFilename), payload.offlineHtml, 'utf-8');
  }

  // Sync Capacitor root & Android asset config
  const capConfigPath = path.resolve(__dirname, 'capacitor.config.json');
  const capConfig = await readJsonSafe<Record<string, unknown>>(capConfigPath, {
    appId: validPackageId,
    appName,
    webDir: 'dist',
    bundledWebRuntime: false,
    server: {
      androidScheme: 'https',
      allowNavigation: ['*'],
      cleartext: true,
    },
  });
  capConfig.appId = validPackageId;
  capConfig.appName = appName;
  capConfig.webDir = 'dist';
  capConfig.bundledWebRuntime = false;
  const capConfigStr = `${JSON.stringify(capConfig, null, 2)}\n`;
  await fs.writeFile(capConfigPath, capConfigStr, 'utf-8');

  const androidCapConfigPath = path.resolve(__dirname, 'android/app/src/main/assets/capacitor.config.json');
  if (existsSync(path.dirname(androidCapConfigPath))) {
    await fs.writeFile(androidCapConfigPath, capConfigStr, 'utf-8');
  }

  // Sync Android strings.xml
  const stringsPath = path.resolve(__dirname, 'android/app/src/main/res/values/strings.xml');
  if (existsSync(stringsPath)) {
    const escapedName = escapeXml(appName);
    const escapedPkg = escapeXml(validPackageId);
    const xml = `<?xml version='1.0' encoding='utf-8'?>\n<resources>\n    <string name="app_name">${escapedName}</string>\n    <string name="title_activity_main">${escapedName}</string>\n    <string name="package_name">${escapedPkg}</string>\n    <string name="custom_url_scheme">${escapedPkg}</string>\n</resources>\n`;
    await fs.writeFile(stringsPath, xml, 'utf-8');
  }

  // Sync Android build.gradle namespace & applicationId
  const gradlePath = path.resolve(__dirname, 'android/app/build.gradle');
  if (existsSync(gradlePath)) {
    const rawGradle = await fs.readFile(gradlePath, 'utf-8');
    const updatedGradle = rawGradle
      .replace(/namespace\s+"[^"]+"/, `namespace "${validPackageId}"`)
      .replace(/applicationId\s+"[^"]+"/, `applicationId "${validPackageId}"`);
    if (updatedGradle !== rawGradle) {
      await fs.writeFile(gradlePath, updatedGradle, 'utf-8');
    }
  }

  return {
    syncedAt,
    packageId: validPackageId,
    appName,
    slipsCount: nextSlips.length,
    concoursNumber: Number(nextConcours.number || syncCache.activeConcours.number),
  };
}

async function addDirectoryToZip(
  zip: JSZip,
  absDir: string,
  zipPrefix: string,
  options: { skipDirs?: Set<string>; skipPaths?: string[] } = {}
): Promise<number> {
  if (!existsSync(absDir)) return 0;
  const entries = await fs.readdir(absDir, { withFileTypes: true });
  let count = 0;

  for (const entry of entries) {
    if (options.skipDirs && options.skipDirs.has(entry.name)) {
      continue;
    }

    const fullPath = path.join(absDir, entry.name);
    const zipPath = zipPrefix ? `${zipPrefix}/${entry.name}` : entry.name;

    if (options.skipPaths && options.skipPaths.some((skip) => zipPath === skip || zipPath.startsWith(`${skip}/`))) {
      continue;
    }

    if (entry.isDirectory()) {
      count += await addDirectoryToZip(zip, fullPath, zipPath, options);
    } else if (entry.isFile()) {
      const buf = await fs.readFile(fullPath);
      const isExecutable = zipPath === 'android/gradlew' || zipPath.endsWith('.sh');
      zip.file(zipPath, buf, isExecutable ? { unixPermissions: 0o755 } : undefined);
      count += 1;
    }
  }

  return count;
}

async function countFilesMatching(dir: string, predicate: (rel: string) => boolean, prefix = ''): Promise<number> {
  if (!existsSync(dir)) return 0;
  const entries = await fs.readdir(dir, { withFileTypes: true });
  let count = 0;
  for (const entry of entries) {
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      count += await countFilesMatching(full, predicate, rel);
    } else if (entry.isFile() && predicate(rel)) {
      count += 1;
    }
  }
  return count;
}

async function startServer() {
  await Promise.all([initPushStore(), initSyncArchiveStore()]);

  const app = express();
  const httpServer = createHttpServer(app);
  app.use(express.json({ limit: '15mb' }));

  // Always-on server monitor so subscribed desktop OS clients receive goals & new grilles even when app is closed
  setInterval(() => {
    if (pushSubscriptions.size > 0) {
      void probeOfficialPromosportSite().catch(() => {});
      void refreshLiveMatchesCache(false).catch(() => {});
    }
  }, 25000);

  // Desktop / OS Web Push API (VAPID public key, subscribe, unsubscribe, test)
  app.get('/api/push/vapid-public-key', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      publicKey: pushKeys?.publicKey || null,
      supported: Boolean(pushKeys?.publicKey),
    });
  });

  app.post('/api/push/subscribe', async (req, res) => {
    const sub = req.body?.subscription as webpush.PushSubscription | undefined;
    if (!sub || typeof sub.endpoint !== 'string') {
      res.status(400).json({ ok: false, error: 'Invalid subscription' });
      return;
    }
    pushSubscriptions.set(sub.endpoint, sub);
    await persistPushStore();
    res.json({ ok: true, subscribersCount: pushSubscriptions.size });
  });

  app.post('/api/push/unsubscribe', async (req, res) => {
    const endpoint = req.body?.endpoint as string | undefined;
    if (endpoint) {
      pushSubscriptions.delete(endpoint);
      await persistPushStore();
    }
    res.json({ ok: true });
  });

  app.post('/api/push/test', async (req, res) => {
    const title = String(req.body?.title || `إشعارات بروموسبور نشطة — قصاصة ${syncCache.activeConcours.number}`);
    const body = String(req.body?.body || 'ستصلك إشعارات الأهداف والقصاصات الجديدة على سطح المكتب دائماً.');
    const concoursNumber = Number(req.body?.concoursNumber || syncCache.activeConcours.number);
    const sent = await broadcastDesktopPush({
      title,
      body,
      concoursNumber,
      tag: `test-${Date.now()}`,
    });
    res.json({ ok: true, sent, subscribersCount: pushSubscriptions.size });
  });

  // Live continuous & scheduled Promosport sync endpoint (bounded wait + coalesced upstream probes)
  app.get('/api/promosport/sync', async (req, res) => {
    const force = req.query.refresh === '1';
    const ageMs = Date.now() - syncCache.lastAttemptMs;

    if (force || ageMs > 10000) {
      const probePromise = probeOfficialPromosportSite();
      // Never block client HTTP responses beyond 4s waiting on upstream third-party timeouts
      await Promise.race([
        probePromise,
        new Promise<void>((resolve) => setTimeout(resolve, 4000)),
      ]);
    } else {
      const nowMs = Date.now();
      syncCache.activeConcours = evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null);
      syncCache.syncedAt = new Date(nowMs).toISOString();
    }

    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({
      activeConcours: syncCache.activeConcours,
      grilles: syncCache.grilles,
      syncedAt: syncCache.syncedAt,
      source: syncCache.lastRemoteSuccessMs > 0 ? 'server-live' : 'server-cache',
    });
  });

  // Real-time promosport-pronostic.com full scan + moment-by-moment live scores endpoint
  app.get('/api/promosport/live-matches', async (req, res) => {
    const forceScan = req.query.scan === '1';
    const payload = await refreshLiveMatchesCache(forceScan);
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json(payload);
  });

  // Auto-bootstrap recorded ZIP configuration & slips on new device launch
  app.get('/api/promosport/bootstrap', async (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    const bootstrapPath = path.resolve(__dirname, 'APP_BOOTSTRAP.json');
    if (existsSync(bootstrapPath)) {
      try {
        const raw = await fs.readFile(bootstrapPath, 'utf-8');
        const parsed = JSON.parse(raw);
        res.json({ available: true, ...parsed });
        return;
      } catch {
        // Fallback below
      }
    }
    res.json({ available: false });
  });

  // Auto-sync live edits, slips, settings & Capacitor Android metadata
  app.post('/api/export/sync-state', async (req, res) => {
    try {
      const result = await syncWorkspaceAndCapacitor((req.body || {}) as SyncWorkspacePayload);
      res.setHeader('Cache-Control', 'no-store');
      res.json({ ok: true, ...result });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Sync state error';
      res.status(500).json({ ok: false, error: msg });
    }
  });

  // Real-time Android Capacitor & PWA readiness audit for the UI checklist
  app.get('/api/export/readiness', async (_req, res) => {
    try {
      const resDir = path.resolve(__dirname, 'android/app/src/main/res');
      const manifestPath = path.resolve(__dirname, 'android/app/src/main/AndroidManifest.xml');
      const manifestRaw = existsSync(manifestPath) ? await fs.readFile(manifestPath, 'utf-8') : '';
      const appSettings = await readJsonSafe<Record<string, unknown>>(
        path.resolve(__dirname, 'APP_SETTINGS.json'),
        {}
      );
      const slips = await readJsonSafe<unknown[]>(path.resolve(__dirname, 'SAVED_USER_SLIPS.json'), []);

      const [iconCount, splashCount] = await Promise.all([
        countFilesMatching(resDir, (rel) => /^mipmap-[^/]+\/ic_launcher.*\.png$/i.test(rel)),
        countFilesMatching(resDir, (rel) => /^drawable[^/]*\/splash\.png$/i.test(rel)),
      ]);

      res.setHeader('Cache-Control', 'no-store');
      res.json({
        ready:
          existsSync(path.resolve(__dirname, 'android/gradlew')) &&
          existsSync(path.resolve(__dirname, '.github/workflows/build-android-apk.yml')) &&
          iconCount >= 15 &&
          splashCount >= 6,
        hasGradleWrapper: existsSync(path.resolve(__dirname, 'android/gradlew')),
        hasWorkflow: existsSync(path.resolve(__dirname, '.github/workflows/build-android-apk.yml')),
        hasInternetPermission: manifestRaw.includes('android.permission.INTERNET'),
        hasNotificationPermission: manifestRaw.includes('android.permission.POST_NOTIFICATIONS'),
        hasCapacitorAssetsPublic: existsSync(path.resolve(__dirname, 'android/app/src/main/assets/public/index.html')),
        distBuilt: existsSync(path.resolve(__dirname, 'dist/index.html')),
        iconCount,
        splashCount,
        slipsCount: Array.isArray(slips) ? slips.length : 0,
        packageId: String(appSettings.packageId || 'com.promosport.tunisie.mb'),
        appName: String(appSettings.appName || 'بروموسبور تونس - MB Football'),
        lastAutoSyncAt,
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Readiness check error';
      res.status(500).json({ ready: false, error: msg });
    }
  });

  // Export COMPLETE auto-synced ZIP package (dist/ + src/ + public/ + full android/ Capacitor + offline HTML + bootstrap)
  app.post('/api/export/full-zip', async (req, res) => {
    try {
      const payload = (req.body || {}) as SyncWorkspacePayload;
      const syncResult = await syncWorkspaceAndCapacitor(payload);
      const distDir = await ensureBuiltDist(true);
      const androidAssetsCount = await syncDistToCapacitorAssets(distDir);

      const zip = new JSZip();
      let fileCount = 0;

      // 1. Freshly compiled production dist/ (excludes aistudio media scratch)
      fileCount += await addDirectoryToZip(zip, distDir, 'dist', {
        skipPaths: ['dist/assets/aistudio'],
      });

      // 2. Complete source tree & public PWA assets
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'src'), 'src');
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'public'), 'public', {
        skipPaths: ['public/assets/aistudio'],
      });

      // 3. Complete Android Capacitor workspace (with synced assets/public, covers, icons, manifest, gradle)
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'android'), 'android', {
        skipDirs: new Set(['.gradle', 'build', '.cxx', '.idea', 'local.properties']),
        skipPaths: ['android/app/src/main/assets/public/assets/aistudio'],
      });

      // 4. Cloud APK CI workflow & local helper scripts
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, '.github'), '.github');
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'scripts'), 'scripts');

      // 5. Essential root configs, docs, server, & recorded state
      const htmlFilename = `Promosport_MB_3D_Offline_App_${syncResult.concoursNumber}.html`;
      const rootFiles = [
        'index.html',
        'package.json',
        'package-lock.json',
        'tsconfig.json',
        'vite.config.ts',
        'capacitor.config.json',
        'server.ts',
        'metadata.json',
        'start-ready-app.mjs',
        '.env.example',
        'README.md',
        'README_ANDROID_AND_WEB_BUILD.md',
        'READ_ME_FIRST_AR.txt',
        'APP_BOOTSTRAP.json',
        'APP_SETTINGS.json',
        'NOTIFICATION_SETTINGS.json',
        'SAVED_USER_SLIPS.json',
        'PROMPT_SPECIFICATION.txt',
        htmlFilename,
      ];

      for (const rel of rootFiles) {
        const abs = path.resolve(__dirname, rel);
        if (existsSync(abs)) {
          const buf = await fs.readFile(abs);
          zip.file(rel, buf);
          fileCount += 1;
        }
      }

      const zipBuffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
        platform: 'UNIX',
      });

      const downloadName = `Promosport_MB_3D_Full_Package_${syncResult.concoursNumber}.zip`;
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${downloadName}"`);
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.setHeader('X-Bundle-File-Count', String(fileCount));
      res.setHeader('X-Android-Assets-Count', String(androidAssetsCount));
      res.send(zipBuffer);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Full ZIP export failed';
      res.status(500).json({ error: msg });
    }
  });

  // Export compiled production dist/ app bundle for full-app ZIP download (compat fallback)
  app.get('/api/export/built-bundle', async (req, res) => {
    try {
      const forceFresh = req.query.fresh === '1';
      const distDir = await ensureBuiltDist(forceFresh);
      await syncDistToCapacitorAssets(distDir);
      const files: ExportDistFile[] = [];
      await collectDistFiles(distDir, distDir, files);

      const extraPaths = [
        'start-ready-app.mjs',
        'scripts/check-and-build-apk.mjs',
        '.github/workflows/build-android-apk.yml',
        'README_ANDROID_AND_WEB_BUILD.md',
        'capacitor.config.json',
        'package.json',
      ];
      const extras: ExportDistFile[] = [];
      for (const relPath of extraPaths) {
        const absPath = path.resolve(__dirname, relPath);
        if (existsSync(absPath)) {
          try {
            const buf = await fs.readFile(absPath);
            extras.push({
              path: relPath,
              base64: buf.toString('base64'),
              size: buf.length,
            });
          } catch {
            // ignore optional file read failures
          }
        }
      }

      res.setHeader('Cache-Control', 'no-store');
      res.json({
        builtAt: new Date().toISOString(),
        freshRebuild: forceFresh,
        fileCount: files.length,
        files,
        extras,
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Build bundle error';
      res.status(500).json({ error: msg, files: [] });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      plugins: isHmrDisabled
        ? [
            {
              name: 'disable-hmr-websocket-client',
              enforce: 'post',
              transform(code, id) {
                if (id.replace(/\\/g, '/').endsWith('/vite/dist/client/client.mjs')) {
                  const patched = code.replace(
                    /const transport = normalizeModuleRunnerTransport\(\(\(\) => \{[\s\S]*?\}\)\(\)\);/,
                    'const transport = normalizeModuleRunnerTransport({ async connect() {}, async disconnect() {}, send() {} });'
                  );
                  if (patched !== code) {
                    return { code: patched, map: null };
                  }
                }
                return undefined;
              },
            },
          ]
        : [],
      server: {
        middlewareMode: true,
        allowedHosts: true,
        hmr: isHmrDisabled ? false : { server: httpServer },
        ws: isHmrDisabled ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.on('error', (err) => {
    console.error('HTTP server error:', err);
  });

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Promosport Tunisie server running on http://0.0.0.0:${PORT}`);
    // Warm cache right after port is bound so startup is instantaneous
    void probeOfficialPromosportSite().catch(() => {});
  });
}

startServer().catch((err) => {
  console.error('Failed to start Promosport Tunisie server:', err);
  process.exit(1);
});
