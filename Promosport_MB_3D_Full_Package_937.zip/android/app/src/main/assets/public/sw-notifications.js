/**
 * Companion Service Worker extension for Promosport Tunisie 3D
 * Handles always-on device notifications, background sync checks, and tap-to-open-grille actions.
 */

const ALERT_CACHE_NAME = 'promosport-alert-state-v1';
const ALERT_STATE_URL = '/__promosport_sw_state.json';

function computeConcoursSignature(concours) {
  if (!concours || !concours.number) return '';
  const matchesLen = Array.isArray(concours.matches) ? concours.matches.length : 0;
  return `${concours.number}:${concours.fullDateFormatted || ''}:${matchesLen}`;
}

async function readAlertState() {
  try {
    const cache = await caches.open(ALERT_CACHE_NAME);
    const res = await cache.match(ALERT_STATE_URL);
    if (!res) return { lastSeenSignature: null, concoursNumber: 0 };
    return await res.json();
  } catch {
    return { lastSeenSignature: null, concoursNumber: 0 };
  }
}

async function writeAlertState(state) {
  try {
    const cache = await caches.open(ALERT_CACHE_NAME);
    const response = new Response(JSON.stringify(state), {
      headers: { 'Content-Type': 'application/json' },
    });
    await cache.put(ALERT_STATE_URL, response);
  } catch {
    // ignore cache quota errors
  }
}

async function showDeviceGrilleNotification(title, body, concoursNumber, signature, customTag, targetTab = 'grille') {
  if (!self.registration || !self.registration.showNotification) return;
  try {
    await self.registration.showNotification(title, {
      body,
      icon: '/pwa-192x192.png',
      badge: '/pwa-192x192.png',
      dir: 'rtl',
      lang: 'ar',
      tag: customTag || `promosport-grille-${concoursNumber || 'live'}`,
      renotify: true,
      silent: false,
      vibrate: [220, 100, 220, 100, 320],
      data: {
        url: `/?openTab=${targetTab}`,
        concoursNumber,
        signature,
        targetTab,
      },
    });
  } catch {
    // ignore notification errors when permission is revoked
  }
}

async function checkForNewGrilleInBackground() {
  try {
    const response = await fetch('/api/promosport/sync?refresh=1', { cache: 'no-store' });
    if (!response.ok) return;
    const payload = await response.json();
    const activeConcours = payload && payload.activeConcours;
    const currentState = await readAlertState();
    let updatedState = Object.assign({}, currentState);

    if (activeConcours && activeConcours.number) {
      const nextSig = computeConcoursSignature(activeConcours);
      if (nextSig && Number(activeConcours.number) > Number(currentState.concoursNumber || 0)) {
        updatedState = {
          ...updatedState,
          lastSeenSignature: nextSig,
          concoursNumber: activeConcours.number,
          updatedAt: Date.now(),
        };
        await writeAlertState(updatedState);

        const title = `قصاصة جديدة رقم ${activeConcours.number}`;
        const body = `الجائزة الكبرى: ${activeConcours.cagnotteEstimate || ''} — انقر لفتح القصاصة الآن`;

        await showDeviceGrilleNotification(title, body, activeConcours.number, nextSig);

        const windowClients = await self.clients.matchAll({
          type: 'window',
          includeUncontrolled: true,
        });
        for (const client of windowClients) {
          client.postMessage({
            type: 'NEW_GRILLE_DETECTED',
            concours: activeConcours,
            signature: nextSig,
          });
        }
      }
    }

    const latestOfficial = Array.isArray(payload && payload.grilles)
      ? payload.grilles.find((g) => g && g.status === 'official' && g.winnersFormatted)
      : null;
    if (latestOfficial) {
      const winSig = `${latestOfficial.number}:${latestOfficial.winnersCount}:${latestOfficial.prizePerWinner}`;
      if (currentState.lastWinnersSig !== winSig) {
        updatedState = {
          ...updatedState,
          lastWinnersSig: winSig,
          updatedAt: Date.now(),
        };
        await writeAlertState(updatedState);

        const wTitle = `إعلان عدد المرابيح — قصاصة رقم ${latestOfficial.number}`;
        const wBody = `عدد المرابيح: ${latestOfficial.winnersFormatted} • نصيب العمود: ${latestOfficial.prizePerWinnerFormatted}`;
        await showDeviceGrilleNotification(wTitle, wBody, latestOfficial.number, winSig, '', 'tirage');
      }
    }
  } catch {
    // offline or isolated network - keep state untouched
  }
}

self.addEventListener('message', (event) => {
  const data = event.data;
  if (!data || typeof data !== 'object') return;

  if (data.type === 'SYNC_STATE') {
    event.waitUntil(
      writeAlertState({
        lastSeenSignature: data.lastSeenSignature || null,
        concoursNumber: data.concoursNumber || 0,
        updatedAt: Date.now(),
      })
    );
  } else if (data.type === 'SHOW_NEW_GRILLE_NOTIFICATION') {
    event.waitUntil(
      showDeviceGrilleNotification(
        data.title || 'بروموسبور تونس — قصاصة جديدة',
        data.body || '',
        data.concoursNumber || 0,
        data.signature || '',
        data.tag || '',
        data.targetTab || 'grille'
      )
    );
  }
});

self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'promosport-grille-sync') {
    event.waitUntil(checkForNewGrilleInBackground());
  }
});

self.addEventListener('sync', (event) => {
  if (event.tag === 'promosport-grille-sync') {
    event.waitUntil(checkForNewGrilleInBackground());
  }
});

self.addEventListener('push', (event) => {
  let title = 'قصاصة جديدة — بروموسبور تونس';
  let body = 'تم صدور قصاصة جديدة وتحديث النتائج المباشرة.';
  let concoursNumber = 0;
  let customTag = '';
  let targetTab = 'grille';

  try {
    if (event.data) {
      const parsed = event.data.json();
      title = parsed.title || title;
      body = parsed.body || body;
      concoursNumber = parsed.concoursNumber || 0;
      customTag = parsed.tag || '';
      targetTab = parsed.targetTab || 'grille';
    }
  } catch {
    if (event.data) {
      body = event.data.text() || body;
    }
  }

  event.waitUntil(showDeviceGrilleNotification(title, body, concoursNumber, `push-${Date.now()}`, customTag, targetTab));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const notifData = event.notification.data || {};
  const targetTab = notifData.targetTab || 'grille';
  const targetUrl = notifData.url || `/?openTab=${targetTab}`;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (const client of windowClients) {
        if ('focus' in client) {
          client.focus();
          client.postMessage({
            type: 'OPEN_NOTIFICATION_TARGET',
            concoursNumber: notifData.concoursNumber || 0,
            targetTab,
          });
          return;
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
      return undefined;
    })
  );
});
