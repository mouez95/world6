/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  importScripts("/sw-notifications.js");
  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "sw-notifications.js",
    "revision": "4dd94ed97928c854b5fdde7f3f9736d5"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "39f153e273bae9fe9a62d7effd3c6e14"
  }, {
    "url": "pwa-512x512.png",
    "revision": "af5b2c58aff6c1be42d60eef0503cb40"
  }, {
    "url": "pwa-192x192.png",
    "revision": "873c40cb5aa7ab5f9791bf8137f320bf"
  }, {
    "url": "index.html",
    "revision": "b5e66069488c8fb5b60930288cd3fdd9"
  }, {
    "url": "icon.svg",
    "revision": "de2b9bba33ea770d31729a0d3cdbcc87"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "aa003e46b91d0a9d50aa78c67f73a704"
  }, {
    "url": "assets/workbox-window.prod.es5-zd_v-k4h.js",
    "revision": null
  }, {
    "url": "assets/index-CMgwM5f7.css",
    "revision": null
  }, {
    "url": "assets/index-BHlnC1Rk.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "aa003e46b91d0a9d50aa78c67f73a704"
  }, {
    "url": "icon.svg",
    "revision": "de2b9bba33ea770d31729a0d3cdbcc87"
  }, {
    "url": "pwa-192x192.png",
    "revision": "873c40cb5aa7ab5f9791bf8137f320bf"
  }, {
    "url": "pwa-512x512.png",
    "revision": "af5b2c58aff6c1be42d60eef0503cb40"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "39f153e273bae9fe9a62d7effd3c6e14"
  }, {
    "url": "sw-notifications.js",
    "revision": "4dd94ed97928c854b5fdde7f3f9736d5"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1a9a0f5279895d10036df7f6d153caf3"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
