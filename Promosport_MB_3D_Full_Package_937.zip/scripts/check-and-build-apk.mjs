#!/usr/bin/env node
import { execSync } from 'node:child_process';
import { existsSync } from 'node:fs';

function hasCommand(cmd) {
  try {
    execSync(`command -v ${cmd}`, { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

const hasAndroidSdk = Boolean(process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || hasCommand('sdkmanager'));
const hasGradle = Boolean(hasCommand('gradle') || existsSync('android/gradlew'));

console.log('\n=== Promosport MB 3D — Smart APK & Web Build Check ===');
execSync('npm run build', { stdio: 'inherit' });

if (!hasAndroidSdk || !hasGradle) {
  console.log('\n[INFO] بيئة البناء الحالية لا تحتوي على Android SDK أو Gradle محلياً.');
  console.log('[OK] تم بناء تطبيق الويب و PWA بنجاح في مجلد dist/ جاهزاً للتشغيل عبر: npm start\n');
  console.log('لبناء ملف APK بدون تثبيت Android SDK أو Gradle على جهازك:');
  console.log('  1) سحابياً عبر GitHub Actions (مجاناً): ارفع هذا المجلد إلى GitHub وشغّل .github/workflows/build-android-apk.yml لتحميل app-debug.apk.');
  console.log('  2) سحابياً عبر PWABuilder: https://www.pwabuilder.com/?url=https%3A%2F%2Fais-dev-frlvig3bi52fdi4iktajk5-974683008569.europe-west2.run.app');
  console.log('  3) أوفلاين فوراً على الهاتف: افتح Promosport_MB_3D_Offline_App_936.html داخل Google Chrome.\n');
  process.exit(0);
}

console.log('[OK] Android SDK & Gradle detected! Syncing Capacitor Android & building APK...');
if (existsSync('android')) {
  execSync('npx cap copy android && npx cap update android', { stdio: 'inherit' });
} else {
  execSync('npx cap add android && npx cap sync android', { stdio: 'inherit' });
}
if (existsSync('android/gradlew')) {
  execSync('cd android && chmod +x gradlew && ./gradlew assembleDebug', { stdio: 'inherit' });
} else {
  execSync('cd android && gradle assembleDebug', { stdio: 'inherit' });
}
