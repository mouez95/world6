#!/usr/bin/env node
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const distDir = path.join(__dirname, 'dist');
const publicDir = path.join(__dirname, 'public');
const bootstrapFile = path.join(__dirname, 'APP_BOOTSTRAP.json');
const PORT = Number(process.env.PORT) || 3000;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

if (!fs.existsSync(path.join(distDir, 'index.html'))) {
  console.error('Missing dist/index.html. Run: npm install && npm run build');
  process.exit(1);
}

const syncState = {
  activeConcours: {"number":936,"category":"international","title":"Promosport : Concours N° 936","season":"Saison 2026-2027","fullDateFormatted":"du 17/11/2026 à 20:00","dateStr":"17-11-2026","closingTimeStr":"17/11/2026 à 20:00","cagnotteEstimate":"تُحدد عند السحب","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_pronostic?jeux=Promosport&ng=936","matches":[{"id":1,"siteMatchId":"1528992","dayTime":"19:45","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","homeTeam":"ويلز","homeTeamFr":"Wales","homeLogo":"WAL","awayTeam":"البرتغال","awayTeamFr":"Portugal","awayLogo":"PT","date":"17-11-2026","time":"19:45","kickoffTimestamp":1794944700000,"status":"finished","score":"2 - 3","result":"2","prob1":11,"probX":17,"prob2":72,"isDelayed":false,"scoreHome":"2","scoreAway":"3"},{"id":2,"siteMatchId":"1528998","dayTime":"19:45","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","homeTeam":"بولندا","homeTeamFr":"Poland","homeLogo":"PL","awayTeam":"السويد","awayTeamFr":"Sweden","awayLogo":"SE","date":"17-11-2026","time":"19:45","kickoffTimestamp":1794944700000,"status":"finished","score":"1 - 1","result":"X","prob1":40,"probX":24,"prob2":36,"isDelayed":false,"scoreHome":"1","scoreAway":"1"},{"id":3,"siteMatchId":"1528993","dayTime":"19:45","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","homeTeam":"الدنمارك","homeTeamFr":"Denmark","homeLogo":"DK","awayTeam":"النرويج","awayTeamFr":"Norway","awayLogo":"NO","date":"17-11-2026","time":"19:45","kickoffTimestamp":1794944700000,"status":"finished","score":"2 - 3","result":"2","prob1":38,"probX":23,"prob2":39,"isDelayed":false,"scoreHome":"2","scoreAway":"3"},{"id":4,"siteMatchId":"1528997","dayTime":"19:45","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","homeTeam":"جمهورية أيرلندا","homeTeamFr":"Rep. Of Ireland","homeLogo":"IE","awayTeam":"كوسوفو","awayTeamFr":"Kosovo","awayLogo":"XK","date":"17-11-2026","time":"19:45","kickoffTimestamp":1794944700000,"status":"finished","score":"3 - 0","result":"1","prob1":49,"probX":27,"prob2":24,"isDelayed":false,"scoreHome":"3","scoreAway":"0"},{"id":5,"siteMatchId":"1528995","dayTime":"19:45","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","homeTeam":"المجر","homeTeamFr":"Hungary","homeLogo":"HU","awayTeam":"أيرلندا الشمالية","awayTeamFr":"Northern Ireland","awayLogo":"GB-NIR","date":"17-11-2026","time":"19:45","kickoffTimestamp":1794944700000,"status":"finished","score":"1 - 1","result":"X","prob1":50,"probX":27,"prob2":23,"isDelayed":false,"scoreHome":"1","scoreAway":"1"},{"id":6,"siteMatchId":"1528994","dayTime":"19:45","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","homeTeam":"أوكرانيا","homeTeamFr":"Ukraine","homeLogo":"UA","awayTeam":"جورجيا","awayTeamFr":"Georgia","awayLogo":"GE","date":"17-11-2026","time":"19:45","kickoffTimestamp":1794944700000,"status":"finished","score":"1 - 0","result":"1","prob1":38,"probX":26,"prob2":36,"isDelayed":false,"scoreHome":"1","scoreAway":"0"},{"id":7,"siteMatchId":"1528999","dayTime":"19:45","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","homeTeam":"البوسنة والهرسك","homeTeamFr":"Bosnia & Herzegovina","homeLogo":"BA","awayTeam":"رومانيا","awayTeamFr":"Romania","awayLogo":"RO","date":"17-11-2026","time":"19:45","kickoffTimestamp":1794944700000,"status":"finished","score":"2 - 1","result":"1","prob1":54,"probX":25,"prob2":21,"isDelayed":false,"scoreHome":"2","scoreAway":"1"},{"id":8,"siteMatchId":"1545889","dayTime":"19:00","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","homeTeam":"الكونغو","homeTeamFr":"Congo","homeLogo":"CG","awayTeam":"جزر القمر","awayTeamFr":"Comoros","awayLogo":"KM","date":"17-11-2026","time":"19:00","kickoffTimestamp":1794942000000,"status":"finished","score":"0 - 1","result":"2","prob1":42,"probX":32,"prob2":26,"isDelayed":false,"scoreHome":"0","scoreAway":"1"},{"id":9,"siteMatchId":"1545899","dayTime":"19:00","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","homeTeam":"موريتانيا","homeTeamFr":"Mauritania","homeLogo":"MR","awayTeam":"بوركينا فاسو","awayTeamFr":"Burkina Faso","awayLogo":"BF","date":"17-11-2026","time":"19:00","kickoffTimestamp":1794942000000,"status":"finished","score":"1 - 3","result":"2","prob1":31,"probX":33,"prob2":36,"isDelayed":false,"scoreHome":"1","scoreAway":"3"},{"id":10,"siteMatchId":"1545902","dayTime":"19:00","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","homeTeam":"رواندا","homeTeamFr":"Rwanda","homeLogo":"RW","awayTeam":"مالي","awayTeamFr":"Mali","awayLogo":"ML","date":"17-11-2026","time":"19:00","kickoffTimestamp":1794942000000,"status":"finished","score":"0 - 2","result":"2","prob1":21,"probX":30,"prob2":49,"isDelayed":false,"scoreHome":"0","scoreAway":"2"},{"id":11,"siteMatchId":"1545886","dayTime":"19:00","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","homeTeam":"بوتسوانا","homeTeamFr":"Botswana","homeLogo":"BW","awayTeam":"أوغندا","awayTeamFr":"Uganda","awayLogo":"UG","date":"17-11-2026","time":"19:00","kickoffTimestamp":1794942000000,"status":"finished","score":"1 - 1","result":"X","prob1":44,"probX":32,"prob2":24,"isDelayed":false,"scoreHome":"1","scoreAway":"1"},{"id":12,"siteMatchId":"1545896","dayTime":"19:00","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","homeTeam":"ليبيريا","homeTeamFr":"Liberia","homeLogo":"LR","awayTeam":"الرأس الأخضر","awayTeamFr":"Cape Verde Islands","awayLogo":"CV","date":"17-11-2026","time":"19:00","kickoffTimestamp":1794942000000,"status":"finished","score":"2 - 0","result":"1","prob1":20,"probX":29,"prob2":51,"isDelayed":false,"scoreHome":"2","scoreAway":"0"},{"id":13,"siteMatchId":"1545901","dayTime":"20:00","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","homeTeam":"النيجر","homeTeamFr":"Niger","homeLogo":"NE","awayTeam":"المغرب","awayTeamFr":"Morocco","awayLogo":"MA","date":"17-11-2026","time":"20:00","kickoffTimestamp":1794945600000,"status":"finished","score":"0 - 1","result":"2","prob1":3,"probX":10,"prob2":87,"isDelayed":false,"scoreHome":"0","scoreAway":"1"}]},
  grilles: [{"id":"grille-936","number":936,"date":"17/11/2026 à 20:00","cagnotte":0,"cagnotteFormatted":"قيد التحديد الرسمي","winnersCount":0,"winnersFormatted":"قيد التحديد الرسمي","prizePerWinner":0,"prizePerWinnerFormatted":"قيد التحديد الرسمي","isRollover":false,"status":"pending","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_result?grille=936&jeux=Promosport","matches":[{"id":1,"homeTeam":"ويلز","homeTeamFr":"Wales","homeLogo":"WAL","awayTeam":"البرتغال","awayTeamFr":"Portugal","awayLogo":"PT","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 3","result":"2"},{"id":2,"homeTeam":"بولندا","homeTeamFr":"Poland","homeLogo":"PL","awayTeam":"السويد","awayTeamFr":"Sweden","awayLogo":"SE","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 1","result":"X"},{"id":3,"homeTeam":"الدنمارك","homeTeamFr":"Denmark","homeLogo":"DK","awayTeam":"النرويج","awayTeamFr":"Norway","awayLogo":"NO","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 3","result":"2"},{"id":4,"homeTeam":"جمهورية أيرلندا","homeTeamFr":"Rep. Of Ireland","homeLogo":"IE","awayTeam":"كوسوفو","awayTeamFr":"Kosovo","awayLogo":"XK","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"3 - 0","result":"1"},{"id":5,"homeTeam":"المجر","homeTeamFr":"Hungary","homeLogo":"HU","awayTeam":"أيرلندا الشمالية","awayTeamFr":"Northern Ireland","awayLogo":"GB-NIR","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 1","result":"X"},{"id":6,"homeTeam":"أوكرانيا","homeTeamFr":"Ukraine","homeLogo":"UA","awayTeam":"جورجيا","awayTeamFr":"Georgia","awayLogo":"GE","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 0","result":"1"},{"id":7,"homeTeam":"البوسنة والهرسك","homeTeamFr":"Bosnia & Herzegovina","homeLogo":"BA","awayTeam":"رومانيا","awayTeamFr":"Romania","awayLogo":"RO","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 1","result":"1"},{"id":8,"homeTeam":"الكونغو","homeTeamFr":"Congo","homeLogo":"CG","awayTeam":"جزر القمر","awayTeamFr":"Comoros","awayLogo":"KM","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"0 - 1","result":"2"},{"id":9,"homeTeam":"موريتانيا","homeTeamFr":"Mauritania","homeLogo":"MR","awayTeam":"بوركينا فاسو","awayTeamFr":"Burkina Faso","awayLogo":"BF","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"1 - 3","result":"2"},{"id":10,"homeTeam":"رواندا","homeTeamFr":"Rwanda","homeLogo":"RW","awayTeam":"مالي","awayTeamFr":"Mali","awayLogo":"ML","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"0 - 2","result":"2"},{"id":11,"homeTeam":"بوتسوانا","homeTeamFr":"Botswana","homeLogo":"BW","awayTeam":"أوغندا","awayTeamFr":"Uganda","awayLogo":"UG","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"1 - 1","result":"X"},{"id":12,"homeTeam":"ليبيريا","homeTeamFr":"Liberia","homeLogo":"LR","awayTeam":"الرأس الأخضر","awayTeamFr":"Cape Verde Islands","awayLogo":"CV","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"2 - 0","result":"1"},{"id":13,"homeTeam":"النيجر","homeTeamFr":"Niger","homeLogo":"NE","awayTeam":"المغرب","awayTeamFr":"Morocco","awayLogo":"MA","competition":"تصفيات كأس أمم إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"0 - 1","result":"2"}]},{"id":"grille-935","number":935,"date":"15-11-2026 à 14:00","cagnotte":68399,"cagnotteFormatted":"68 399 DT","winnersCount":2,"winnersFormatted":"2 مرابيح","prizePerWinner":34199.5,"prizePerWinnerFormatted":"34 199,500 DT","isRollover":false,"status":"official","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_result?grille=935&jeux=Promosport","matches":[{"id":1,"homeTeam":"إسبانيا","homeTeamFr":"Spain","homeLogo":"ES","awayTeam":"إنجلترا","awayTeamFr":"England","awayLogo":"GB-ENG","competition":"دوري الأمم الأوروبية (الشوط 1)","competitionFr":"UEFA Nations League (1ère MT)","score":"0 - 1","result":"2"},{"id":2,"homeTeam":"إسبانيا","homeTeamFr":"Spain","homeLogo":"ES","awayTeam":"إنجلترا","awayTeamFr":"England","awayLogo":"GB-ENG","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 3","result":"2"},{"id":3,"homeTeam":"بلجيكا","homeTeamFr":"Belgium","homeLogo":"BE","awayTeam":"إيطاليا","awayTeamFr":"Italy","awayLogo":"IT","competition":"دوري الأمم الأوروبية (الشوط 1)","competitionFr":"UEFA Nations League (1ère MT)","score":"3 - 1","result":"1"},{"id":4,"homeTeam":"بلجيكا","homeTeamFr":"Belgium","homeLogo":"BE","awayTeam":"إيطاليا","awayTeamFr":"Italy","awayLogo":"IT","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"4 - 1","result":"1"},{"id":5,"homeTeam":"فرنسا","homeTeamFr":"France","homeLogo":"FR","awayTeam":"تركيا","awayTeamFr":"Türkiye","awayLogo":"TR","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 1","result":"1"},{"id":6,"homeTeam":"كرواتيا","homeTeamFr":"Croatia","homeLogo":"HR","awayTeam":"التشيك","awayTeamFr":"Czechia","awayLogo":"CZ","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 1","result":"1"},{"id":7,"homeTeam":"بيلاروسيا","homeTeamFr":"Belarus","homeLogo":"BY","awayTeam":"ألبانيا","awayTeamFr":"Albania","awayLogo":"AL","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"0 - 2","result":"2"},{"id":8,"homeTeam":"قبرص","homeTeamFr":"Cyprus","homeLogo":"CY","awayTeam":"الجبل الأسود","awayTeamFr":"Montenegro","awayLogo":"ME","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 4","result":"2"},{"id":9,"homeTeam":"لاتفيا","homeTeamFr":"Latvia","homeLogo":"LV","awayTeam":"أرمينيا","awayTeamFr":"Armenia","awayLogo":"AM","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"0 - 0","result":"X"},{"id":10,"homeTeam":"غرناطة","homeTeamFr":"Granada CF","homeLogo":"GRA","awayTeam":"لاس بالماس","awayTeamFr":"Las Palmas","awayLogo":"LPA","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"1 - 0","result":"1"},{"id":11,"homeTeam":"إيبار","homeTeamFr":"Eibar","homeLogo":"EIB","awayTeam":"قادش","awayTeamFr":"Cadiz","awayLogo":"CAD","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"1 - 1","result":"X"},{"id":12,"homeTeam":"إلدينسي","homeTeamFr":"Eldense","homeLogo":"ELD","awayTeam":"ساباديل","awayTeamFr":"Sabadell","awayLogo":"SAB","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"2 - 0","result":"1"},{"id":13,"homeTeam":"تينيريفي","homeTeamFr":"Tenerife","homeLogo":"TEN","awayTeam":"سبتة","awayTeamFr":"AD Ceuta FC","awayLogo":"CEU","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"2 - 0","result":"1"}]},{"id":"grille-934","number":934,"date":"14-11-2026 à 16:15","cagnotte":53306,"cagnotteFormatted":"53 306 DT","winnersCount":1,"winnersFormatted":"1 مرابيح","prizePerWinner":53306,"prizePerWinnerFormatted":"53 306 DT","isRollover":false,"status":"official","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_result?grille=934&jeux=Promosport","matches":[{"id":1,"homeTeam":"البرتغال","homeTeamFr":"Portugal","homeLogo":"PT","awayTeam":"الدنمارك","awayTeamFr":"Denmark","awayLogo":"DK","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 4","result":"2"},{"id":2,"homeTeam":"النرويج","homeTeamFr":"Norway","homeLogo":"NO","awayTeam":"ويلز","awayTeamFr":"Wales","awayLogo":"WAL","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"3 - 1","result":"1"},{"id":3,"homeTeam":"أيرلندا الشمالية","homeTeamFr":"Northern Ireland","homeLogo":"GB-NIR","awayTeam":"أوكرانيا","awayTeamFr":"Ukraine","awayLogo":"UA","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 0","result":"1"},{"id":4,"homeTeam":"النمسا","homeTeamFr":"Austria","homeLogo":"AT","awayTeam":"جمهورية أيرلندا","awayTeamFr":"Rep. Of Ireland","awayLogo":"IE","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 0","result":"1"},{"id":5,"homeTeam":"رومانيا","homeTeamFr":"Romania","homeLogo":"RO","awayTeam":"بولندا","awayTeamFr":"Poland","awayLogo":"PL","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 1","result":"1"},{"id":6,"homeTeam":"السويد","homeTeamFr":"Sweden","homeLogo":"SE","awayTeam":"البوسنة والهرسك","awayTeamFr":"Bosnia & Herzegovina","awayLogo":"BA","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"3 - 2","result":"1"},{"id":7,"homeTeam":"جورجيا","homeTeamFr":"Georgia","homeLogo":"GE","awayTeam":"المجر","awayTeamFr":"Hungary","awayLogo":"HU","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"0 - 2","result":"2"},{"id":8,"homeTeam":"أوغندا","homeTeamFr":"Uganda","homeLogo":"UG","awayTeam":"بوتسوانا","awayTeamFr":"Botswana","awayLogo":"BW","competition":"تصفيات كأس إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"1 - 1","result":"X"},{"id":9,"homeTeam":"الجزائر","homeTeamFr":"Algeria","homeLogo":"DZ","awayTeam":"توغو","awayTeamFr":"Togo","awayLogo":"TG","competition":"تصفيات كأس إفريقيا","competitionFr":"Africa Cup of Nations - Qualification","score":"1 - 0","result":"1"},{"id":10,"homeTeam":"ريال أوفييدو","homeTeamFr":"Oviedo","homeLogo":"OVI","awayTeam":"جيرونا","awayTeamFr":"Girona","awayLogo":"GIR","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"1 - 2","result":"2"},{"id":11,"homeTeam":"مايوركا","homeTeamFr":"Mallorca","homeLogo":"MAL","awayTeam":"قرطبة","awayTeamFr":"Cordoba","awayLogo":"COR","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"3 - 3","result":"X"},{"id":12,"homeTeam":"ريال سوسيداد ب","homeTeamFr":"Real Sociedad II","homeLogo":"RSOB","awayTeam":"سبورتينغ خيخون","awayTeamFr":"Sporting Gijon","awayLogo":"GIJ","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"2 - 2","result":"X"},{"id":13,"homeTeam":"ألميريا","homeTeamFr":"Almeria","homeLogo":"ALM","awayTeam":"أندورا","awayTeamFr":"FC Andorra","awayLogo":"AND","competition":"الدوري الإسباني الدرجة 2","competitionFr":"LaLiga Hypermotion","score":"2 - 1","result":"1"}]},{"id":"grille-933","number":933,"date":"12-11-2026 à 17:00","cagnotte":61959,"cagnotteFormatted":"61 959 DT","winnersCount":616,"winnersFormatted":"616 مرابيح","prizePerWinner":100.583,"prizePerWinnerFormatted":"100,583 DT","isRollover":false,"status":"official","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_result?grille=933&jeux=Promosport","matches":[{"id":1,"homeTeam":"إيطاليا","homeTeamFr":"Italie","homeLogo":"IT","awayTeam":"فرنسا","awayTeamFr":"France","awayLogo":"FR","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"3 - 1","result":"1"},{"id":2,"homeTeam":"تركيا","homeTeamFr":"Turquie","homeLogo":"TR","awayTeam":"بلجيكا","awayTeamFr":"Belgique","awayLogo":"BE","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"1 - 2","result":"2"},{"id":3,"homeTeam":"التشيك","homeTeamFr":"Tcheque","homeLogo":"CZ","awayTeam":"إسبانيا","awayTeamFr":"Espagne","awayLogo":"ES","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"0 - 2","result":"2"},{"id":4,"homeTeam":"إنجلترا","homeTeamFr":"Angleterre","homeLogo":"GB-ENG","awayTeam":"كرواتيا","awayTeamFr":"Croatie","awayLogo":"HR","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 1","result":"1"},{"id":5,"homeTeam":"ألبانيا","homeTeamFr":"Albanie","homeLogo":"AL","awayTeam":"فنلندا","awayTeamFr":"Finlande","awayLogo":"FI","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 0","result":"1"},{"id":6,"homeTeam":"الجبل الأسود","homeTeamFr":"Montenegro","homeLogo":"ME","awayTeam":"لاتفيا","awayTeamFr":"Lettonie","awayLogo":"LV","competition":"دوري الأمم الأوروبية","competitionFr":"UEFA Nations League","score":"2 - 1","result":"1"},{"id":7,"homeTeam":"أرمينيا","homeTeamFr":"Armenie","homeLogo":"AM","awayTeam":"قبرص","awayTeamFr":"Chypre","awayLogo":"CY","competition":"تصفيات أمم أوروبا","competitionFr":"Éliminatoires Euro","score":"1 - 1","result":"X"},{"id":8,"homeTeam":"غينيا الاستوائية","homeTeamFr":"Guinee Equatoriale","homeLogo":"GQ","awayTeam":"زيمبابوي","awayTeamFr":"Zimbabwe","awayLogo":"ZW","competition":"تصفيات كأس إفريقيا","competitionFr":"Éliminatoires CAN","score":"0 - 0","result":"X"},{"id":9,"homeTeam":"مدغشقر","homeTeamFr":"Madagascar","homeLogo":"MG","awayTeam":"غينيا بيساو","awayTeamFr":"Guinee Bissau","awayLogo":"GW","competition":"تصفيات كأس إفريقيا","competitionFr":"Éliminatoires CAN","score":"1 - 1","result":"X"},{"id":10,"homeTeam":"كوت ديفوار","homeTeamFr":"Cote D ivoire","homeLogo":"CI","awayTeam":"غامبيا","awayTeamFr":"Gambie","awayLogo":"GM","competition":"تصفيات كأس إفريقيا","competitionFr":"Éliminatoires CAN","score":"2 - 1","result":"1"},{"id":11,"homeTeam":"الكونغو الديمقراطية","homeTeamFr":"RD Congo","homeLogo":"CD","awayTeam":"سيراليون","awayTeamFr":"Sierra Leone","awayLogo":"SL","competition":"تصفيات كأس إفريقيا","competitionFr":"Éliminatoires CAN","score":"3 - 1","result":"1"},{"id":12,"homeTeam":"بنين","homeTeamFr":"Benin","homeLogo":"BJ","awayTeam":"إفريقيا الوسطى","awayTeamFr":"Afrique Centrale","awayLogo":"CF","competition":"تصفيات كأس إفريقيا","competitionFr":"Éliminatoires CAN","score":"4 - 1","result":"1"},{"id":13,"homeTeam":"السنغال","homeTeamFr":"Senegal","homeLogo":"SN","awayTeam":"السودان","awayTeamFr":"Soudan","awayLogo":"SD","competition":"تصفيات كأس إفريقيا","competitionFr":"Éliminatoires CAN","score":"4 - 1","result":"1"}]},{"id":"grille-932","number":932,"date":"08-11-2026 à 15:00","cagnotte":194030,"cagnotteFormatted":"194 030 DT","winnersCount":45,"winnersFormatted":"45 مرابيح","prizePerWinner":4311.778,"prizePerWinnerFormatted":"4 311,778 DT","isRollover":false,"status":"official","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_result?grille=932&jeux=Promosport","matches":[{"id":1,"homeTeam":"ليفربول","homeTeamFr":"Liverpool","homeLogo":"LIV","awayTeam":"أستون فيلا","awayTeamFr":"Aston Villa","awayLogo":"AVL","competition":"الدوري الإنجليزي","competitionFr":"Premier League","score":"2 - 0","result":"1"},{"id":2,"homeTeam":"مانشستر سيتي","homeTeamFr":"Manchester City","homeLogo":"MCI","awayTeam":"برايتون","awayTeamFr":"Brighton","awayLogo":"BHA","competition":"الدوري الإنجليزي","competitionFr":"Premier League","score":"1 - 2","result":"2"},{"id":3,"homeTeam":"ريال مدريد","homeTeamFr":"Real Madrid","homeLogo":"RMA","awayTeam":"أوساسونا","awayTeamFr":"Osasuna","awayLogo":"OSA","competition":"الدوري الإسباني","competitionFr":"La Liga","score":"4 - 0","result":"1"},{"id":4,"homeTeam":"فياريال","homeTeamFr":"Villarreal","homeLogo":"VIL","awayTeam":"ديبورتيفو ألافيس","awayTeamFr":"Alavés","awayLogo":"ALA","competition":"الدوري الإسباني","competitionFr":"La Liga","score":"3 - 0","result":"1"},{"id":5,"homeTeam":"يوفنتوس","homeTeamFr":"Juventus","homeLogo":"JUV","awayTeam":"تورينو","awayTeamFr":"Torino","awayLogo":"TOR","competition":"الدوري الإيطالي","competitionFr":"Serie A","score":"2 - 0","result":"1"},{"id":6,"homeTeam":"ميلان","homeTeamFr":"AC Milan","homeLogo":"MIL","awayTeam":"كالياري","awayTeamFr":"Cagliari","awayLogo":"CAG","competition":"الدوري الإيطالي","competitionFr":"Serie A","score":"3 - 3","result":"X"},{"id":7,"homeTeam":"بايرن ميونخ","homeTeamFr":"Bayern Munich","homeLogo":"BAY","awayTeam":"سانت باولي","awayTeamFr":"St. Pauli","awayLogo":"STP","competition":"الدوري الألماني","competitionFr":"Bundesliga","score":"1 - 0","result":"1"},{"id":8,"homeTeam":"بوروسيا دورتموند","homeTeamFr":"B. Dortmund","homeLogo":"BVB","awayTeam":"ماينتس","awayTeamFr":"Mainz 05","awayLogo":"M05","competition":"الدوري الألماني","competitionFr":"Bundesliga","score":"1 - 3","result":"2"},{"id":9,"homeTeam":"باريس سان جيرمان","homeTeamFr":"Paris SG","homeLogo":"PSG","awayTeam":"أنجيه","awayTeamFr":"Angers","awayLogo":"ANG","competition":"الدوري الفرنسي","competitionFr":"Ligue 1","score":"4 - 2","result":"1"},{"id":10,"homeTeam":"موناكو","homeTeamFr":"AS Monaco","homeLogo":"MON","awayTeam":"ستراسبورغ","awayTeamFr":"Strasbourg","awayLogo":"STR","competition":"الدوري الفرنسي","competitionFr":"Ligue 1","score":"3 - 1","result":"1"},{"id":11,"homeTeam":"إنتر ميلان","homeTeamFr":"Inter Milan","homeLogo":"INT","awayTeam":"نابولي","awayTeamFr":"Napoli","awayLogo":"NAP","competition":"الدوري الإيطالي","competitionFr":"Serie A","score":"2 - 1","result":"1"},{"id":12,"homeTeam":"تشيلسي","homeTeamFr":"Chelsea","homeLogo":"CHE","awayTeam":"أرسنال","awayTeamFr":"Arsenal","awayLogo":"ARS","competition":"الدوري الإنجليزي","competitionFr":"Premier League","score":"1 - 1","result":"X"},{"id":13,"homeTeam":"برشلونة","homeTeamFr":"FC Barcelona","homeLogo":"BAR","awayTeam":"ريال سوسيداد","awayTeamFr":"Real Sociedad","awayLogo":"RSO","competition":"الدوري الإسباني","competitionFr":"La Liga","score":"3 - 0","result":"1"}]},{"id":"grille-931","number":931,"date":"07-11-2026 à 15:00","cagnotte":72152,"cagnotteFormatted":"72 152 DT","winnersCount":0,"winnersFormatted":"0 مرابيح (ترحيل)","prizePerWinner":0,"prizePerWinnerFormatted":"ترحيل الجائزة (0 DT)","isRollover":true,"status":"official","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_result?grille=931&jeux=Promosport","matches":[{"id":1,"homeTeam":"إنتر ميلان","homeTeamFr":"Inter Milan","homeLogo":"INT","awayTeam":"أرسنال","awayTeamFr":"Arsenal","awayLogo":"ARS","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 0","result":"1"},{"id":2,"homeTeam":"باريس سان جيرمان","homeTeamFr":"Paris SG","homeLogo":"PSG","awayTeam":"أتلتيكو مدريد","awayTeamFr":"Atlético Madrid","awayLogo":"ATM","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 2","result":"2"},{"id":3,"homeTeam":"بايرن ميونخ","homeTeamFr":"Bayern Munich","homeLogo":"BAY","awayTeam":"بنفيكا","awayTeamFr":"Benfica","awayLogo":"BEN","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 0","result":"1"},{"id":4,"homeTeam":"النجم الأحمر بلغراد","homeTeamFr":"Crvena Zvezda","homeLogo":"RSB","awayTeam":"برشلونة","awayTeamFr":"FC Barcelona","awayLogo":"BAR","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"2 - 5","result":"2"},{"id":5,"homeTeam":"شتوتغارت","homeTeamFr":"VfB Stuttgart","homeLogo":"STU","awayTeam":"أتالانتا","awayTeamFr":"Atalanta","awayLogo":"ATA","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"0 - 2","result":"2"},{"id":6,"homeTeam":"فينورد","homeTeamFr":"Feyenoord","homeLogo":"FEY","awayTeam":"سالزبورغ","awayTeamFr":"RB Salzburg","awayLogo":"SAL","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 3","result":"2"},{"id":7,"homeTeam":"سبارتا براغ","homeTeamFr":"Sparta Prague","homeLogo":"SPA","awayTeam":"ستاد بريست","awayTeamFr":"Stade Brestois","awayLogo":"BRE","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 2","result":"2"},{"id":8,"homeTeam":"لاتسيو","homeTeamFr":"SS Lazio","homeLogo":"LAZ","awayTeam":"بورتو","awayTeamFr":"FC Porto","awayLogo":"POR_C","competition":"الدوري الأوروبي","competitionFr":"Europa League","score":"2 - 1","result":"1"},{"id":9,"homeTeam":"مانشستر يونايتد","homeTeamFr":"Man United","homeLogo":"MUN","awayTeam":"باوك سالونيكا","awayTeamFr":"PAOK","awayLogo":"PAO","competition":"الدوري الأوروبي","competitionFr":"Europa League","score":"2 - 0","result":"1"},{"id":10,"homeTeam":"غلطة سراي","homeTeamFr":"Galatasaray","homeLogo":"GAL","awayTeam":"توتنهام","awayTeamFr":"Tottenham","awayLogo":"TOT","competition":"الدوري الأوروبي","competitionFr":"Europa League","score":"3 - 2","result":"1"},{"id":11,"homeTeam":"أولمبياكوس","homeTeamFr":"Olympiacos","homeLogo":"OLY","awayTeam":"رينجرز","awayTeamFr":"Rangers","awayLogo":"RAN","competition":"الدوري الأوروبي","competitionFr":"Europa League","score":"1 - 1","result":"X"},{"id":12,"homeTeam":"أياكس","homeTeamFr":"AFC Ajax","homeLogo":"AJA","awayTeam":"فيكتوريا بلزن","awayTeamFr":"Viktoria Plzeň","awayLogo":"PLZ","competition":"الدوري الأوروبي","competitionFr":"Europa League","score":"5 - 0","result":"1"},{"id":13,"homeTeam":"تشيلسي","homeTeamFr":"Chelsea","homeLogo":"CHE","awayTeam":"نوح الأرميني","awayTeamFr":"FC Noah","awayLogo":"NOA","competition":"دوري المؤتمر الأوروبي","competitionFr":"Conference League","score":"8 - 0","result":"1"}]},{"id":"grille-930","number":930,"date":"05-11-2026 à 18:45","cagnotte":48179,"cagnotteFormatted":"48 179 DT","winnersCount":8,"winnersFormatted":"8 مرابيح","prizePerWinner":6022.375,"prizePerWinnerFormatted":"6 022,375 DT","isRollover":false,"status":"official","sourceUrl":"https://www.promosport-pronostic.com/welcome/promo_result?grille=930&jeux=Promosport","matches":[{"id":1,"homeTeam":"ريال مدريد","homeTeamFr":"Real Madrid","homeLogo":"RMA","awayTeam":"ميلان","awayTeamFr":"AC Milan","awayLogo":"MIL","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 3","result":"2"},{"id":2,"homeTeam":"ليفربول","homeTeamFr":"Liverpool","homeLogo":"LIV","awayTeam":"باير ليفركوزن","awayTeamFr":"Bayer Leverkusen","awayLogo":"LEV","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"4 - 0","result":"1"},{"id":3,"homeTeam":"سبورتينغ لشبونة","homeTeamFr":"Sporting CP","homeLogo":"SCP","awayTeam":"مانشستر سيتي","awayTeamFr":"Manchester City","awayLogo":"MCI","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"4 - 1","result":"1"},{"id":4,"homeTeam":"ليل","homeTeamFr":"Lille OSC","homeLogo":"LIL","awayTeam":"يوفنتوس","awayTeamFr":"Juventus","awayLogo":"JUV","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 1","result":"X"},{"id":5,"homeTeam":"سلتيك","homeTeamFr":"Celtic FC","homeLogo":"CEL","awayTeam":"لايبزيغ","awayTeamFr":"RB Leipzig","awayLogo":"RBL","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"3 - 1","result":"1"},{"id":6,"homeTeam":"بوروسيا دورتموند","homeTeamFr":"B. Dortmund","homeLogo":"BVB","awayTeam":"شتورم غراتس","awayTeamFr":"Sturm Graz","awayLogo":"STG","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 0","result":"1"},{"id":7,"homeTeam":"بولونيا","homeTeamFr":"Bologna","homeLogo":"BOL","awayTeam":"موناكو","awayTeamFr":"AS Monaco","awayLogo":"MON","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"0 - 1","result":"2"},{"id":8,"homeTeam":"بي إس في آيندهوفن","homeTeamFr":"PSV Eindhoven","homeLogo":"PSV","awayTeam":"جيرونا","awayTeamFr":"Girona FC","awayLogo":"GIR","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"4 - 0","result":"1"},{"id":9,"homeTeam":"سلوفان براتيسلافا","homeTeamFr":"Slovan Bratislava","homeLogo":"SLO","awayTeam":"دينامو زغرب","awayTeamFr":"Dinamo Zagreb","awayLogo":"DZG","competition":"دوري أبطال أوروبا","competitionFr":"Champions League","score":"1 - 4","result":"2"},{"id":10,"homeTeam":"أتلتيكو مدريد","homeTeamFr":"Atlético Madrid","homeLogo":"ATM","awayTeam":"إشبيلية","awayTeamFr":"Sevilla FC","awayLogo":"SEV","competition":"الدوري الإسباني","competitionFr":"La Liga","score":"2 - 1","result":"1"},{"id":11,"homeTeam":"أرسنال","homeTeamFr":"Arsenal","homeLogo":"ARS","awayTeam":"نيوكاسل يونايتد","awayTeamFr":"Newcastle Utd","awayLogo":"NEW","competition":"الدوري الإنجليزي","competitionFr":"Premier League","score":"2 - 0","result":"1"},{"id":12,"homeTeam":"روما","homeTeamFr":"AS Roma","homeLogo":"ROM","awayTeam":"فيورنتينا","awayTeamFr":"Fiorentina","awayLogo":"FIO","competition":"الدوري الإيطالي","competitionFr":"Serie A","score":"2 - 2","result":"X"},{"id":13,"homeTeam":"ليون","homeTeamFr":"Olympique Lyon","homeLogo":"LYO","awayTeam":"مارسيليا","awayTeamFr":"Marseille","awayLogo":"OM","competition":"الدوري الفرنسي","competitionFr":"Ligue 1","score":"3 - 2","result":"1"}]}],
  lastProbeAt: null,
  status: 'cached',
};

const ESPN_LEAGUES = ['all', 'esp.2', 'uefa.nations', 'caf.nations', 'fifa.worldq', 'fifa.friendly', 'esp.1', 'eng.1', 'ita.1', 'fra.1', 'ger.1'];

const ALIAS_GROUPS = [
  ['danemark', 'denmark'], ['norvege', 'norway'], ['paysdegalles', 'wales'],
  ['irlandedunord', 'northernireland', 'nireland'], ['autriche', 'austria'],
  ['irlande', 'ireland', 'repofireland', 'republicofireland'], ['roumanie', 'romania'], ['pologne', 'poland'],
  ['suede', 'sweden'], ['bosnieherzegovine', 'bosniaandherzegovina', 'bosniaherzegovina', 'bosnia'],
  ['georgie', 'georgia'], ['hongrie', 'hungary'], ['ouganda', 'uganda'],
  ['algerie', 'algeria'], ['realsociedadb', 'realsociedadii', 'realsociedad2'],
  ['sportinggijon', 'sportingdegijon', 'gijon'], ['italie', 'italy'], ['turquie', 'turkey', 'turkiye'],
  ['belgique', 'belgium'], ['tcheque', 'czechia', 'czechrepublic'], ['espagne', 'spain'],
  ['angleterre', 'england'], ['croatie', 'croatia'], ['albanie', 'albania'], ['finlande', 'finland'],
  ['lettonie', 'latvia'], ['armenie', 'armenia'], ['chypre', 'cyprus'], ['soudan', 'sudan'],
  ['guineeequatoriale', 'equatorialguinea'], ['guineebissau', 'guineabissau'],
  ['cotedivoire', 'ivorycoast'], ['gambie', 'gambia'], ['rdcongo', 'drcongo'],
  ['afriquecentrale', 'centralafricanrepublic'], ['allemagne', 'germany'],
  ['paysbas', 'netherlands', 'holland'], ['suisse', 'switzerland'], ['tunisie', 'tunisia'], ['maroc', 'morocco'], ['egypte', 'egypt'],
  ['capeverdeislands', 'capeverde', 'caboverde'], ['comoros', 'comores'], ['mauritania', 'mauritanie'],
  ['burkinafaso'], ['botswana'], ['liberia'], ['rwanda'], ['mali'], ['congo'], ['niger'], ['kosovo'], ['belarus'],
];
const ALIAS_MAP = new Map();
for (const g of ALIAS_GROUPS) {
  for (const t of g) ALIAS_MAP.set(t, g);
}

function normName(v) {
  return String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
}

function tokenCandidates(name, frName) {
  const out = new Set();
  for (const raw of [name, frName]) {
    const t = normName(raw);
    if (!t) continue;
    out.add(t);
    for (const a of ALIAS_MAP.get(t) || []) out.add(a);
  }
  return Array.from(out);
}

function tokensMatch(cands, feeds) {
  const fn = feeds.map(normName).filter(Boolean);
  for (const c of cands) {
    for (const f of fn) {
      if (f === c) return true;
      if (c.length >= 4 && f.length >= 4 && (f.includes(c) || c.includes(f))) {
        if ((c === 'ireland' || c === 'irlande') && f.includes('northern')) continue;
        return true;
      }
    }
  }
  return false;
}

function isDelayedToken(raw) {
  return /postponed|canceled|cancelled|suspended|delayed|abandoned|interrupted|\bpst\b|\bppd\b|\bcanc\b|\bsusp\b|\bdel\b|\babd\b/i.test(String(raw || ''));
}

function parseKickoffMsNode(m) {
  const dp = String(m.date || '').match(/(\d{2})-(\d{2})-(\d{4})/);
  const tp = String(m.dayTime || m.time || '').match(/(\d{1,2}):(\d{2})/);
  if (!dp || !tp) return null;
  const ms = Date.parse(`${dp[3]}-${dp[2]}-${dp[1]}T${tp[1].padStart(2, '0')}:${tp[2]}:00+01:00`);
  return Number.isNaN(ms) ? null : ms;
}

async function fetchJsonSafe(url, timeoutMs = 5500) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const r = await fetch(url, { signal: controller.signal, headers: { Accept: 'application/json' } });
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  } finally {
    clearTimeout(tid);
  }
}

let activeProbe = null;
async function probeLiveScores() {
  if (activeProbe) return activeProbe;
  activeProbe = (async () => {
    try {
      // 1. Authoritative Promosport-Pronostic real-time rapid JSON
      const rapid = await fetchJsonSafe('https://www.promosport-pronostic.com/welcome/getmatchid_rapid', 5500);
      if (Array.isArray(rapid) && rapid.length) {
        const byId = new Map();
        for (const item of rapid) {
          if (item && item.match_id) byId.set(String(item.match_id), item);
        }
        for (const m of syncState.activeConcours.matches || []) {
          const item = m.siteMatchId ? byId.get(String(m.siteMatchId)) : null;
          if (!item) continue;
          if (isDelayedToken(item.st)) {
            m.isDelayed = true;
            m.status = 'scheduled';
            m.score = '- - -';
            m.scoreHome = undefined;
            m.scoreAway = undefined;
            m.liveMinute = undefined;
            m.result = null;
            continue;
          }
          const sh = /^\d+$/.test(String(item.bb1)) ? String(item.bb1) : null;
          const sa = /^\d+$/.test(String(item.bb2)) ? String(item.bb2) : null;
          if (sh !== null && sa !== null && (String(item.live) === '1' || item.st === '1H' || item.st === 'HT' || item.st === '2H')) {
            m.isDelayed = false;
            m.status = 'live';
            m.liveMinute = item.st === 'HT' ? 'HT' : (item.min ? `${item.min}'` : (item.st || 'LIVE'));
            m.scoreHome = sh;
            m.scoreAway = sa;
            m.score = `${sh} - ${sa}`;
          }
        }
        syncState.lastProbeAt = new Date().toISOString();
        syncState.status = 'synced';
      }

      // 2. Date-scoped ESPN scoreboards with +-36h proximity & delayed suppression
      const dateSet = new Set();
      const now = Date.now();
      for (const offset of [-86400000, 0, 86400000]) {
        const d = new Date(now + offset);
        dateSet.add(`${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, '0')}${String(d.getUTCDate()).padStart(2, '0')}`);
      }
      for (const m of syncState.activeConcours.matches || []) {
        const dp = String(m.date || '').match(/(\d{2})-(\d{2})-(\d{4})/);
        if (dp) dateSet.add(`${dp[3]}${dp[2]}${dp[1]}`);
      }
      const urls = [];
      for (const dt of Array.from(dateSet).slice(0, 6)) {
        for (const lg of ESPN_LEAGUES) {
          urls.push(`https://site.api.espn.com/apis/site/v2/sports/soccer/${lg}/scoreboard?dates=${dt}`);
        }
      }

      const pages = await Promise.allSettled(urls.map((u) => fetchJsonSafe(u, 5500)));
      const events = [];
      for (const p of pages) {
        if (p.status === 'fulfilled' && p.value && Array.isArray(p.value.events)) {
          events.push(...p.value.events);
        }
      }
      if (events.length) {
        for (const m of syncState.activeConcours.matches || []) {
          const hc = tokenCandidates(m.homeTeam, m.homeTeamFr);
          const ac = tokenCandidates(m.awayTeam, m.awayTeamFr);
          const koMs = parseKickoffMsNode(m);
          for (const ev of events) {
            const comp = ev?.competitions?.[0];
            const comps = comp?.competitors;
            if (!Array.isArray(comps) || comps.length < 2) continue;
            if (koMs && ev?.date) {
              const evMs = Date.parse(ev.date);
              if (!Number.isNaN(evMs) && Math.abs(evMs - koMs) > 36 * 3600 * 1000) continue;
            }
            const hm = comps.find((c) => c.homeAway === 'home') || comps[0];
            const aw = comps.find((c) => c.homeAway === 'away') || comps[1];
            const fh = [hm?.team?.displayName, hm?.team?.shortDisplayName, hm?.team?.name];
            const fa = [aw?.team?.displayName, aw?.team?.shortDisplayName, aw?.team?.name];
            if (tokensMatch(hc, fh) && tokensMatch(ac, fa)) {
              const rawSt = [comp?.status?.type?.name, comp?.status?.type?.shortDetail, comp?.status?.type?.description].filter(Boolean).join(' ');
              if (isDelayedToken(rawSt)) {
                m.isDelayed = true;
                m.status = 'scheduled';
                m.score = '- - -';
                m.scoreHome = undefined;
                m.scoreAway = undefined;
                m.liveMinute = undefined;
                m.result = null;
                break;
              }
              const st = comp?.status?.type?.state;
              const done = Boolean(comp?.status?.type?.completed || st === 'post');
              if ((st === 'in' || done) && hm?.score != null && aw?.score != null) {
                const sh = String(hm.score).trim();
                const sa = String(aw.score).trim();
                if (/^\d+$/.test(sh) && /^\d+$/.test(sa)) {
                  m.isDelayed = false;
                  m.scoreHome = sh;
                  m.scoreAway = sa;
                  m.score = `${sh} - ${sa}`;
                  if (done) {
                    m.status = 'finished';
                    m.liveMinute = undefined;
                    m.result = Number(sh) > Number(sa) ? '1' : Number(sa) > Number(sh) ? '2' : 'X';
                  } else {
                    m.status = 'live';
                    m.liveMinute = comp?.status?.displayClock || m.liveMinute;
                  }
                }
              }
              break;
            }
          }
        }
        syncState.lastProbeAt = new Date().toISOString();
        syncState.status = 'synced';
      }
    } catch {
      // Keep cached concours offline without crashing
    } finally {
      activeProbe = null;
    }
  })();
  return activeProbe;
}

void probeLiveScores();
setInterval(probeLiveScores, 10000);

function openBrowser(url) {
  if (process.argv.includes('--no-open')) return;
  try {
    const plat = process.platform;
    if (plat === 'darwin') {
      spawn('open', [url], { detached: true, stdio: 'ignore' }).unref();
    } else if (plat === 'win32') {
      spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore' }).unref();
    } else {
      spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
    }
  } catch {
    // Headless environment
  }
}

function getLanUrls(port) {
  const urls = [];
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const info of nets[name] || []) {
      if (info && info.family === 'IPv4' && !info.internal) {
        urls.push(`http://${info.address}:${port}`);
      }
    }
  }
  return urls;
}

http.createServer(async (req, res) => {
  const rawUrl = req.url || '/';
  const [urlPath, rawQuery = ''] = rawUrl.split('?');
  if (urlPath === '/api/promosport/sync') {
    if (rawQuery.includes('refresh=1') || !syncState.lastProbeAt) {
      await probeLiveScores();
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(syncState));
    return;
  }
  if (urlPath === '/api/promosport/bootstrap') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
    if (fs.existsSync(bootstrapFile)) {
      res.end(fs.readFileSync(bootstrapFile, 'utf-8'));
    } else {
      res.end(JSON.stringify({ available: false }));
    }
    return;
  }
  const cleanPath = urlPath === '/' ? 'index.html' : urlPath.replace(/^\/+/, '');
  let filePath = path.join(distDir, cleanPath);
  if ((!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) && fs.existsSync(path.join(publicDir, cleanPath))) {
    filePath = path.join(publicDir, cleanPath);
  }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(distDir, 'index.html');
  }
  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(res);
}).listen(PORT, '0.0.0.0', () => {
  const localUrl = `http://localhost:${PORT}`;
  console.log(`\n[OK] بروموسبور تونس - MB Football (Auto-Bootstrapped & Live Sync 1s/10s) running at ${localUrl}`);
  for (const lan of getLanUrls(PORT)) {
    console.log(`[MOBILE URL] ${lan}`);
  }
  openBrowser(localUrl);
});
